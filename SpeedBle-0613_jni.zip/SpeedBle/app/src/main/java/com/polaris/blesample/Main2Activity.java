package com.polaris.blesample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;

public class Main2Activity extends AppCompatActivity implements View.OnClickListener {

    private RecyclerView recyclerDevice;
    private Button btnScan;
    private Button btnConnect;
    private Button btnDisconnect;
    private GridView gridValue;
    private Button btnStartRead;
    private Button btnStopRead;
    private Button btnCommand1;
    private Button btnCommand2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        initView();
    }

    private void initView() {
        recyclerDevice = findViewById(R.id.recycler_device);
        btnScan = findViewById(R.id.btn_scan);
        btnConnect = findViewById(R.id.btn_connect);
        btnDisconnect = findViewById(R.id.btn_disconnect);
        gridValue = findViewById(R.id.grid_value);
        btnStartRead = findViewById(R.id.btn_start_read);
        btnStopRead = findViewById(R.id.btn_stop_read);
        btnCommand1 = findViewById(R.id.btn_command_1);
        btnCommand2 = findViewById(R.id.btn_command_2);

        btnScan.setOnClickListener(this);
        btnConnect.setOnClickListener(this);
        btnDisconnect.setOnClickListener(this);
        btnStartRead.setOnClickListener(this);
        btnStopRead.setOnClickListener(this);
        btnCommand1.setOnClickListener(this);
        btnCommand2.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_scan:
                break;
            case R.id.btn_connect:
                break;
            case R.id.btn_disconnect:
                break;
            case R.id.btn_start_read:
                break;
            case R.id.btn_stop_read:
                break;
            case R.id.btn_command_1:
                break;
            case R.id.btn_command_2:
                break;
        }
    }
}
