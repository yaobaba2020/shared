package com.polaris.blesample;

import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;

import com.polaris.speedble.data.BleDevice;
import com.polaris.speedble.data.ParseResult;

public class Global {
    public static BleDevice bleDevice;
    public static BluetoothGattService bluetoothGattService;
    public static BluetoothGattCharacteristic characteristic;
    public static ParseResult parseResult;
}
