package com.polaris.blesample.operation;

import android.annotation.TargetApi;
import android.bluetooth.BluetoothGattCharacteristic;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.polaris.blesample.Global;
import com.polaris.blesample.R;
import com.polaris.speedble.BleManagerImpl;
import com.polaris.speedble.callback.BleIndicateCallback;
import com.polaris.speedble.callback.BleNotifyCallback;
import com.polaris.speedble.callback.BleReadCallback;
import com.polaris.speedble.callback.BleWriteCallback;
import com.polaris.speedble.data.BleDevice;
import com.polaris.speedble.exception.BleException;
import com.polaris.speedble.utils.HexUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
public class CharacteristicOperationFragment extends Fragment {

    public static final int PROPERTY_READ = 1;
    public static final int PROPERTY_WRITE = 2;
    public static final int PROPERTY_WRITE_NO_RESPONSE = 3;
    public static final int PROPERTY_NOTIFY = 4;
    public static final int PROPERTY_INDICATE = 5;

    private LinearLayout layout_container;
    private List<String> childList = new ArrayList<>();
    private int id = 0;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_characteric_operation, null);
        initView(v);
        return v;
    }

    private void initView(View v) {
        layout_container = (LinearLayout) v.findViewById(R.id.layout_container);
    }

    public void showData() {
        final BleDevice bleDevice = Global.bleDevice;
        final BluetoothGattCharacteristic characteristic = Global.characteristic;

        final int charaProp = ((OperationActivity) getActivity()).getCharaProp();
        String child = characteristic.getUuid().toString() + " " + String.valueOf(charaProp);

        for (int i = 0; i < layout_container.getChildCount(); i++) {
            layout_container.getChildAt(i).setVisibility(View.GONE);
        }
        if (childList.contains(child)) {
            layout_container.findViewWithTag(bleDevice.getKey() + characteristic.getUuid().toString() + charaProp)
                    .setVisibility(View.VISIBLE);
        } else {
            childList.add(child);

            View view = LayoutInflater.from(getActivity()).inflate(R.layout.layout_characteric_operation, null);
            view.setTag(bleDevice.getKey() + characteristic.getUuid().toString() + charaProp);

            final TextView txt_title = (TextView) view.findViewById(R.id.txt_title);
            txt_title.setText(String.valueOf(characteristic.getUuid().toString() + " " + getActivity().getString(R.string.data_changed)));
            final TextView txt = (TextView) view.findViewById(R.id.txt);
            txt.setMovementMethod(ScrollingMovementMethod.getInstance());
            LinearLayout layout_add = (LinearLayout) view.findViewById(R.id.layout_add);
            LinearLayout layout_add_2 = (LinearLayout) view.findViewById(R.id.layout_add_2);

            ViewGroup.LayoutParams param = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

            int prop = characteristic.getProperties();

            switch (charaProp) {
                case PROPERTY_READ: {
                    View view_add = LayoutInflater.from(getActivity()).inflate(R.layout.layout_characteric_operation_button, null);
                    Button btn = (Button) view_add.findViewById(R.id.btn);
                    btn.setText(getActivity().getString(R.string.read));
                    btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            BleManagerImpl.getInstance().read(
                                    bleDevice,
                                    characteristic.getService().getUuid().toString(),
                                    characteristic.getUuid().toString(),
                                    new BleReadCallback() {

                                        @Override
                                        public void onReadSuccess(final byte[] data) {
                                            log(txt, "<-- " + HexUtil.formatHexString(data, true));
                                            Global.parseResult = BleManagerImpl.getInstance().parseResponse(data);
                                        }

                                        @Override
                                        public void onReadFailure(final BleException exception) {
                                            log(txt, "<-- " + exception.toString());
                                        }
                                    });
                        }
                    });
                    layout_add.addView(view_add, param);
                }
                break;

                case PROPERTY_WRITE: {
                    View view_add = LayoutInflater.from(getActivity()).inflate(R.layout.layout_characteric_operation_et, null);
                    final EditText et = (EditText) view_add.findViewById(R.id.et);
                    Button btn = (Button) view_add.findViewById(R.id.btn);
                    btn.setText(getActivity().getString(R.string.write));
                    btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String hex = et.getText().toString();
                            if (TextUtils.isEmpty(hex)) {
                                return;
                            }
                            BleManagerImpl.getInstance().writePrivate(
                                    bleDevice,
                                    characteristic.getService().getUuid().toString(),
                                    characteristic.getUuid().toString(),
                                    id,
                                    HexUtil.hexStringToBytes(hex),
                                    new BleWriteCallback() {

                                        @Override
                                        public void onWriteSuccess(final int current, final int total, final byte[] justWrite) {
                                            log(txt, "--> current: " + current
                                                    + " total: " + total
                                                    + " justWrite: " + HexUtil.formatHexString(justWrite, true));
                                        }

                                        @Override
                                        public void onWriteFailure(final BleException exception) {
                                            log(txt, "--> " + exception.toString());
                                        }
                                    });
                        }
                    });
                    if ((prop & BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
                        View view_add_2 = LayoutInflater.from(getActivity()).inflate(R.layout.layout_characteric_operation_button, null);
                        final Button btn_2 = (Button) view_add_2.findViewById(R.id.btn);
                        btn_2.setText(getActivity().getString(R.string.open_notification));
                        btn_2.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                if (btn_2.getText().toString().equals(getActivity().getString(R.string.open_notification))) {
                                    btn_2.setText(getActivity().getString(R.string.close_notification));
                                    BleManagerImpl.getInstance().notify(
                                            bleDevice,
                                            characteristic.getService().getUuid().toString(),
                                            characteristic.getUuid().toString(),
                                            new BleNotifyCallback() {

                                                @Override
                                                public void onNotifySuccess() {
                                                    log(txt, "<-- notify success");
                                                }

                                                @Override
                                                public void onNotifyFailure(final BleException exception) {
                                                    log(txt, "<-- " + exception.toString());
                                                }

                                                @Override
                                                public void onCharacteristicChanged(byte[] data) {
                                                    log(txt, "<-- " + HexUtil.formatHexString(characteristic.getValue(), true));
                                                    Global.parseResult = BleManagerImpl.getInstance().parseResponse(characteristic.getValue());
                                                }
                                            });
                                } else {
                                    btn_2.setText(getActivity().getString(R.string.open_notification));
                                    BleManagerImpl.getInstance().stopNotify(
                                            bleDevice,
                                            characteristic.getService().getUuid().toString(),
                                            characteristic.getUuid().toString());
                                }
                            }
                        });
                        layout_add_2.addView(view_add_2, param);
                        layout_add_2.setVisibility(View.VISIBLE);
                    }
                    if ((prop & BluetoothGattCharacteristic.PROPERTY_INDICATE) > 0) {
                        View view_add_2 = LayoutInflater.from(getActivity()).inflate(R.layout.layout_characteric_operation_button, null);
                        final Button btn_2 = (Button) view_add_2.findViewById(R.id.btn);
                        btn_2.setText(getActivity().getString(R.string.open_notification));
                        btn_2.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                if (btn_2.getText().toString().equals(getActivity().getString(R.string.open_notification))) {
                                    btn_2.setText(getActivity().getString(R.string.close_notification));
                                    BleManagerImpl.getInstance().indicate(
                                            bleDevice,
                                            characteristic.getService().getUuid().toString(),
                                            characteristic.getUuid().toString(),
                                            new BleIndicateCallback() {

                                                @Override
                                                public void onIndicateSuccess() {
                                                    log(txt, "<-- indicate success");
                                                }

                                                @Override
                                                public void onIndicateFailure(final BleException exception) {
                                                    log(txt, "<-- " + exception.toString());
                                                }

                                                @Override
                                                public void onCharacteristicChanged(byte[] data) {
                                                    log(txt, "<-- " + HexUtil.formatHexString(characteristic.getValue(), true));
                                                    Global.parseResult = BleManagerImpl.getInstance().parseResponse(characteristic.getValue());
                                                }
                                            });
                                } else {
                                    btn_2.setText(getActivity().getString(R.string.open_notification));
                                    BleManagerImpl.getInstance().stopIndicate(
                                            bleDevice,
                                            characteristic.getService().getUuid().toString(),
                                            characteristic.getUuid().toString());
                                }
                            }
                        });
                        layout_add_2.addView(view_add_2, param);
                        layout_add_2.setVisibility(View.VISIBLE);
                    }
                    layout_add.addView(view_add, param);
                }
                break;

                case PROPERTY_WRITE_NO_RESPONSE: {
                    View view_add = LayoutInflater.from(getActivity()).inflate(R.layout.layout_characteric_operation_et, null);
                    final EditText et = (EditText) view_add.findViewById(R.id.et);
                    Button btn = (Button) view_add.findViewById(R.id.btn);
                    btn.setText(getActivity().getString(R.string.write));
                    btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String hex = et.getText().toString();
                            if (TextUtils.isEmpty(hex)) {
                                return;
                            }
                            BleManagerImpl.getInstance().writePrivate(
                                    bleDevice,
                                    characteristic.getService().getUuid().toString(),
                                    characteristic.getUuid().toString(),
                                    id,
                                    HexUtil.hexStringToBytes(hex),
                                    new BleWriteCallback() {

                                        @Override
                                        public void onWriteSuccess(final int current, final int total, final byte[] justWrite) {
                                            log(txt, "--> current: " + current
                                                    + " total: " + total
                                                    + " justWrite: " + HexUtil.formatHexString(justWrite, true));
                                        }

                                        @Override
                                        public void onWriteFailure(final BleException exception) {
                                            log(txt, "--> " + exception.toString());
                                        }
                                    });
                        }
                    });
                    layout_add.addView(view_add, param);
                }
                break;

                case PROPERTY_NOTIFY: {
                    View view_add = LayoutInflater.from(getActivity()).inflate(R.layout.layout_characteric_operation_button, null);
                    final Button btn = (Button) view_add.findViewById(R.id.btn);
                    btn.setText(getActivity().getString(R.string.open_notification));
                    btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (btn.getText().toString().equals(getActivity().getString(R.string.open_notification))) {
                                btn.setText(getActivity().getString(R.string.close_notification));
                                BleManagerImpl.getInstance().notify(
                                        bleDevice,
                                        characteristic.getService().getUuid().toString(),
                                        characteristic.getUuid().toString(),
                                        new BleNotifyCallback() {

                                            @Override
                                            public void onNotifySuccess() {
                                                log(txt, "<-- notify success");
                                            }

                                            @Override
                                            public void onNotifyFailure(final BleException exception) {
                                                log(txt, "<-- " + exception.toString());
                                            }

                                            @Override
                                            public void onCharacteristicChanged(byte[] data) {
                                                log(txt, "<-- " + HexUtil.formatHexString(characteristic.getValue(), true));
                                                Global.parseResult = BleManagerImpl.getInstance().parseResponse(characteristic.getValue());
                                            }
                                        });
                            } else {
                                btn.setText(getActivity().getString(R.string.open_notification));
                                BleManagerImpl.getInstance().stopNotify(
                                        bleDevice,
                                        characteristic.getService().getUuid().toString(),
                                        characteristic.getUuid().toString());
                            }
                        }
                    });
                    layout_add.addView(view_add, param);
                }
                break;

                case PROPERTY_INDICATE: {
                    View view_add = LayoutInflater.from(getActivity()).inflate(R.layout.layout_characteric_operation_button, null);
                    final Button btn = (Button) view_add.findViewById(R.id.btn);
                    btn.setText(getActivity().getString(R.string.open_notification));
                    btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (btn.getText().toString().equals(getActivity().getString(R.string.open_notification))) {
                                btn.setText(getActivity().getString(R.string.close_notification));
                                BleManagerImpl.getInstance().indicate(
                                        bleDevice,
                                        characteristic.getService().getUuid().toString(),
                                        characteristic.getUuid().toString(),
                                        new BleIndicateCallback() {

                                            @Override
                                            public void onIndicateSuccess() {
                                                log(txt, "<-- indicate success");
                                            }

                                            @Override
                                            public void onIndicateFailure(final BleException exception) {
                                                log(txt, "<-- " + exception.toString());
                                            }

                                            @Override
                                            public void onCharacteristicChanged(byte[] data) {
                                                Global.parseResult = BleManagerImpl.getInstance().parseResponse(characteristic.getValue());
                                                log(txt, "<-- " + HexUtil.formatHexString(characteristic.getValue(), true));
                                            }
                                        });
                            } else {
                                btn.setText(getActivity().getString(R.string.open_notification));
                                BleManagerImpl.getInstance().stopIndicate(
                                        bleDevice,
                                        characteristic.getService().getUuid().toString(),
                                        characteristic.getUuid().toString());
                            }
                        }
                    });
                    layout_add.addView(view_add, param);
                }
                break;
            }

            layout_container.addView(view, param);
        }
    }

    private void runOnUiThread(Runnable runnable) {
        if (isAdded() && getActivity() != null)
            getActivity().runOnUiThread(runnable);
    }

    private void log(final TextView textView, final String content) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                textView.append(content);
                textView.append("\n");
            }
        });
    }

    private void randomId() {
        id = new Random().nextInt(10);
    }
}