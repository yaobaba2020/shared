package com.polaris.blesample.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.View;

import com.polaris.blesample.R;
import com.polaris.speedble.BleManagerImpl;
import com.polaris.speedble.data.BleDevice;

import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

import java.util.List;

public class DeviceAdapter2 extends SuperAdapter<BleDevice> {
    private int selectedPosition = -1;

    public DeviceAdapter2(Context context, List<BleDevice> items, int layoutResId) {
        super(context, items, layoutResId);
    }

    @Override
    public void onBind(SuperViewHolder holder, int viewType, int layoutPosition, BleDevice item) {
        if (item != null) {
            boolean isConnected = BleManagerImpl.getInstance().isConnected(item);
            String name = item.getName();
            String mac = item.getMac();
            int rssi = item.getRssi();
            holder.setText(R.id.txt_name, name);
            holder.setText(R.id.txt_mac, mac);
            holder.setText(R.id.txt_rssi, String.valueOf(rssi));
            if (isConnected) {
                holder.setVisibility(R.id.layout_rssi, View.GONE);
                holder.setVisibility(R.id.txt_connected, View.VISIBLE);
                holder.setImageResource(R.id.img_blue, R.mipmap.ic_blue_connected);
                holder.setTextColor(R.id.txt_name, 0xFF1DE9B6);
                holder.setTextColor(R.id.txt_mac, 0xFF1DE9B6);
            } else {
                holder.setVisibility(R.id.layout_rssi, View.VISIBLE);
                holder.setVisibility(R.id.txt_connected, View.GONE);
                holder.setImageResource(R.id.img_blue, R.mipmap.ic_blue_remote);
                holder.setTextColor(R.id.txt_name, Color.BLACK);
                holder.setTextColor(R.id.txt_mac, Color.BLACK);
            }
        }

        if (selectedPosition == layoutPosition) {
            holder.setBackgroundColor(R.id.root, Color.LTGRAY);
        } else {
            holder.setBackgroundColor(R.id.root, Color.WHITE);
        }
    }

    public int getSelectedPosition() {
        return selectedPosition;
    }

    public void setSelectedPosition(int selectedPosition) {
        this.selectedPosition = selectedPosition;
    }
}