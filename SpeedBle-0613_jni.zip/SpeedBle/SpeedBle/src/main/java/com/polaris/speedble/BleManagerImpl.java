package com.polaris.speedble;

import android.annotation.TargetApi;
import android.app.Application;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.os.Build;

import com.polaris.speedble.bluetooth.BleBluetooth;
import com.polaris.speedble.bluetooth.MultipleBluetoothController;
import com.polaris.speedble.callback.BleGattCallback;
import com.polaris.speedble.callback.BleIndicateCallback;
import com.polaris.speedble.callback.BleMtuChangedCallback;
import com.polaris.speedble.callback.BleNotifyCallback;
import com.polaris.speedble.callback.BleReadCallback;
import com.polaris.speedble.callback.BleRssiCallback;
import com.polaris.speedble.callback.BleScanAndConnectCallback;
import com.polaris.speedble.callback.BleScanCallback;
import com.polaris.speedble.callback.BleWriteCallback;
import com.polaris.speedble.data.BleDevice;
import com.polaris.speedble.data.BleScanState;
import com.polaris.speedble.data.ParseResult;
import com.polaris.speedble.scan.BleScanRuleConfig;
import com.polaris.speedble.utils.HexUtil;

import java.util.List;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
public class BleManagerImpl extends BleManager {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();

    public static BleManagerImpl getInstance() {
        return H.m;
    }

    protected static class H {
        protected static final BleManagerImpl m = new BleManagerImpl();
    }

    /*public void init(Application a) {
        i(a);
    }*/
    public native void init(Application a);

    /**
     * Get the Context
     *
     * @return
     */
    public Context a() {
        return a;
    }

    /**
     * Get the BluetoothManager
     *
     * @return
     */
    /*public BluetoothManager getBluetoothManager() {
        return gbm();
    }*/
    public native BluetoothManager getBluetoothManager();

    /**
     * Get the BluetoothAdapter
     *
     * @return
     */
    /*public BluetoothAdapter getBluetoothAdapter() {
        return gba();
    }*/
    public native BluetoothAdapter getBluetoothAdapter();

    /**
     * get the ScanRuleConfig
     *
     * @return
     */
    /*public BleScanRuleConfig getScanRuleConfig() {
        return gsrc();
    }*/
    public native BleScanRuleConfig getScanRuleConfig();

    /**
     * Get the multiple Bluetooth Controller
     *
     * @return
     */
    /*public MultipleBluetoothController getMultipleBluetoothController() {
        return gmbc();
    }*/
    public native MultipleBluetoothController getMultipleBluetoothController();

    /**
     * Configure scan and connection properties
     *
     * @param config
     */
    /*public void initScanRule(BleScanRuleConfig config) {
        isr(config);
    }*/
    public native void initScanRule(BleScanRuleConfig config);

    /**
     * Get the maximum number of connections
     *
     * @return
     */
    /*public int getMaxConnectCount() {
        return gmcc();
    }*/
    public native int getMaxConnectCount();

    /**
     * Set the maximum number of connections
     *
     * @param count
     * @return BleManager
     */
    /*public BleManagerImpl setMaxConnectCount(int count) {
        // return smcc(count);
        smcc(count);
        return this;
    }*/
    public native BleManagerImpl setMaxConnectCount(int count);

    /**
     * Get operate timeout
     *
     * @return
     */
    /*public int getOperateTimeout() {
        return got();
    }*/
    public native int getOperateTimeout();

    /**
     * Set operate timeout
     *
     * @param count
     * @return BleManager
     */
    /*public BleManagerImpl setOperateTimeout(int count) {
        // return soto(count);
        soto(count);
        return this;
    }*/
    public native BleManagerImpl setOperateTimeout(int count);

    /**
     * Get connect retry count
     *
     * @return
     */
    /*public int getReConnectCount() {
        return grcc();
    }*/
    public native int getReConnectCount();

    /**
     * Get connect retry interval
     *
     * @return
     */
    /*public long getReConnectInterval() {
        return grci();
    }*/
    public native long getReConnectInterval();

    /**
     * Set connect retry count and interval
     *
     * @param count
     * @return BleManager
     */
    /*public BleManagerImpl setReConnectCount(int count) {
        // return srcc(count, DCRI);
        srcc(count, DCRI);
        return this;
    }*/
    public native BleManagerImpl setReConnectCount(int count);

    /**
     * Set connect retry count and interval
     *
     * @param count
     * @return BleManager
     */
    /*public BleManagerImpl setReConnectCount(int count, long interval) {
        // return srcc(count, interval);
        srcc(count, interval);
        return this;
    }*/
    public native BleManagerImpl setReConnectCount2(int count, long interval);

    /**
     * Get operate split Write Num
     *
     * @return
     */
    /*public int getSplitWriteNum() {
        return gswn();
    }*/
    public native int getSplitWriteNum();

    /**
     * Set split Writ eNum
     *
     * @param num
     * @return BleManager
     */
    /*public BleManagerImpl setSplitWriteNum(int num) {
        // return sswn(num);
        sswn(num);
        return this;
    }*/
    public native BleManagerImpl setSplitWriteNum(int num);

    /**
     * Get operate connect Over Time
     *
     * @return
     */
    /*public long getConnectOverTime() {
        return gcot();
    }*/
    public native long getConnectOverTime();

    /**
     * Set connect Over Time
     *
     * @param time
     * @return BleManager
     */
    /*public BleManagerImpl setConnectOverTime(long time) {
        // return scot(time);
        scot(time);
        return this;
    }*/
    public native BleManagerImpl setConnectOverTime(long time);

    /**
     * print log?
     *
     * @param enable
     * @return BleManager
     */
    /*public BleManagerImpl enableLog(boolean enable) {
        // return el(enable);
        el(enable);
        return this;
    }*/
    public native BleManagerImpl enableLog(boolean enable);

    /**
     * scan device around
     *
     * @param callback
     */
    /*public void scan(BleScanCallback callback) {
        s(callback);
    }*/
    public native void scan(BleScanCallback callback);

    /**
     * scan device then connect
     *
     * @param callback
     */
    /*public void scanAndConnect(BleScanAndConnectCallback callback) {
        sac(callback);
    }*/
    public native void scanAndConnect(BleScanAndConnectCallback callback);

    /**
     * connect a known device
     *
     * @param bleDevice
     * @param bleGattCallback
     * @return
     */
    /*public BluetoothGatt connect(BleDevice bleDevice, BleGattCallback bleGattCallback) {
        return c(bleDevice, bleGattCallback);
    }*/
    public native BluetoothGatt connect(BleDevice bleDevice, BleGattCallback bleGattCallback);

    /**
     * connect a device through its mac without scan,whether or not it has been connected
     *
     * @param mac
     * @param bleGattCallback
     * @return
     */
    /*public BluetoothGatt connect(String mac, BleGattCallback bleGattCallback) {
        return c(mac, bleGattCallback);
    }*/
    public native BluetoothGatt connect2(String mac, BleGattCallback bleGattCallback);

    /**
     * Cancel scan
     */
    /*public void cancelScan() {
        cs();
    }*/
    public native void cancelScan();

    /**
     * notify
     *
     * @param bleDevice
     * @param uuid_service
     * @param uuid_notify
     * @param callback
     */
    /*public void notify(BleDevice bleDevice,
                       String uuid_service,
                       String uuid_notify,
                       BleNotifyCallback callback) {
        n(bleDevice, uuid_service, uuid_notify, false, callback);
    }*/
    public native void notify(BleDevice bleDevice,
                              String uuid_service,
                              String uuid_notify,
                              BleNotifyCallback callback);

    /**
     * notify
     *
     * @param bleDevice
     * @param uuid_service
     * @param uuid_notify
     * @param useCharacteristicDescriptor
     * @param callback
     */
    /*public void notify(BleDevice bleDevice,
                       String uuid_service,
                       String uuid_notify,
                       boolean useCharacteristicDescriptor,
                       BleNotifyCallback callback) {
        n(bleDevice, uuid_service, uuid_notify, useCharacteristicDescriptor, callback);
    }*/
    public native void notify2(BleDevice bleDevice,
                               String uuid_service,
                               String uuid_notify,
                               boolean useCharacteristicDescriptor,
                               BleNotifyCallback callback);

    /**
     * indicate
     *
     * @param bleDevice
     * @param uuid_service
     * @param uuid_indicate
     * @param callback
     */
    /*public void indicate(BleDevice bleDevice,
                         String uuid_service,
                         String uuid_indicate,
                         BleIndicateCallback callback) {
        i(bleDevice, uuid_service, uuid_indicate, false, callback);
    }*/
    public native void indicate(BleDevice bleDevice,
                                String uuid_service,
                                String uuid_indicate,
                                BleIndicateCallback callback);

    /**
     * indicate
     *
     * @param bleDevice
     * @param uuid_service
     * @param uuid_indicate
     * @param useCharacteristicDescriptor
     * @param callback
     */
    /*public void indicate(BleDevice bleDevice,
                         String uuid_service,
                         String uuid_indicate,
                         boolean useCharacteristicDescriptor,
                         BleIndicateCallback callback) {
        i(bleDevice, uuid_service, uuid_indicate, useCharacteristicDescriptor, callback);
    }*/
    public native void indicate2(BleDevice bleDevice,
                                 String uuid_service,
                                 String uuid_indicate,
                                 boolean useCharacteristicDescriptor,
                                 BleIndicateCallback callback);

    /**
     * stop notify, remove callback
     *
     * @param bleDevice
     * @param uuid_service
     * @param uuid_notify
     * @return
     */
    /*public boolean stopNotify(BleDevice bleDevice,
                              String uuid_service,
                              String uuid_notify) {
        return sn(bleDevice, uuid_service, uuid_notify, false);
    }*/
    public native boolean stopNotify(BleDevice bleDevice,
                                     String uuid_service,
                                     String uuid_notify);

    /**
     * stop notify, remove callback
     *
     * @param bleDevice
     * @param uuid_service
     * @param uuid_notify
     * @param useCharacteristicDescriptor
     * @return
     */
    /*public boolean stopNotify(BleDevice bleDevice,
                              String uuid_service,
                              String uuid_notify,
                              boolean useCharacteristicDescriptor) {
        return sn(bleDevice, uuid_service, uuid_notify, useCharacteristicDescriptor);
    }*/
    public native boolean stopNotify2(BleDevice bleDevice,
                                      String uuid_service,
                                      String uuid_notify,
                                      boolean useCharacteristicDescriptor);

    /**
     * stop indicate, remove callback
     *
     * @param bleDevice
     * @param uuid_service
     * @param uuid_indicate
     * @return
     */
    /*public boolean stopIndicate(BleDevice bleDevice,
                                String uuid_service,
                                String uuid_indicate) {
        return si(bleDevice, uuid_service, uuid_indicate, false);
    }*/
    public native boolean stopIndicate(BleDevice bleDevice,
                                       String uuid_service,
                                       String uuid_indicate);

    /**
     * stop indicate, remove callback
     *
     * @param bleDevice
     * @param uuid_service
     * @param uuid_indicate
     * @param useCharacteristicDescriptor
     * @return
     */
    /*public boolean stopIndicate(BleDevice bleDevice,
                                String uuid_service,
                                String uuid_indicate,
                                boolean useCharacteristicDescriptor) {
        return si(bleDevice, uuid_service, uuid_indicate, useCharacteristicDescriptor);
    }*/
    public native boolean stopIndicate2(BleDevice bleDevice,
                                        String uuid_service,
                                        String uuid_indicate,
                                        boolean useCharacteristicDescriptor);

    /**
     * write
     *
     * @param bleDevice
     * @param uuid_service
     * @param uuid_write
     * @param data
     * @param callback
     */
    /*public void write(BleDevice bleDevice,
                      String uuid_service,
                      String uuid_write,
                      byte[] data,
                      BleWriteCallback callback) {
        w(bleDevice, uuid_service, uuid_write, data, true, true, 0, callback);
    }*/
    public native void write(BleDevice bleDevice,
                             String uuid_service,
                             String uuid_write,
                             byte[] data,
                             BleWriteCallback callback);

    /**
     * write
     *
     * @param bleDevice
     * @param uuid_service
     * @param uuid_write
     * @param data
     * @param split
     * @param callback
     */
    /*public void write(BleDevice bleDevice,
                      String uuid_service,
                      String uuid_write,
                      byte[] data,
                      boolean split,
                      BleWriteCallback callback) {

        w(bleDevice, uuid_service, uuid_write, data, split, true, 0, callback);
    }*/
    public native void write2(BleDevice bleDevice,
                              String uuid_service,
                              String uuid_write,
                              byte[] data,
                              boolean split,
                              BleWriteCallback callback);

    /**
     * write
     *
     * @param bleDevice
     * @param uuid_service
     * @param uuid_write
     * @param data
     * @param split
     * @param sendNextWhenLastSuccess
     * @param intervalBetweenTwoPackage
     * @param callback
     */
    /*public void write(BleDevice bleDevice,
                      String uuid_service,
                      String uuid_write,
                      byte[] data,
                      boolean split,
                      boolean sendNextWhenLastSuccess,
                      long intervalBetweenTwoPackage,
                      BleWriteCallback callback) {

        w(bleDevice, uuid_service, uuid_write, data, split, sendNextWhenLastSuccess, intervalBetweenTwoPackage, callback);
    }*/
    public native void write3(BleDevice bleDevice,
                              String uuid_service,
                              String uuid_write,
                              byte[] data,
                              boolean split,
                              boolean sendNextWhenLastSuccess,
                              long intervalBetweenTwoPackage,
                              BleWriteCallback callback);

    /**
     * read
     *
     * @param bleDevice
     * @param uuid_service
     * @param uuid_read
     * @param callback
     */
    /*public void read(BleDevice bleDevice,
                     String uuid_service,
                     String uuid_read,
                     BleReadCallback callback) {
        r(bleDevice, uuid_service, uuid_read, callback);
    }*/
    public native void read(BleDevice bleDevice,
                            String uuid_service,
                            String uuid_read,
                            BleReadCallback callback);

    /**
     * read Rssi
     *
     * @param bleDevice
     * @param callback
     */
    /*public void readRssi(BleDevice bleDevice,
                         BleRssiCallback callback) {
        rr(bleDevice, callback);
    }*/
    public native void readRssi(BleDevice bleDevice,
                                BleRssiCallback callback);

    /**
     * set Mtu
     *
     * @param bleDevice
     * @param mtu
     * @param callback
     */
    /*public void setMtu(BleDevice bleDevice,
                       int mtu,
                       BleMtuChangedCallback callback) {
        sm(bleDevice, mtu, callback);
    }*/
    public native void setMtu(BleDevice bleDevice,
                              int mtu,
                              BleMtuChangedCallback callback);

    /**
     * requestConnectionPriority
     *
     * @param connectionPriority Request a specific connection priority. Must be one of
     *                           {@link BluetoothGatt#CONNECTION_PRIORITY_BALANCED},
     *                           {@link BluetoothGatt#CONNECTION_PRIORITY_HIGH}
     *                           or {@link BluetoothGatt#CONNECTION_PRIORITY_LOW_POWER}.
     * @throws IllegalArgumentException If the parameters are outside of their
     *                                  specified range.
     */
    /*public boolean requestConnectionPriority(BleDevice bleDevice, int connectionPriority) {
        return rcp(bleDevice, connectionPriority);
    }*/
    public native boolean requestConnectionPriority(BleDevice bleDevice, int connectionPriority);

    /**
     * is support ble?
     *
     * @return
     */
    /*public boolean isSupportBle() {
        return isb();
    }*/
    public native boolean isSupportBle();

    /**
     * Open bluetooth
     */
    /*public void enableBluetooth() {
        eb();
    }*/
    public native void enableBluetooth();

    /**
     * Disable bluetooth
     */
    /*public void disableBluetooth() {
        db();
    }*/
    public native void disableBluetooth();

    /**
     * judge Bluetooth is enable
     *
     * @return
     */
    /*public boolean isBlueEnable() {
        return ibe();
    }*/
    public native boolean isBlueEnable();

    /*public BleDevice convertBleDevice(BluetoothDevice bluetoothDevice) {
        return cbd(bluetoothDevice);
    }*/
    public native BleDevice convertBleDevice(BluetoothDevice bluetoothDevice);

    /*@TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public BleDevice convertBleDevice(ScanResult scanResult) {
        return cbdl(scanResult);
    }*/
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public native BleDevice convertBleDeviceL(ScanResult scanResult);

    /*public BleBluetooth getBleBluetooth(BleDevice bleDevice) {
        return gbb(bleDevice);
    }*/
    public native BleBluetooth getBleBluetooth(BleDevice bleDevice);

    /*public BluetoothGatt getBluetoothGatt(BleDevice bleDevice) {
        return gbg(bleDevice);
    }*/
    public native BluetoothGatt getBluetoothGatt(BleDevice bleDevice);

    /*public List<BluetoothGattService> getBluetoothGattServices(BleDevice bleDevice) {
        return gbgs(bleDevice);
    }*/
    public native List<BluetoothGattService> getBluetoothGattServices(BleDevice bleDevice);

    /*public List<BluetoothGattCharacteristic> getBluetoothGattCharacteristics(BluetoothGattService service) {
        return gbgc(service);
    }*/
    public native List<BluetoothGattCharacteristic> getBluetoothGattCharacteristics(BluetoothGattService service);

    /*public void removeConnectGattCallback(BleDevice bleDevice) {
        rcgc(bleDevice);
    }*/
    public native void removeConnectGattCallback(BleDevice bleDevice);

    /*public void removeRssiCallback(BleDevice bleDevice) {
        rrsc(bleDevice);
    }*/
    public native void removeRssiCallback(BleDevice bleDevice);

    /*public void removeMtuChangedCallback(BleDevice bleDevice) {
        rmcc(bleDevice);
    }*/
    public native void removeMtuChangedCallback(BleDevice bleDevice);

    /*public void removeNotifyCallback(BleDevice bleDevice, String uuid_notify) {
        rnc(bleDevice, uuid_notify);
    }*/
    public native void removeNotifyCallback(BleDevice bleDevice, String uuid_notify);

    /*public void removeIndicateCallback(BleDevice bleDevice, String uuid_indicate) {
        ric(bleDevice, uuid_indicate);
    }*/
    public native void removeIndicateCallback(BleDevice bleDevice, String uuid_indicate);

    /*public void removeWriteCallback(BleDevice bleDevice, String uuid_write) {
        rwc(bleDevice, uuid_write);
    }*/
    public native void removeWriteCallback(BleDevice bleDevice, String uuid_write);

    /*public void removeReadCallback(BleDevice bleDevice, String uuid_read) {
        rrdc(bleDevice, uuid_read);
    }*/
    public native void removeReadCallback(BleDevice bleDevice, String uuid_read);

    /*public void clearCharacterCallback(BleDevice bleDevice) {
        ccc(bleDevice);
    }*/
    public native void clearCharacterCallback(BleDevice bleDevice);

    /*public BleScanState getScanSate() {
        return gss();
    }*/
    public native BleScanState getScanSate();

    /*public List<BleDevice> getAllConnectedDevice() {
        return gacd();
    }*/
    public native List<BleDevice> getAllConnectedDevice();

    /**
     * @param bleDevice
     * @return State of the profile connection. One of
     * {@link BluetoothProfile#STATE_CONNECTED},
     * {@link BluetoothProfile#STATE_CONNECTING},
     * {@link BluetoothProfile#STATE_DISCONNECTED},
     * {@link BluetoothProfile#STATE_DISCONNECTING}
     */
    /*public int getConnectState(BleDevice bleDevice) {
        return gcs(bleDevice);
    }*/
    public native int getConnectState(BleDevice bleDevice);

    /*public boolean isConnected(BleDevice bleDevice) {
        return ic(bleDevice);
    }*/
    public native boolean isConnected(BleDevice bleDevice);

    /*public boolean isConnected(String mac) {
        return ic2(mac);
    }*/
    public native boolean isConnected2(String mac);

    /*public void disconnect(BleDevice bleDevice) {
        d(bleDevice);
    }*/
    public native void disconnect(BleDevice bleDevice);

    /*public void disconnectAllDevice() {
        dad();
    }*/
    public native void disconnectAllDevice();

    /*public void destroy() {
        d();
    }*/
    public native void destroy();

//    public native void writePrivate(BleDevice bleDevice,
//                                    String uuid_service,
//                                    String uuid_write,
//                                    int id,
//                                    byte[] data,
//                                    BleWriteCallback callback);

    public void writePrivate(BleDevice bleDevice,
                             String uuid_service,
                             String uuid_write,
                             int id,
                             byte[] data,
                             BleWriteCallback callback) {
        String sof = "OxAA";
        int len = 1;
        if (data != null) {
            len = data.length;
        }
        byte[] bytesToWrite = HexUtil.mergeByteArrays(HexUtil.hexStringToBytes(sof),
                HexUtil.intToByteArray1(len));
        bytesToWrite = HexUtil.mergeByteArrays(bytesToWrite , HexUtil.intToByteArray1(id));
        bytesToWrite = HexUtil.mergeByteArrays(bytesToWrite, data);
        byte xSum = HexUtil.byteArrayXOR(bytesToWrite);
        bytesToWrite = HexUtil.mergeByteArray2(bytesToWrite, xSum);

        write(bleDevice, uuid_service, uuid_write, bytesToWrite, callback);
    }

    public native byte[] writeLog(int id, byte[] data);

    public native ParseResult parseResponse(byte[] data);
}
