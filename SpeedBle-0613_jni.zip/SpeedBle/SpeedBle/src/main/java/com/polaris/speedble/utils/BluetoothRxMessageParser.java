package com.polaris.speedble.utils;

import com.polaris.speedble.data.DataStructure;

import java.util.LinkedList;
import java.util.Queue;

public class BluetoothRxMessageParser {

    //FIFO Queue where data is stored. Queue size = 100 deep
    private static Queue<DataStructure> mQueueData = new LinkedList<>();

    public static Queue<DataStructure> getQueueData() {
        return mQueueData;
    }

    public static DataStructure parse(byte[] data) {
        if (HexUtil.byteToInt(data[0]) == 0xAA) {
            switch (data[2]) {
                case 0x01: {
                    if (data[1] == 0x14) {
                        DataStructure rxData = new DataStructure();

                        rxData.Value6 = (HexUtil.byteToInt(data[3]) << 8) | HexUtil.byteToInt(data[4]);
                        rxData.Value7 = (HexUtil.byteToInt(data[5]) << 8) | HexUtil.byteToInt(data[6]);
                        rxData.Value8 = HexUtil.byteToInt(data[7]);
                        rxData.Value9 = (HexUtil.byteToInt(data[8]) << 8) | HexUtil.byteToInt(data[9]);
                        rxData.Value10 = (HexUtil.byteToInt(data[10]) << 8) | HexUtil.byteToInt(data[11]);
                        rxData.Value11 = HexUtil.byteToInt(data[12]);
                        rxData.Value12 = (HexUtil.byteToInt(data[13]) << 24) | (HexUtil.byteToInt(data[14]) << 16) | (HexUtil.byteToInt(data[15]) << 8) | HexUtil.byteToInt(data[16]);
                        rxData.Value13 = (HexUtil.byteToInt(data[17]) << 24) | (HexUtil.byteToInt(data[18]) << 16) | (HexUtil.byteToInt(data[19]) << 8) | HexUtil.byteToInt(data[20]);

                        if (mQueueData.size() >= 100) {
                            mQueueData.remove();    //Delete oldest element from queue
                        }

                        mQueueData.add(rxData); //Add new data to queue

                        return rxData;
                    }
                    break;
                }
                case 0x05: {
                    if (data[1] == 0x11) {
                        DataStructure rxData = new DataStructure();

                        rxData.Check1 = ((HexUtil.byteToInt(data[7]) >> 0) & 0x1) == 0x1;
                        rxData.Check6 = ((HexUtil.byteToInt(data[7]) >> 1) & 0x1) == 0x1;
                        rxData.Check11 = ((HexUtil.byteToInt(data[7]) >> 2) & 0x1) == 0x1;
                        rxData.Value1 = HexUtil.byteToInt(data[8]);

                        rxData.Check2 = ((HexUtil.byteToInt(data[9]) >> 0) & 0x1) == 0x1;
                        rxData.Check7 = ((HexUtil.byteToInt(data[9]) >> 1) & 0x1) == 0x1;
                        rxData.Check12 = ((HexUtil.byteToInt(data[9]) >> 2) & 0x1) == 0x1;
                        rxData.Value2 = HexUtil.byteToInt(data[10]);

                        rxData.Check3 = ((HexUtil.byteToInt(data[11]) >> 0) & 0x1) == 0x1;
                        rxData.Check8 = ((HexUtil.byteToInt(data[11]) >> 1) & 0x1) == 0x1;
                        rxData.Check13 = ((HexUtil.byteToInt(data[11]) >> 2) & 0x1) == 0x1;
                        rxData.Value3 = HexUtil.byteToInt(data[12]);

                        rxData.Check4 = ((HexUtil.byteToInt(data[13]) >> 0) & 0x1) == 0x1;
                        rxData.Check9 = ((HexUtil.byteToInt(data[13]) >> 1) & 0x1) == 0x1;
                        rxData.Check14 = ((HexUtil.byteToInt(data[13]) >> 2) & 0x1) == 0x1;
                        rxData.Value4 = (HexUtil.byteToInt(data[14]) << 8) | HexUtil.byteToInt(data[15]);

                        rxData.Check5 = ((HexUtil.byteToInt(data[16]) >> 0) & 0x1) == 0x1;
                        rxData.Check10 = ((HexUtil.byteToInt(data[16]) >> 1) & 0x1) == 0x1;
                        rxData.Check15 = ((HexUtil.byteToInt(data[16]) >> 2) & 0x1) == 0x1;
                        rxData.Value5 = HexUtil.byteToInt(data[17]);

                        if (mQueueData.size() >= 100) {
                            mQueueData.remove();        //Delete oldest element from queue
                        }

                        mQueueData.add(rxData);     //Add new data to queue

                        return rxData;
                    }
                    break;
                }
            }
        }

        return null;
    }
}
