package com.polaris.speedble.utils;


import com.polaris.speedble.bluetooth.BleBluetooth;

import java.util.LinkedHashMap;

public class BLHM<K, V> extends LinkedHashMap<K, V> {

    private final int MS;

    public BLHM(int s) {
        super((int) Math.ceil(s / 0.75) + 1, 0.75f, true);
        MS = s;
    }

    @Override
    protected boolean removeEldestEntry(java.util.Map.Entry e) {
        if (size() > MS && e.getValue() instanceof BleBluetooth) {
            ((BleBluetooth) e.getValue()).disconnect();
        }
        return size() > MS;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Entry<K, V> entry : entrySet()) {
            sb.append(String.format("%s:%s ", entry.getKey(), entry.getValue()));
        }
        return sb.toString();
    }

}
