package com.polaris.speedble.data;

public class Msg2Parmeter {
        public byte Status = 0;
        public int Value = 0;

        public byte getStatus() {
            return Status;
        }

        public void setStatus(byte status) {
            Status = status;
        }

        public int getValue() {
            return Value;
        }

        public void setValue(int value) {
            Value = value;
        }
    }