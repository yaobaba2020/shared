package com.polaris.speedble.scan;


import android.annotation.TargetApi;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;

import com.polaris.speedble.callback.BleScanPresenterImp;
import com.polaris.speedble.data.BleDevice;
import com.polaris.speedble.data.BleMsg;
import com.polaris.speedble.utils.BleLog;
import com.polaris.speedble.utils.HexUtil;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
public abstract class BSP implements BluetoothAdapter.LeScanCallback {

    private String[] dns;
    private String dm;
    private boolean f;
    private boolean nc;
    private long sto;
    private BleScanPresenterImp bspt;

    private List<BleDevice> bdl = new ArrayList<>();

    private Handler mh = new Handler(Looper.getMainLooper());
    private HandlerThread ht;
    private Handler h;
    private boolean bh;

    private static final class SH extends Handler {

        private final WeakReference<BSP> bsp;

        SH(Looper looper, BSP bleScanPresenter) {
            super(looper);
            bsp = new WeakReference<>(bleScanPresenter);
        }

        @Override
        public void handleMessage(Message msg) {
            BSP bsp = this.bsp.get();
            if (bsp != null) {
                if (msg.what == BleMsg.MSG_SCAN_DEVICE) {
                    final BleDevice bd = (BleDevice) msg.obj;
                    if (bd != null) {
                        bsp.handleResult(bd);
                    }
                }
            }
        }
    }

    private void handleResult(final BleDevice d) {
        mh.post(new Runnable() {
            @Override
            public void run() {
                onLeScan(d);
            }
        });
        checkDevice(d);
    }

    public void prepare(String[] names, String mac, boolean fuzzy, boolean needConnect,
                        long timeOut, BleScanPresenterImp bleScanPresenterImp) {
        dns = names;
        dm = mac;
        f = fuzzy;
        nc = needConnect;
        sto = timeOut;
        bspt = bleScanPresenterImp;

        ht = new HandlerThread(BSP.class.getSimpleName());
        ht.start();
        h = new SH(ht.getLooper(), this);
        bh = true;
    }

    public boolean ismNeedConnect() {
        return nc;
    }

    public BleScanPresenterImp getBleScanPresenterImp() {
        return bspt;
    }

    @Override
    public void onLeScan(BluetoothDevice device, int rssi, byte[] scanRecord) {
        if (device == null)
            return;

        if (!bh)
            return;

        Message m = h.obtainMessage();
        m.what = BleMsg.MSG_SCAN_DEVICE;
        m.obj = new BleDevice(device, rssi, scanRecord, System.currentTimeMillis());
        h.sendMessage(m);
    }

    private void checkDevice(BleDevice bleDevice) {
        if (TextUtils.isEmpty(dm) && (dns == null || dns.length < 1)) {
            correctDeviceAndNextStep(bleDevice);
            return;
        }

        if (!TextUtils.isEmpty(dm)) {
            if (!dm.equalsIgnoreCase(bleDevice.getMac()))
                return;
        }

        if (dns != null && dns.length > 0) {
            AtomicBoolean e = new AtomicBoolean(false);
            for (String n : dns) {
                String rn = bleDevice.getName();
                if (rn == null)
                    rn = "";
                if (f ? rn.contains(n) : rn.equals(n)) {
                    e.set(true);
                }
            }
            if (!e.get()) {
                return;
            }
        }

        correctDeviceAndNextStep(bleDevice);
    }


    private void correctDeviceAndNextStep(final BleDevice bd) {
        if (nc) {
            BleLog.i("devices detected  ------"
                    + "  name:" + bd.getName()
                    + "  mac:" + bd.getMac()
                    + "  Rssi:" + bd.getRssi()
                    + "  scanRecord:" + HexUtil.formatHexString(bd.getScanRecord()));

            bdl.add(bd);
            mh.post(new Runnable() {
                @Override
                public void run() {
                    BleScanner.getInstance().stopLeScan();
                }
            });

        } else {
            AtomicBoolean f = new AtomicBoolean(false);
            for (BleDevice d : bdl) {
                if (d.getDevice().equals(bd.getDevice())) {
                    f.set(true);
                }
            }
            if (!f.get()) {
                BleLog.i("device detected  ------"
                        + "  name: " + bd.getName()
                        + "  mac: " + bd.getMac()
                        + "  Rssi: " + bd.getRssi()
                        + "  scanRecord: " + HexUtil.formatHexString(bd.getScanRecord(), true));

                bdl.add(bd);
                mh.post(new Runnable() {
                    @Override
                    public void run() {
                        onScanning(bd);
                    }
                });
            }
        }
    }

    public final void notifyScanStarted(final boolean success) {
        bdl.clear();

        removeHandlerMsg();

        if (success && sto > 0) {
            mh.postDelayed(new Runnable() {
                @Override
                public void run() {
                    BleScanner.getInstance().stopLeScan();
                }
            }, sto);
        }

        mh.post(new Runnable() {
            @Override
            public void run() {
                onScanStarted(success);
            }
        });
    }

    public final void notifyScanStopped() {
        bh = false;
        ht.quit();
        removeHandlerMsg();
        mh.post(new Runnable() {
            @Override
            public void run() {
                onScanFinished(bdl);
            }
        });
    }

    public final void removeHandlerMsg() {
        mh.removeCallbacksAndMessages(null);
        h.removeCallbacksAndMessages(null);
    }

    public abstract void onScanStarted(boolean success);

    public abstract void onLeScan(BleDevice bleDevice);

    public abstract void onScanning(BleDevice bleDevice);

    public abstract void onScanFinished(List<BleDevice> bleDeviceList);
}
