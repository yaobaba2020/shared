package com.polaris.speedble;

import android.annotation.TargetApi;
import android.app.Application;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Looper;
import android.util.Log;

import com.polaris.speedble.bluetooth.BleBluetooth;
import com.polaris.speedble.bluetooth.MultipleBluetoothController;
import com.polaris.speedble.bluetooth.SW;
import com.polaris.speedble.callback.BleGattCallback;
import com.polaris.speedble.callback.BleIndicateCallback;
import com.polaris.speedble.callback.BleMtuChangedCallback;
import com.polaris.speedble.callback.BleNotifyCallback;
import com.polaris.speedble.callback.BleReadCallback;
import com.polaris.speedble.callback.BleRssiCallback;
import com.polaris.speedble.callback.BleScanAndConnectCallback;
import com.polaris.speedble.callback.BleScanCallback;
import com.polaris.speedble.callback.BleWriteCallback;
import com.polaris.speedble.data.BleDevice;
import com.polaris.speedble.data.BleScanState;
import com.polaris.speedble.data.DataMsg1;
import com.polaris.speedble.data.DataMsg2;
import com.polaris.speedble.data.ParseResult;
import com.polaris.speedble.exception.OtherException;
import com.polaris.speedble.scan.BleScanRuleConfig;
import com.polaris.speedble.scan.BleScanner;
import com.polaris.speedble.utils.BleLog;
import com.polaris.speedble.utils.HexUtil;

import java.util.List;
import java.util.UUID;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
public class BleManager {

    protected Application a;
    protected BleScanRuleConfig rc;
    protected BluetoothAdapter ba;
    protected MultipleBluetoothController mbc;
    protected BluetoothManager bm;

    public static final int DST = 10000;
    protected static final int DMMD = 7;
    protected static final int DOT = 5000;
    protected static final int DCRC = 0;
    protected static final int DCRI = 5000;
    protected static final int DM = 23;
    protected static final int DMM = 512;
    protected static final int DWDSC = 20;
    protected static final int DCOT = 10000;

    protected int mcc = DMMD;
    protected int oto = DOT;
    protected int rcc = DCRC;
    protected long rci = DCRI;
    protected int swn = DWDSC;
    protected long cot = DCOT;

    protected void i(Application a) {
        if (this.a == null && a != null) {
            this.a = a;
            if (isb()) {
                bm = (BluetoothManager) this.a.getSystemService(Context.BLUETOOTH_SERVICE);
            }
            ba = BluetoothAdapter.getDefaultAdapter();
            mbc = new MultipleBluetoothController();
            rc = new BleScanRuleConfig();
        }
    }

    /**
     * Get the Context
     *
     * @return
     */
    public Context a() {
        return a;
    }

    /**
     * getBluetoothManager
     * Get the BluetoothManager
     *
     * @return
     */
    public BluetoothManager gbm() {
        return bm;
    }

    /**
     * getBluetoothAdapter
     * Get the BluetoothAdapter
     *
     * @return
     */
    public BluetoothAdapter gba() {
        return ba;
    }

    /**
     * getScanRuleConfig
     * get the ScanRuleConfig
     *
     * @return
     */
    public BleScanRuleConfig gsrc() {
        return rc;
    }

    /**
     * getMultipleBluetoothController
     * Get the multiple Bluetooth Controller
     *
     * @return
     */
    public MultipleBluetoothController gmbc() {
        return mbc;
    }

    /**
     * initScanRule
     * Configure scan and connection properties
     *
     * @param config
     */
    public void isr(BleScanRuleConfig c) {
        this.rc = c;
    }

    /**
     * getMaxConnectCount
     * Get the maximum number of connections
     *
     * @return
     */
    public int gmcc() {
        return mcc;
    }

    /**
     * setMaxConnectCount
     * Set the maximum number of connections
     *
     * @param count
     * @return BleManager
     */
    public BleManager smcc(int i) {
        if (i > DMMD)
            i = DMMD;
        this.mcc = i;
        return this;
    }

    /**
     * getOperateTimeout
     * Get operate timeout
     *
     * @return
     */
    public int got() {
        return oto;
    }

    /**
     * setOperateTimeout
     * Set operate timeout
     *
     * @param count
     * @return BleManager
     */
    public BleManager soto(int i) {
        this.oto = i;
        return this;
    }

    /**
     * getReConnectCount
     * Get connect retry count
     *
     * @return
     */
    public int grcc() {
        return rcc;
    }

    /**
     * getReConnectInterval
     * Get connect retry interval
     *
     * @return
     */
    public long grci() {
        return rci;
    }

    /**
     * setReConnectCount
     * Set connect retry count and interval
     *
     * @param count
     * @return BleManager
     */
    public BleManager srcc(int c, long i) {
        if (c > 10)
            c = 10;
        if (i < 0)
            i = 0;
        this.rcc = c;
        this.rci = i;
        return this;
    }


    /**
     * getSplitWriteNum
     * Get operate split Write Num
     *
     * @return
     */
    public int gswn() {
        return swn;
    }

    /**
     * setSplitWriteNum
     * Set split Writ eNum
     *
     * @param num
     * @return BleManager
     */
    public BleManager sswn(int n) {
        if (n > 0) {
            this.swn = n;
        }
        return this;
    }

    /**
     * getConnectOverTime
     * Get operate connect Over Time
     *
     * @return
     */
    public long gcot() {
        return cot;
    }

    /**
     * setConnectOverTime
     * Set connect Over Time
     *
     * @param time
     * @return BleManager
     */
    public BleManager scot(long t) {
        if (t <= 0) {
            t = 100;
        }
        this.cot = t;
        return this;
    }

    public BleManager el(boolean b) {
        BleLog.isPrint = b;
        return this;
    }

    /**
     * scan
     * scan device around
     *
     * @param callback
     */
    public void s(BleScanCallback c) {
        if (c == null) {
            throw new IllegalArgumentException("BleScanCallback can not be Null!");
        }

        if (!ibe()) {
            BleLog.e("Bluetooth not enable!");
            c.onScanStarted(false);
            return;
        }

        UUID[] us = rc.getServiceUuids();
        String[] ns = rc.getDeviceNames();
        String dm = rc.getDeviceMac();
        boolean f = rc.isFuzzy();
        long to = rc.getScanTimeOut();

        BleScanner.getInstance().scan(us, ns, dm, f, to, c);
    }

    /**
     * scanAndConnect
     * scan device then connect
     *
     * @param callback
     */
    public void sac(BleScanAndConnectCallback c) {
        if (c == null) {
            throw new IllegalArgumentException("BleScanAndConnectCallback can not be Null!");
        }

        if (!ibe()) {
            BleLog.e("Bluetooth not enable!");
            c.onScanStarted(false);
            return;
        }

        UUID[] us = rc.getServiceUuids();
        String[] ns = rc.getDeviceNames();
        String dm = rc.getDeviceMac();
        boolean f = rc.isFuzzy();
        long to = rc.getScanTimeOut();

        BleScanner.getInstance().scanAndConnect(us, ns, dm, f, to, c);
    }

    /**
     * connect
     * connect a known device
     *
     * @param bleDevice
     * @param bleGattCallback
     * @return
     */
    public BluetoothGatt c(BleDevice d, BleGattCallback c) {
        if (c == null) {
            throw new IllegalArgumentException("BleGattCallback can not be Null!");
        }

        if (!ibe()) {
            BleLog.e("Bluetooth not enable!");
            c.onConnectFail(d, new OtherException("Bluetooth not enable!"));
            return null;
        }

        if (Looper.myLooper() == null || Looper.myLooper() != Looper.getMainLooper()) {
            BleLog.w("Be careful: currentThread is not MainThread!");
        }

        if (d == null || d.getDevice() == null) {
            c.onConnectFail(d, new OtherException("Not Found Device Exception Occurred!"));
        } else {
            BleBluetooth bt = mbc.buildConnectingBle(d);
            boolean ac = rc.isAutoConnect();
            return bt.connect(d, ac, c);
        }

        return null;
    }

    /**
     * connect
     * connect a device through its mac without scan,whether or not it has been connected
     *
     * @param mac
     * @param bleGattCallback
     * @return
     */
    public BluetoothGatt c2(String m, BleGattCallback c) {
        BluetoothDevice d1 = gba().getRemoteDevice(m);
        BleDevice d2 = new BleDevice(d1, 0, null, 0);
        return c(d2, c);
    }


    /**
     * cancelScan
     * Cancel scan
     */
    public void cs() {
        BleScanner.getInstance().stopLeScan();
    }

    /**
     * notify
     *
     * @param bleDevice
     * @param uuid_service
     * @param uuid_notify
     * @param useCharacteristicDescriptor
     * @param callback
     */
    public void n(BleDevice d,
                  String s,
                  String n,
                  boolean cd,
                  BleNotifyCallback c) {
        if (c == null) {
            throw new IllegalArgumentException("BleNotifyCallback can not be Null!");
        }

        BleBluetooth b = mbc.getBleBluetooth(d);
        if (b == null) {
            c.onNotifyFailure(new OtherException("This device not connect!"));
        } else {
            b.newBleConnector()
                    .withUUIDString(s, n)
                    .enableCharacteristicNotify(c, n, cd);
        }
    }

    /**
     * indicate
     *
     * @param bleDevice
     * @param uuid_service
     * @param uuid_indicate
     * @param useCharacteristicDescriptor
     * @param callback
     */
    public void in(BleDevice d,
                   String s,
                   String i,
                   boolean cd,
                   BleIndicateCallback c) {
        if (c == null) {
            throw new IllegalArgumentException("BleIndicateCallback can not be Null!");
        }

        BleBluetooth b = mbc.getBleBluetooth(d);
        if (b == null) {
            c.onIndicateFailure(new OtherException("This device not connect!"));
        } else {
            b.newBleConnector()
                    .withUUIDString(s, i)
                    .enableCharacteristicIndicate(c, i, cd);
        }
    }

    /**
     * stopNotify
     * stop notify, remove callback
     *
     * @param bleDevice
     * @param uuid_service
     * @param uuid_notify
     * @param useCharacteristicDescriptor
     * @return
     */
    public boolean sn(BleDevice d,
                      String s1,
                      String s2,
                      boolean cd) {
        BleBluetooth b = mbc.getBleBluetooth(d);
        if (b == null) {
            return false;
        }
        boolean s = b.newBleConnector()
                .withUUIDString(s1, s2)
                .disableCharacteristicNotify(cd);
        if (s) {
            b.removeNotifyCallback(s2);
        }
        return s;
    }

    /**
     * stopIndicate
     * stop indicate, remove callback
     *
     * @param d
     * @param s1
     * @param s2
     * @param z
     * @return
     */
    public boolean si(BleDevice d,
                      String s1,
                      String s2,
                      boolean z) {
        BleBluetooth bb = mbc.getBleBluetooth(d);
        if (bb == null) {
            return false;
        }
        boolean s = bb.newBleConnector()
                .withUUIDString(s1, s2)
                .disableCharacteristicIndicate(z);
        if (s) {
            bb.removeIndicateCallback(s2);
        }
        return s;
    }

    /**
     * write
     *
     * @param d
     * @param s
     * @param w
     * @param bs
     * @param z1
     * @param z2
     * @param j
     * @param c
     */
    public void w(BleDevice d,
                  String s,
                  String w,
                  byte[] bs,
                  boolean z1,
                  boolean z2,
                  long j,
                  BleWriteCallback c) {

        if (c == null) {
            throw new IllegalArgumentException("BleWriteCallback can not be Null!");
        }

        if (bs == null) {
            BleLog.e("data is Null!");
            c.onWriteFailure(new OtherException("data is Null!"));
            return;
        }

        if (bs.length > 20 && !z1) {
            BleLog.w("Be careful: data's length beyond 20! Ensure MTU higher than 23, or use spilt write!");
        }

        BleBluetooth bb = mbc.getBleBluetooth(d);
        if (bb == null) {
            c.onWriteFailure(new OtherException("This device not connect!"));
        } else {
            if (z1 && bs.length > gswn()) {
                new SW().sw(bb, s, w, bs,
                        z2, j, c);
            } else {
                bb.newBleConnector()
                        .withUUIDString(s, w)
                        .writeCharacteristic(bs, c, w);
            }
        }
    }

    /**
     * read
     *
     * @param bleDevice
     * @param uuid_service
     * @param uuid_read
     * @param callback
     */
    public void r(BleDevice d,
                  String s,
                  String r,
                  BleReadCallback c) {
        if (c == null) {
            throw new IllegalArgumentException("BleReadCallback can not be Null!");
        }

        BleBluetooth b = mbc.getBleBluetooth(d);
        if (b == null) {
            c.onReadFailure(new OtherException("This device is not connected!"));
        } else {
            b.newBleConnector()
                    .withUUIDString(s, r)
                    .readCharacteristic(c, r);
        }
    }

    /**
     * readRssi
     * read Rssi
     *
     * @param bleDevice
     * @param callback
     */
    public void rr(BleDevice d,
                   BleRssiCallback c) {
        if (c == null) {
            throw new IllegalArgumentException("BleRssiCallback can not be Null!");
        }

        BleBluetooth b = mbc.getBleBluetooth(d);
        if (b == null) {
            c.onRssiFailure(new OtherException("This device is not connected!"));
        } else {
            b.newBleConnector().readRemoteRssi(c);
        }
    }

    /**
     * setMtu
     * set Mtu
     *
     * @param bleDevice
     * @param mtu
     * @param callback
     */
    public void sm(BleDevice d,
                   int m,
                   BleMtuChangedCallback c) {
        if (c == null) {
            throw new IllegalArgumentException("BleMtuChangedCallback can not be Null!");
        }

        if (m > DMM) {
            BleLog.e("requiredMtu should lower than 512 !");
            c.onSetMTUFailure(new OtherException("requiredMtu should lower than 512 !"));
            return;
        }

        if (m < DM) {
            BleLog.e("requiredMtu should higher than 23 !");
            c.onSetMTUFailure(new OtherException("requiredMtu should higher than 23 !"));
            return;
        }

        BleBluetooth b = mbc.getBleBluetooth(d);
        if (b == null) {
            c.onSetMTUFailure(new OtherException("This device is not connected!"));
        } else {
            b.newBleConnector().setMtu(m, c);
        }
    }

    /**
     * requestConnectionPriority
     *
     * @param connectionPriority Request a specific connection priority. Must be one of
     *                           {@link BluetoothGatt#CONNECTION_PRIORITY_BALANCED},
     *                           {@link BluetoothGatt#CONNECTION_PRIORITY_HIGH}
     *                           or {@link BluetoothGatt#CONNECTION_PRIORITY_LOW_POWER}.
     * @throws IllegalArgumentException If the parameters are outside of their
     *                                  specified range.
     */
    public boolean rcp(BleDevice d, int p) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            BleBluetooth b = mbc.getBleBluetooth(d);
            if (b == null) {
                return false;
            } else {
                return b.newBleConnector().requestConnectionPriority(p);
            }
        }
        return false;
    }

    /**
     * isSupportBle
     * is support ble?
     *
     * @return
     */
    public boolean isb() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2
                && a.getApplicationContext().getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE);
    }

    /**
     * enableBluetooth
     * Open bluetooth
     */
    public void eb() {
        if (ba != null) {
            ba.enable();
        }
    }

    /**
     * disableBluetooth
     * Disable bluetooth
     */
    public void db() {
        if (ba != null) {
            if (ba.isEnabled())
                ba.disable();
        }
    }

    /**
     * ibe
     * judge Bluetooth is enable
     *
     * @return
     */
    public boolean ibe() {
        return ba != null && ba.isEnabled();
    }

    public BleDevice cbd(BluetoothDevice d) {
        return new BleDevice(d);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public BleDevice cbdl(ScanResult r) {
        if (r == null) {
            throw new IllegalArgumentException("scanResult can not be Null!");
        }
        BluetoothDevice bd = r.getDevice();
        int r2 = r.getRssi();
        ScanRecord sr = r.getScanRecord();
        byte[] b = null;
        if (sr != null)
            b = sr.getBytes();
        long tn = r.getTimestampNanos();
        return new BleDevice(bd, r2, b, tn);
    }

    public BleBluetooth gbb(BleDevice b) {
        if (mbc != null) {
            return mbc.getBleBluetooth(b);
        }
        return null;
    }

    public BluetoothGatt gbg(BleDevice d) {
        BleBluetooth b = gbb(d);
        if (b != null)
            return b.getBluetoothGatt();
        return null;
    }

    public List<BluetoothGattService> gbgs(BleDevice d) {
        BluetoothGatt g = gbg(d);
        if (g != null) {
            return g.getServices();
        }
        return null;
    }

    public List<BluetoothGattCharacteristic> gbgc(BluetoothGattService s) {
        return s.getCharacteristics();
    }

    public void rcgc(BleDevice d) {
        BleBluetooth b = gbb(d);
        if (b != null)
            b.removeConnectGattCallback();
    }

    public void rrsc(BleDevice d) {
        BleBluetooth b = gbb(d);
        if (b != null)
            b.removeRssiCallback();
    }

    public void rmcc(BleDevice d) {
        BleBluetooth b = gbb(d);
        if (b != null)
            b.removeMtuChangedCallback();
    }

    public void rnc(BleDevice d, String n) {
        BleBluetooth b = gbb(d);
        if (b != null)
            b.removeNotifyCallback(n);
    }

    public void ric(BleDevice d, String i) {
        BleBluetooth b = gbb(d);
        if (b != null)
            b.removeIndicateCallback(i);
    }

    public void rwc(BleDevice d, String w) {
        BleBluetooth b = gbb(d);
        if (b != null)
            b.removeWriteCallback(w);
    }

    public void rrdc(BleDevice d, String r) {
        BleBluetooth b = gbb(d);
        if (b != null)
            b.removeReadCallback(r);
    }

    public void ccc(BleDevice d) {
        BleBluetooth b = gbb(d);
        if (b != null)
            b.clearCharacterCallback();
    }

    public BleScanState gss() {
        return BleScanner.getInstance().getScanState();
    }

    public List<BleDevice> gacd() {
        if (mbc == null)
            return null;
        return mbc.getDeviceList();
    }

    /**
     * getConnectState
     *
     * @param bleDevice
     * @return State of the profile connection. One of
     * {@link BluetoothProfile#STATE_CONNECTED},
     * {@link BluetoothProfile#STATE_CONNECTING},
     * {@link BluetoothProfile#STATE_DISCONNECTED},
     * {@link BluetoothProfile#STATE_DISCONNECTING}
     */
    public int gcs(BleDevice d) {
        if (d != null) {
            return bm.getConnectionState(d.getDevice(), BluetoothProfile.GATT);
        } else {
            return BluetoothProfile.STATE_DISCONNECTED;
        }
    }

    public boolean ic(BleDevice d) {
        return gcs(d) == BluetoothProfile.STATE_CONNECTED;
    }

    public boolean ic2(String m) {
        List<BleDevice> l = gacd();
        for (BleDevice d : l) {
            if (d != null) {
                if (d.getMac().equals(m)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void d(BleDevice d) {
        if (mbc != null) {
            mbc.disconnect(d);
        }
    }

    public void dad() {
        if (mbc != null) {
            mbc.disconnectAllDevice();
        }
    }

    public void dt() {
        if (mbc != null) {
            mbc.destroy();
        }
    }

//    public ParseResult parseResponse(byte[] data) {
//        ParseResult result = new ParseResult();
//        result.setStMsgValid(true);        // result.stMsgValid = true;
//
//        if (HexUtil.byteToInt(data[0]) == 0xAA) {
//            result.setStRxMsgId(data[2]);       // result.stRxMsgId = data[2];    //Return id
//
//            switch (data[2]) {
//                case 0x01: {
//                    if (data[1] == 0x14) {
//                        DataMsg1 stDataMsg1 = result.getStDataMsg1();
//
//                        stDataMsg1.setVar1((data[4] << 8) | data[3]);
//                        stDataMsg1.setVar2((data[6] << 8) | data[5]);
//                        stDataMsg1.setVar3(data[7]);
//                        stDataMsg1.setVar4((data[9] << 8) | data[8]);
//                        stDataMsg1.setVar5((data[11] << 8) | data[10]);
//                        stDataMsg1.setVar6(data[12]);
//                        stDataMsg1.setVar7((data[16] << 24) | (data[15] << 16) | (data[14] << 8) | data[13]);
//                        stDataMsg1.setVar8((data[20] << 24) | (data[19] << 16) | (data[18] << 8) | data[17]);
//
//                        result.setStDataMsg1(stDataMsg1);
//                    } else {
//                        result.setStMsgValid(false);        // result.stMsgValid = false;
//                    }
//                    break;
//                }
//                case 0x05: {
//                    if (data[1] == 0x11) {
//                        DataMsg2 stDataMsg2 = result.getStDataMsg2();
//
//                        stDataMsg2.setStatus((data[4] << 8) | data[3]);
//                        stDataMsg2.getVar9().setStatus(data[5]);
//                        stDataMsg2.getVar9().setValue(data[6]);
//                        stDataMsg2.getVar10().setStatus(data[7]);
//                        stDataMsg2.getVar10().setValue(data[8]);
//                        stDataMsg2.getVar11().setStatus(data[9]);
//                        stDataMsg2.getVar11().setValue(data[10]);
//                        stDataMsg2.getVar12().setStatus(data[11]);
//                        stDataMsg2.getVar12().setValue((data[13] << 8) | data[12]);
//                        stDataMsg2.getVar13().setStatus(data[14]);
//                        stDataMsg2.getVar13().setValue(data[15]);
//
//                        result.setStDataMsg2(stDataMsg2);
//                    } else {
//                        result.setStMsgValid(false);        // result.stMsgValid = false;
//                    }
//                    break;
//                }
//                default:
//                    result.setStMsgValid(false);        // result.stMsgValid = false;
//                    break;
//            }
//        } else {
//            result.setStMsgValid(false);        // result.stMsgValid = false;
//        }
//
//        return result;
//    }
}