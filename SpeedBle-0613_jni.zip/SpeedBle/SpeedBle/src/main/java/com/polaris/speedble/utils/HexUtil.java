package com.polaris.speedble.utils;

import android.view.View;

import java.util.Calendar;

public class HexUtil {

    private static final char[] DL = {'0', '1', '2', '3', '4', '5',
            '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    private static final char[] DU = {'0', '1', '2', '3', '4', '5',
            '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    public static char[] encodeHex(byte[] data) {
        return encodeHex(data, true);
    }

    public static char[] encodeHex(byte[] data, boolean toLowerCase) {
        return eh(data, toLowerCase ? DL : DU);
    }

    protected static char[] eh(byte[] d, char[] t) {
        if (d == null)
            return null;
        int l = d.length;
        char[] o = new char[l << 1];
        for (int i = 0, j = 0; i < l; i++) {
            o[j++] = t[(0xF0 & d[i]) >>> 4];
            o[j++] = t[0x0F & d[i]];
        }
        return o;
    }


    public static String encodeHexStr(byte[] data) {
        return encodeHexStr(data, true);
    }

    public static String encodeHexStr(byte[] data, boolean toLowerCase) {
        return ehs(data, toLowerCase ? DL : DU);
    }


    protected static String ehs(byte[] d, char[] t) {
        return new String(eh(d, t));
    }

    public static String formatHexString(byte[] data) {
        return formatHexString(data, false);
    }

    public static String formatHexString(byte[] data, boolean addSpace) {
        if (data == null || data.length < 1)
            return null;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < data.length; i++) {
            String h = Integer.toHexString(data[i] & 0xFF);
            if (h.length() == 1) {
                h = '0' + h;
            }
            sb.append(h);
            if (addSpace)
                sb.append(" ");
        }
        return sb.toString().trim();
    }

    public static byte[] decodeHex(char[] data) {

        int l = data.length;

        if ((l & 0x01) != 0) {
            throw new RuntimeException("Odd number of characters.");
        }

        byte[] o = new byte[l >> 1];

        // two characters form the hex value.
        for (int i = 0, j = 0; j < l; i++) {
            int f = td(data[j], j) << 4;
            j++;
            f = f | td(data[j], j);
            j++;
            o[i] = (byte) (f & 0xFF);
        }

        return o;
    }


    protected static int td(char ch, int index) {
        int d = Character.digit(ch, 16);
        if (d == -1) {
            throw new RuntimeException("Illegal hexadecimal character " + ch
                    + " at index " + index);
        }
        return d;
    }


    public static byte[] hexStringToBytes(String hexString) {
        if (hexString == null || hexString.equals("")) {
            return null;
        }
        if (hexString.startsWith("0x")) {
            hexString = hexString.substring(2);
        }
        if (hexString.equals("")) {
            return null;
        }
        hexString = hexString.trim();
        hexString = hexString.toUpperCase();
        int l = hexString.length() / 2;
        char[] hc = hexString.toCharArray();
        byte[] d = new byte[l];
        for (int i = 0; i < l; i++) {
            int p = i * 2;
            d[i] = (byte) (charToByte(hc[p]) << 4 | charToByte(hc[p + 1]));
        }
        return d;
    }

    public static byte charToByte(char c) {
        return (byte) "0123456789ABCDEF".indexOf(c);
    }

    public static String extractData(byte[] data, int position) {
        return HexUtil.formatHexString(new byte[]{data[position]});
    }

    public static byte[] intToByteArray(int a) {
        byte[] ret = new byte[4];
        ret[3] = (byte) (a & 0xFF);
        ret[2] = (byte) ((a >> 8) & 0xFF);
        ret[1] = (byte) ((a >> 16) & 0xFF);
        ret[0] = (byte) ((a >> 24) & 0xFF);
        return ret;
    }

    public static byte[] intToByteArray1(int a) {
        byte[] ret = new byte[1];
        ret[0] = (byte) (a & 0xFF);
        return ret;
    }

    public static byte intToByte(int a) {
        return (byte) (a & 0xFF);
    }

    public static int byteToInt(byte b) {
        return b & 0xFF;
    }

    public static int byteArrayToInt(byte[] b) {
        byte[] bb = new byte[4];
        if (b.length < 4) {
            for (int i = 0; i < 4; i++) {
                // 01 02 03
                // 00 01 02 03
                if (4 - i > b.length) {
                    bb[i] = 0;
                } else {
                    bb[i] = b[i - (4 - b.length)];
                }
            }
            b = bb;
        }
        return (b[3] & 0xFF) + ((b[2] & 0xFF) << 8) + ((b[1] & 0xFF) << 16) + ((b[0] & 0xFF) << 24);
    }

//    public static int byteArrayToInt(byte[] b) {
//        return (b[3] & 0xFF) + ((b[2] & 0xFF) << 8) + ((b[1] & 0xFF) << 16) + ((b[0] & 0xFF) << 24);
//    }

    public static byte[] mergeByteArray1(byte a, byte[] b) {
        byte[] aa = {a};
        return mergeByteArrays(aa, b);
    }

    public static byte[] mergeByteArray2(byte[] a, byte b) {
        byte[] bb = {b};
        return mergeByteArrays(a, bb);
    }

    public static byte[] mergeByteArrays(byte[] a, byte[] b) {
        if (a == null) a = new byte[0];
        if (b == null) b = new byte[0];
        byte[] result = new byte[a.length + b.length];
        System.arraycopy(a, 0, result, 0, a.length);
        System.arraycopy(b, 0, result, a.length, b.length);
        return result;
    }

    public static byte byteXOR(byte a, byte b) {
        return (byte) (a ^ b);
    }

    public static byte byteArrayXOR(byte[] a) {
        byte result = a[0];
        for (int i = 1; i < a.length; i++) {
            result = byteXOR(result, a[i]);
        }
        return result;
    }

    public static byte byteOR(byte a, byte b) {
        return (byte) (a | b);
    }

    public static byte byteArrayOR(byte[] a) {
        byte result = a[0];
        for (int i = 1; i < a.length; i++) {
            result = byteOR(result, a[i]);
        }
        return result;
    }

    public static int byteShiftLeft(byte b, int i) {
        return b << i;
    }

    public static int byteShiftRight(byte b, int i) {
        return b >> i;
    }

    public static byte[] byteArraySub(byte[] a, int start) {
        int len = a.length - start;
        return byteArraySub2(a, start, len);
    }

    public static byte[] byteArraySub2(byte[] a, int start, int len) {
        byte[] result = new byte[len];
        System.arraycopy(a, start, result, 0, len);
        return result;
    }

    public static boolean equalsIgnoreCase(String s1, String s2) {
        return s1.equalsIgnoreCase(s2);
    }

    public static boolean check(int y, int m, int d) {
        Calendar cal = Calendar.getInstance();
        if (cal.get(Calendar.YEAR) <= y
                && cal.get(Calendar.MONTH) <= m
                && cal.get(Calendar.DATE) <= d) {
            return true;
        }
        return false;
    }
}
