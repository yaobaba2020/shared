package com.polaris.speedble.bluetooth;


import android.bluetooth.BluetoothDevice;
import android.os.Build;

import com.polaris.speedble.BleManagerImpl;
import com.polaris.speedble.data.BleDevice;
import com.polaris.speedble.utils.BLHM;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MultipleBluetoothController {

    private final BLHM<String, BleBluetooth> blhm;
    private final HashMap<String, BleBluetooth> m;

    public MultipleBluetoothController() {
        blhm = new BLHM<>(BleManagerImpl.getInstance().getMaxConnectCount());
        m = new HashMap<>();
    }

    public synchronized BleBluetooth buildConnectingBle(BleDevice bleDevice) {
        BleBluetooth bleBluetooth = new BleBluetooth(bleDevice);
        if (!m.containsKey(bleBluetooth.getDeviceKey())) {
            m.put(bleBluetooth.getDeviceKey(), bleBluetooth);
        }
        return bleBluetooth;
    }

    public synchronized void removeConnectingBle(BleBluetooth bleBluetooth) {
        if (bleBluetooth == null) {
            return;
        }
        if (m.containsKey(bleBluetooth.getDeviceKey())) {
            m.remove(bleBluetooth.getDeviceKey());
        }
    }

    public synchronized void addBleBluetooth(BleBluetooth bleBluetooth) {
        if (bleBluetooth == null) {
            return;
        }
        if (!blhm.containsKey(bleBluetooth.getDeviceKey())) {
            blhm.put(bleBluetooth.getDeviceKey(), bleBluetooth);
        }
    }

    public synchronized void removeBleBluetooth(BleBluetooth bleBluetooth) {
        if (bleBluetooth == null) {
            return;
        }
        if (blhm.containsKey(bleBluetooth.getDeviceKey())) {
            blhm.remove(bleBluetooth.getDeviceKey());
        }
    }

    public synchronized boolean isContainDevice(BleDevice bleDevice) {
        return bleDevice != null && blhm.containsKey(bleDevice.getKey());
    }

    public synchronized boolean isContainDevice(BluetoothDevice bluetoothDevice) {
        return bluetoothDevice != null && blhm.containsKey(bluetoothDevice.getName() + bluetoothDevice.getAddress());
    }

    public synchronized BleBluetooth getBleBluetooth(BleDevice bleDevice) {
        if (bleDevice != null) {
            if (blhm.containsKey(bleDevice.getKey())) {
                return blhm.get(bleDevice.getKey());
            }
        }
        return null;
    }

    public synchronized void disconnect(BleDevice bleDevice) {
        if (isContainDevice(bleDevice)) {
            getBleBluetooth(bleDevice).disconnect();
        }
    }

    public synchronized void disconnectAllDevice() {
        for (Map.Entry<String, BleBluetooth> e : blhm.entrySet()) {
            e.getValue().disconnect();
        }
        blhm.clear();
    }

    public synchronized void destroy() {
        for (Map.Entry<String, BleBluetooth> e : blhm.entrySet()) {
            e.getValue().destroy();
        }
        blhm.clear();
        for (Map.Entry<String, BleBluetooth> e : m.entrySet()) {
            e.getValue().destroy();
        }
        m.clear();
    }

    public synchronized List<BleBluetooth> getBleBluetoothList() {
        List<BleBluetooth> l = new ArrayList<>(blhm.values());
        Collections.sort(l, new Comparator<BleBluetooth>() {
            @Override
            public int compare(BleBluetooth lhs, BleBluetooth rhs) {
                return lhs.getDeviceKey().compareToIgnoreCase(rhs.getDeviceKey());
            }
        });
        return l;
    }

    public synchronized List<BleDevice> getDeviceList() {
        refreshConnectedDevice();
        List<BleDevice> l = new ArrayList<>();
        for (BleBluetooth b : getBleBluetoothList()) {
            if (b != null) {
                l.add(b.getDevice());
            }
        }
        return l;
    }

    public void refreshConnectedDevice() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            List<BleBluetooth> l = getBleBluetoothList();
            for (int i = 0; l != null && i < l.size(); i++) {
                BleBluetooth b = l.get(i);
                if (!BleManagerImpl.getInstance().isConnected(b.getDevice())) {
                    removeBleBluetooth(b);
                }
            }
        }
    }


}
