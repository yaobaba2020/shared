
package com.polaris.speedble.bluetooth;

import android.annotation.TargetApi;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import com.polaris.speedble.BleManagerImpl;
import com.polaris.speedble.callback.BleIndicateCallback;
import com.polaris.speedble.callback.BleMtuChangedCallback;
import com.polaris.speedble.callback.BleNotifyCallback;
import com.polaris.speedble.callback.BleReadCallback;
import com.polaris.speedble.callback.BleRssiCallback;
import com.polaris.speedble.callback.BleWriteCallback;
import com.polaris.speedble.data.BleMsg;
import com.polaris.speedble.data.BleWriteState;
import com.polaris.speedble.exception.GattException;
import com.polaris.speedble.exception.OtherException;
import com.polaris.speedble.exception.TimeoutException;

import java.util.UUID;


@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
public class BleConnector {

    private static final String UCCCD = "00002902-0000-1000-8000-00805f9b34fb";

    private BluetoothGatt bg;
    private BluetoothGattService gs;
    private BluetoothGattCharacteristic c;
    private BleBluetooth bb;
    private Handler h;

    BleConnector(BleBluetooth bleBluetooth) {
        this.bb = bleBluetooth;
        this.bg = bleBluetooth.getBluetoothGatt();
        this.h = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                switch (msg.what) {

                    case BleMsg.MSG_CHA_NOTIFY_START: {
                        BleNotifyCallback cb = (BleNotifyCallback) msg.obj;
                        if (cb != null)
                            cb.onNotifyFailure(new TimeoutException());
                        break;
                    }

                    case BleMsg.MSG_CHA_NOTIFY_RESULT: {
                        notifyMsgInit();

                        BleNotifyCallback cb = (BleNotifyCallback) msg.obj;
                        Bundle b = msg.getData();
                        int s = b.getInt(BleMsg.KEY_NOTIFY_BUNDLE_STATUS);
                        if (cb != null) {
                            if (s == BluetoothGatt.GATT_SUCCESS) {
                                cb.onNotifySuccess();
                            } else {
                                cb.onNotifyFailure(new GattException(s));
                            }
                        }
                        break;
                    }

                    case BleMsg.MSG_CHA_NOTIFY_DATA_CHANGE: {
                        BleNotifyCallback cb = (BleNotifyCallback) msg.obj;
                        Bundle b = msg.getData();
                        byte[] v = b.getByteArray(BleMsg.KEY_NOTIFY_BUNDLE_VALUE);
                        if (cb != null) {
                            cb.onCharacteristicChanged(v);
                        }
                        break;
                    }

                    case BleMsg.MSG_CHA_INDICATE_START: {
                        BleIndicateCallback cb = (BleIndicateCallback) msg.obj;
                        if (cb != null)
                            cb.onIndicateFailure(new TimeoutException());
                        break;
                    }

                    case BleMsg.MSG_CHA_INDICATE_RESULT: {
                        indicateMsgInit();

                        BleIndicateCallback cb = (BleIndicateCallback) msg.obj;
                        Bundle b = msg.getData();
                        int s = b.getInt(BleMsg.KEY_INDICATE_BUNDLE_STATUS);
                        if (cb != null) {
                            if (s == BluetoothGatt.GATT_SUCCESS) {
                                cb.onIndicateSuccess();
                            } else {
                                cb.onIndicateFailure(new GattException(s));
                            }
                        }
                        break;
                    }

                    case BleMsg.MSG_CHA_INDICATE_DATA_CHANGE: {
                        BleIndicateCallback cb = (BleIndicateCallback) msg.obj;
                        Bundle b = msg.getData();
                        byte[] v = b.getByteArray(BleMsg.KEY_INDICATE_BUNDLE_VALUE);
                        if (cb != null) {
                            cb.onCharacteristicChanged(v);
                        }
                        break;
                    }

                    case BleMsg.MSG_CHA_WRITE_START: {
                        BleWriteCallback cb = (BleWriteCallback) msg.obj;
                        if (cb != null) {
                            cb.onWriteFailure(new TimeoutException());
                        }
                        break;
                    }

                    case BleMsg.MSG_CHA_WRITE_RESULT: {
                        writeMsgInit();

                        BleWriteCallback cb = (BleWriteCallback) msg.obj;
                        Bundle b = msg.getData();
                        int s = b.getInt(BleMsg.KEY_WRITE_BUNDLE_STATUS);
                        byte[] v = b.getByteArray(BleMsg.KEY_WRITE_BUNDLE_VALUE);
                        if (cb != null) {
                            if (s == BluetoothGatt.GATT_SUCCESS) {
                                cb.onWriteSuccess(BleWriteState.DATA_WRITE_SINGLE, BleWriteState.DATA_WRITE_SINGLE, v);
                            } else {
                                cb.onWriteFailure(new GattException(s));
                            }
                        }
                        break;
                    }

                    case BleMsg.MSG_CHA_READ_START: {
                        BleReadCallback cb = (BleReadCallback) msg.obj;
                        if (cb != null)
                            cb.onReadFailure(new TimeoutException());
                        break;
                    }

                    case BleMsg.MSG_CHA_READ_RESULT: {
                        readMsgInit();

                        BleReadCallback cb = (BleReadCallback) msg.obj;
                        Bundle b = msg.getData();
                        int s = b.getInt(BleMsg.KEY_READ_BUNDLE_STATUS);
                        byte[] v = b.getByteArray(BleMsg.KEY_READ_BUNDLE_VALUE);
                        if (cb != null) {
                            if (s == BluetoothGatt.GATT_SUCCESS) {
                                cb.onReadSuccess(v);
                            } else {
                                cb.onReadFailure(new GattException(s));
                            }
                        }
                        break;
                    }

                    case BleMsg.MSG_READ_RSSI_START: {
                        BleRssiCallback cb = (BleRssiCallback) msg.obj;
                        if (cb != null)
                            cb.onRssiFailure(new TimeoutException());
                        break;
                    }

                    case BleMsg.MSG_READ_RSSI_RESULT: {
                        rssiMsgInit();

                        BleRssiCallback cb = (BleRssiCallback) msg.obj;
                        Bundle b = msg.getData();
                        int s = b.getInt(BleMsg.KEY_READ_RSSI_BUNDLE_STATUS);
                        int v = b.getInt(BleMsg.KEY_READ_RSSI_BUNDLE_VALUE);
                        if (cb != null) {
                            if (s == BluetoothGatt.GATT_SUCCESS) {
                                cb.onRssiSuccess(v);
                            } else {
                                cb.onRssiFailure(new GattException(s));
                            }
                        }
                        break;
                    }

                    case BleMsg.MSG_SET_MTU_START: {
                        BleMtuChangedCallback cb = (BleMtuChangedCallback) msg.obj;
                        if (cb != null)
                            cb.onSetMTUFailure(new TimeoutException());
                        break;
                    }

                    case BleMsg.MSG_SET_MTU_RESULT: {
                        mtuChangedMsgInit();

                        BleMtuChangedCallback cb = (BleMtuChangedCallback) msg.obj;
                        Bundle b = msg.getData();
                        int s = b.getInt(BleMsg.KEY_SET_MTU_BUNDLE_STATUS);
                        int v = b.getInt(BleMsg.KEY_SET_MTU_BUNDLE_VALUE);
                        if (cb != null) {
                            if (s == BluetoothGatt.GATT_SUCCESS) {
                                cb.onMtuChanged(v);
                            } else {
                                cb.onSetMTUFailure(new GattException(s));
                            }
                        }
                        break;
                    }
                }
            }
        };

    }

    private BleConnector withUUID(UUID serviceUUID, UUID characteristicUUID) {
        if (serviceUUID != null && bg != null) {
            gs = bg.getService(serviceUUID);
        }
        if (gs != null && characteristicUUID != null) {
            c = gs.getCharacteristic(characteristicUUID);
        }
        return this;
    }

    public BleConnector withUUIDString(String serviceUUID, String characteristicUUID) {
        return withUUID(formUUID(serviceUUID), formUUID(characteristicUUID));
    }

    private UUID formUUID(String uuid) {
        return uuid == null ? null : UUID.fromString(uuid);
    }


    /*------------------------------- main operation ----------------------------------- */


    /**
     * notify
     */
    public void enableCharacteristicNotify(BleNotifyCallback bleNotifyCallback, String uuid_notify,
                                           boolean userCharacteristicDescriptor) {
        if (c != null
                && (c.getProperties() | BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {

            hcncb(bleNotifyCallback, uuid_notify);
            setCharacteristicNotification(bg, c, userCharacteristicDescriptor, true, bleNotifyCallback);
        } else {
            if (bleNotifyCallback != null)
                bleNotifyCallback.onNotifyFailure(new OtherException("this characteristic not support notify!"));
        }
    }

    /**
     * stop notify
     */
    public boolean disableCharacteristicNotify(boolean useCharacteristicDescriptor) {
        if (c != null
                && (c.getProperties() | BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
            return setCharacteristicNotification(bg, c,
                    useCharacteristicDescriptor, false, null);
        } else {
            return false;
        }
    }

    /**
     * notify setting
     */
    private boolean setCharacteristicNotification(BluetoothGatt gatt,
                                                  BluetoothGattCharacteristic characteristic,
                                                  boolean useCharacteristicDescriptor,
                                                  boolean enable,
                                                  BleNotifyCallback bleNotifyCallback) {
        if (gatt == null || characteristic == null) {
            notifyMsgInit();
            if (bleNotifyCallback != null)
                bleNotifyCallback.onNotifyFailure(new OtherException("gatt or characteristic equal null"));
            return false;
        }

        boolean s1 = gatt.setCharacteristicNotification(characteristic, enable);
        if (!s1) {
            notifyMsgInit();
            if (bleNotifyCallback != null)
                bleNotifyCallback.onNotifyFailure(new OtherException("gatt setCharacteristicNotification fail"));
            return false;
        }

        BluetoothGattDescriptor d;
        if (useCharacteristicDescriptor) {
            d = characteristic.getDescriptor(characteristic.getUuid());
        } else {
            d = characteristic.getDescriptor(formUUID(UCCCD));
        }
        if (d == null) {
            notifyMsgInit();
            if (bleNotifyCallback != null)
                bleNotifyCallback.onNotifyFailure(new OtherException("descriptor equals null"));
            return false;
        } else {
            d.setValue(enable ? BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE :
                    BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE);
            boolean s2 = gatt.writeDescriptor(d);
            if (!s2) {
                notifyMsgInit();
                if (bleNotifyCallback != null)
                    bleNotifyCallback.onNotifyFailure(new OtherException("gatt writeDescriptor fail"));
            }
            return s2;
        }
    }

    /**
     * indicate
     */
    public void enableCharacteristicIndicate(BleIndicateCallback bleIndicateCallback, String uuid_indicate,
                                             boolean useCharacteristicDescriptor) {
        if (c != null
                && (c.getProperties() | BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
            hcicb(bleIndicateCallback, uuid_indicate);
            setCharacteristicIndication(bg, c,
                    useCharacteristicDescriptor, true, bleIndicateCallback);
        } else {
            if (bleIndicateCallback != null)
                bleIndicateCallback.onIndicateFailure(new OtherException("this characteristic not support indicate!"));
        }
    }


    /**
     * stop indicate
     */
    public boolean disableCharacteristicIndicate(boolean userCharacteristicDescriptor) {
        if (c != null
                && (c.getProperties() | BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
            return setCharacteristicIndication(bg, c,
                    userCharacteristicDescriptor, false, null);
        } else {
            return false;
        }
    }

    /**
     * indicate setting
     */
    private boolean setCharacteristicIndication(BluetoothGatt gatt,
                                                BluetoothGattCharacteristic characteristic,
                                                boolean useCharacteristicDescriptor,
                                                boolean enable,
                                                BleIndicateCallback bleIndicateCallback) {
        if (gatt == null || characteristic == null) {
            indicateMsgInit();
            if (bleIndicateCallback != null)
                bleIndicateCallback.onIndicateFailure(new OtherException("gatt or characteristic equal null"));
            return false;
        }

        boolean s1 = gatt.setCharacteristicNotification(characteristic, enable);
        if (!s1) {
            indicateMsgInit();
            if (bleIndicateCallback != null)
                bleIndicateCallback.onIndicateFailure(new OtherException("gatt setCharacteristicNotification fail"));
            return false;
        }

        BluetoothGattDescriptor d;
        if (useCharacteristicDescriptor) {
            d = characteristic.getDescriptor(characteristic.getUuid());
        } else {
            d = characteristic.getDescriptor(formUUID(UCCCD));
        }
        if (d == null) {
            indicateMsgInit();
            if (bleIndicateCallback != null)
                bleIndicateCallback.onIndicateFailure(new OtherException("descriptor equals null"));
            return false;
        } else {
            d.setValue(enable ? BluetoothGattDescriptor.ENABLE_INDICATION_VALUE :
                    BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE);
            boolean s2 = gatt.writeDescriptor(d);
            if (!s2) {
                indicateMsgInit();
                if (bleIndicateCallback != null)
                    bleIndicateCallback.onIndicateFailure(new OtherException("gatt writeDescriptor fail"));
            }
            return s2;
        }
    }

    /**
     * write
     */
    public void writeCharacteristic(byte[] data, BleWriteCallback bleWriteCallback, String uuid_write) {
        if (data == null || data.length <= 0) {
            if (bleWriteCallback != null)
                bleWriteCallback.onWriteFailure(new OtherException("the data to be written is empty"));
            return;
        }

        if (c == null
                || (c.getProperties() & (BluetoothGattCharacteristic.PROPERTY_WRITE | BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) == 0) {
            if (bleWriteCallback != null)
                bleWriteCallback.onWriteFailure(new OtherException("this characteristic not support write!"));
            return;
        }

        if (c.setValue(data)) {
            hcwcb(bleWriteCallback, uuid_write);
            if (!bg.writeCharacteristic(c)) {
                writeMsgInit();
                if (bleWriteCallback != null)
                    bleWriteCallback.onWriteFailure(new OtherException("gatt writeCharacteristic fail"));
            }
        } else {
            if (bleWriteCallback != null)
                bleWriteCallback.onWriteFailure(new OtherException("Updates the locally stored value of this characteristic fail"));
        }
    }

    /**
     * read
     */
    public void readCharacteristic(BleReadCallback bleReadCallback, String uuid_read) {
        if (c != null
                && (c.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) > 0) {

            hcrcb(bleReadCallback, uuid_read);
            if (!bg.readCharacteristic(c)) {
                readMsgInit();
                if (bleReadCallback != null)
                    bleReadCallback.onReadFailure(new OtherException("gatt readCharacteristic fail"));
            }
        } else {
            if (bleReadCallback != null)
                bleReadCallback.onReadFailure(new OtherException("this characteristic not support read!"));
        }
    }

    /**
     * rssi
     */
    public void readRemoteRssi(BleRssiCallback bleRssiCallback) {
        hrrcb(bleRssiCallback);
        if (!bg.readRemoteRssi()) {
            rssiMsgInit();
            if (bleRssiCallback != null)
                bleRssiCallback.onRssiFailure(new OtherException("gatt readRemoteRssi fail"));
        }
    }

    /**
     * set mtu
     */
    public void setMtu(int requiredMtu, BleMtuChangedCallback bleMtuChangedCallback) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            hsmcb(bleMtuChangedCallback);
            if (!bg.requestMtu(requiredMtu)) {
                mtuChangedMsgInit();
                if (bleMtuChangedCallback != null)
                    bleMtuChangedCallback.onSetMTUFailure(new OtherException("gatt requestMtu fail"));
            }
        } else {
            if (bleMtuChangedCallback != null)
                bleMtuChangedCallback.onSetMTUFailure(new OtherException("API level lower than 21"));
        }
    }

    /**
     * requestConnectionPriority
     *
     * @param connectionPriority Request a specific connection priority. Must be one of
     *                           {@link BluetoothGatt#CONNECTION_PRIORITY_BALANCED},
     *                           {@link BluetoothGatt#CONNECTION_PRIORITY_HIGH}
     *                           or {@link BluetoothGatt#CONNECTION_PRIORITY_LOW_POWER}.
     * @throws IllegalArgumentException If the parameters are outside of their
     *                                  specified range.
     */
    public boolean requestConnectionPriority(int connectionPriority) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            return bg.requestConnectionPriority(connectionPriority);
        }
        return false;
    }


    /**************************************** Handle call back ******************************************/

    /**
     * notify
     */
    private void hcncb(BleNotifyCallback cb,
                       String n) {
        if (cb != null) {
            notifyMsgInit();
            cb.setKey(n);
            cb.setHandler(h);
            bb.addNotifyCallback(n, cb);
            h.sendMessageDelayed(
                    h.obtainMessage(BleMsg.MSG_CHA_NOTIFY_START, cb),
                    BleManagerImpl.getInstance().getOperateTimeout());
        }
    }

    /**
     * indicate
     */
    private void hcicb(BleIndicateCallback cb,
                       String i) {
        if (cb != null) {
            indicateMsgInit();
            cb.setKey(i);
            cb.setHandler(h);
            bb.addIndicateCallback(i, cb);
            h.sendMessageDelayed(
                    h.obtainMessage(BleMsg.MSG_CHA_INDICATE_START, cb),
                    BleManagerImpl.getInstance().getOperateTimeout());
        }
    }

    /**
     * write
     */
    private void hcwcb(BleWriteCallback cb,
                       String w) {
        if (cb != null) {
            writeMsgInit();
            cb.setKey(w);
            cb.setHandler(h);
            bb.addWriteCallback(w, cb);
            h.sendMessageDelayed(
                    h.obtainMessage(BleMsg.MSG_CHA_WRITE_START, cb),
                    BleManagerImpl.getInstance().getOperateTimeout());
        }
    }

    /**
     * read
     */
    private void hcrcb(BleReadCallback cb,
                       String r) {
        if (cb != null) {
            readMsgInit();
            cb.setKey(r);
            cb.setHandler(h);
            bb.addReadCallback(r, cb);
            h.sendMessageDelayed(
                    h.obtainMessage(BleMsg.MSG_CHA_READ_START, cb),
                    BleManagerImpl.getInstance().getOperateTimeout());
        }
    }

    /**
     * rssi
     */
    private void hrrcb(BleRssiCallback cb) {
        if (cb != null) {
            rssiMsgInit();
            cb.setHandler(h);
            bb.addRssiCallback(cb);
            h.sendMessageDelayed(
                    h.obtainMessage(BleMsg.MSG_READ_RSSI_START, cb),
                    BleManagerImpl.getInstance().getOperateTimeout());
        }
    }

    /**
     * set mtu
     */
    private void hsmcb(BleMtuChangedCallback cb) {
        if (cb != null) {
            mtuChangedMsgInit();
            cb.setHandler(h);
            bb.addMtuChangedCallback(cb);
            h.sendMessageDelayed(
                    h.obtainMessage(BleMsg.MSG_SET_MTU_START, cb),
                    BleManagerImpl.getInstance().getOperateTimeout());
        }
    }

    public void notifyMsgInit() {
        h.removeMessages(BleMsg.MSG_CHA_NOTIFY_START);
    }

    public void indicateMsgInit() {
        h.removeMessages(BleMsg.MSG_CHA_INDICATE_START);
    }

    public void writeMsgInit() {
        h.removeMessages(BleMsg.MSG_CHA_WRITE_START);
    }

    public void readMsgInit() {
        h.removeMessages(BleMsg.MSG_CHA_READ_START);
    }

    public void rssiMsgInit() {
        h.removeMessages(BleMsg.MSG_READ_RSSI_START);
    }

    public void mtuChangedMsgInit() {
        h.removeMessages(BleMsg.MSG_SET_MTU_START);
    }

}
