#include <jni.h>
#include <string>

/**
 * http://www.pacifier.com/~mmead/jni/cs510jip/Native.cpp
 */

static jstring get_pkg(JNIEnv *env, jobject clazz, jobject activity) {
    jclass android_content_Context = env->GetObjectClass(activity);
    jmethodID midGetPackageName = env->GetMethodID(android_content_Context, "getPackageName",
                                                   "()Ljava/lang/String;");
    jstring packageName = (jstring) env->CallObjectMethod(activity, midGetPackageName);
    return packageName;
}

static void check_pkg(JNIEnv *env, jobject clazz, jobject activity) {
    jstring p1 = get_pkg(env, clazz, activity);
    std::string str_pkg = "com.speedble.blesample";
    jstring p2 = env->NewStringUTF(str_pkg.c_str());

//    jclass cls = env->GetObjectClass(clazz);
    jclass cls = env->FindClass("com/polaris/speedble/utils/HexUtil");
    jmethodID mid = env->GetStaticMethodID(cls, "equalsIgnoreCase",
                                           "(Ljava/lang/String;Ljava/lang/String;)Z");
    jboolean z = env->CallStaticBooleanMethod(cls, mid, p1, p2);

    jmethodID mid2 = env->GetStaticMethodID(cls, "check", "(III)Z");

    if (!z) {
        exit(0);
    }
}

static void check(JNIEnv *env, jobject clazz) {
    jclass cls = env->FindClass("com/polaris/speedble/utils/HexUtil");
    jmethodID mid2 = env->GetStaticMethodID(cls, "check", "(III)Z");

    jboolean z2 = env->CallStaticBooleanMethod(cls, mid2, 2020, 06, 15);

    if (!z2) {
        exit(0);
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_polaris_speedble_BleManagerImpl_stringFromJNI(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_init(
        JNIEnv *env,
        jobject obj,
        jobject app) {

//    // Get the class associated with this object
//    jclass cls = env->GetObjectClass(obj);
//
//    // Get method ID for the 'toString' method of this object's class
//    jmethodID mid = env->GetMethodID(cls, "toString", "()Ljava/lang/String;");
//
//    // Call the method, which returns a String
//    jstring s = (jstring)env->CallObjectMethod(obj, mid);

    check_pkg(env, obj, app);

    jclass cls = env->GetObjectClass(obj);
    // jclass cls = env->FindClass("com/polaris/speedble/BleManagerImpl");
    jmethodID mid = env->GetMethodID(cls, "i", "(Landroid/app/Application;)V");
    env->CallVoidMethod(obj, mid, app);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_getBluetoothManager(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "gbm", "()Landroid/bluetooth/BluetoothManager;");
    return (jobject) env->CallObjectMethod(obj, mid);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_getBluetoothAdapter(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "gba", "()Landroid/bluetooth/BluetoothAdapter;");
    return (jobject) env->CallObjectMethod(obj, mid);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_getScanRuleConfig(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "gsrc",
                                     "()Lcom/polaris/speedble/scan/BleScanRuleConfig;");
    return (jobject) env->CallObjectMethod(obj, mid);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_getMultipleBluetoothController(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "gmbc",
                                     "()Lcom/polaris/speedble/bluetooth/MultipleBluetoothController;");
    return (jobject) env->CallObjectMethod(obj, mid);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_initScanRule(
        JNIEnv *env,
        jobject obj,
        jobject config) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "isr",
                                     "(Lcom/polaris/speedble/scan/BleScanRuleConfig;)V");
    env->CallVoidMethod(obj, mid, config);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_polaris_speedble_BleManagerImpl_getMaxConnectCount(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "gmcc", "()I");
    return env->CallIntMethod(obj, mid);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_setMaxConnectCount(
        JNIEnv *env,
        jobject obj,
        jint count) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "smcc", "(I)Lcom/polaris/speedble/BleManager;");
    env->CallObjectMethod(obj, mid, count);

    return obj;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_polaris_speedble_BleManagerImpl_getOperateTimeout(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "got", "()I");
    return env->CallIntMethod(obj, mid);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_setOperateTimeout(
        JNIEnv *env,
        jobject obj,
        jint count) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "soto", "(I)Lcom/polaris/speedble/BleManager;");
    env->CallObjectMethod(obj, mid, count);

    return obj;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_polaris_speedble_BleManagerImpl_getReConnectCount(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "grcc", "()I");
    return env->CallIntMethod(obj, mid);
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_polaris_speedble_BleManagerImpl_getReConnectInterval(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "grci", "()J");
    return env->CallLongMethod(obj, mid);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_setReConnectCount(
        JNIEnv *env,
        jobject obj,
        jint count) {

    jclass cls = env->GetObjectClass(obj);
    jfieldID fid_DCRI = env->GetStaticFieldID(cls, "DCRI", "I");
    jint DCRI = env->GetStaticIntField(cls, fid_DCRI);
    jmethodID mid = env->GetMethodID(cls, "srcc", "(IJ)Lcom/polaris/speedble/BleManager;");
    env->CallObjectMethod(obj, mid, count, DCRI);

    return obj;
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_setReConnectCount2(
        JNIEnv *env,
        jobject obj,
        jint count,
        jlong interval) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "srcc", "(IJ)Lcom/polaris/speedble/BleManager;");
    env->CallObjectMethod(obj, mid, count, interval);

    return obj;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_polaris_speedble_BleManagerImpl_getSplitWriteNum(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "gswn", "()I");
    return env->CallIntMethod(obj, mid);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_setSplitWriteNum(
        JNIEnv *env,
        jobject obj,
        jint num) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "sswn", "(I)Lcom/polaris/speedble/BleManager;");
    env->CallObjectMethod(obj, mid, num);

    return obj;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_polaris_speedble_BleManagerImpl_getConnectOverTime(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "gcot", "()J");
    return env->CallLongMethod(obj, mid);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_setConnectOverTime(
        JNIEnv *env,
        jobject obj,
        jlong time) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "scot", "(J)Lcom/polaris/speedble/BleManager;");
    env->CallObjectMethod(obj, mid, time);

    return obj;
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_enableLog(
        JNIEnv *env,
        jobject obj,
        jboolean enable) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "el", "(Z)Lcom/polaris/speedble/BleManager;");
    env->CallObjectMethod(obj, mid, enable);

    return obj;
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_scan(
        JNIEnv *env,
        jobject obj,
        jobject callback) {

    check(env, obj);

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "s",
                                     "(Lcom/polaris/speedble/callback/BleScanCallback;)V");
    env->CallVoidMethod(obj, mid, callback);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_scanAndConnect(
        JNIEnv *env,
        jobject obj,
        jobject callback) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "sac",
                                     "(Lcom/polaris/speedble/callback/BleScanAndConnectCallback;)V");
    env->CallVoidMethod(obj, mid, callback);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_connect(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jobject callback) {

    check(env, obj);

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "c",
                                     "(Lcom/polaris/speedble/data/BleDevice;Lcom/polaris/speedble/callback/BleGattCallback;)Landroid/bluetooth/BluetoothGatt;");
    return env->CallObjectMethod(obj, mid, bleDevice, callback);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_connect2(
        JNIEnv *env,
        jobject obj,
        jstring mac,
        jobject callback) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "c2",
                                     "(Ljava/lang/String;Lcom/polaris/speedble/callback/BleGattCallback;)Landroid/bluetooth/BluetoothGatt;");
    return env->CallObjectMethod(obj, mid, mac, callback);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_cancelScan(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "cs", "()V");
    env->CallVoidMethod(obj, mid);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_notify(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jstring uuid_service,
        jstring uuid_notify,
        jobject callback) {

    check(env, obj);

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "n",
                                     "(Lcom/polaris/speedble/data/BleDevice;Ljava/lang/String;Ljava/lang/String;ZLcom/polaris/speedble/callback/BleNotifyCallback;)V");
    env->CallVoidMethod(obj, mid, bleDevice, uuid_service, uuid_notify, false, callback);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_notify2(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jstring uuid_service,
        jstring uuid_notify,
        jboolean useCharacteristicDescriptor,
        jobject callback) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "n",
                                     "(Lcom/polaris/speedble/data/BleDevice;Ljava/lang/String;Ljava/lang/String;ZLcom/polaris/speedble/callback/BleNotifyCallback;)V");
    env->CallVoidMethod(obj, mid, bleDevice, uuid_service, uuid_notify, useCharacteristicDescriptor,
                        callback);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_indicate(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jstring uuid_service,
        jstring uuid_indicate,
        jobject callback) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "in",
                                     "(Lcom/polaris/speedble/data/BleDevice;Ljava/lang/String;Ljava/lang/String;ZLcom/polaris/speedble/callback/BleIndicateCallback;)V");
    env->CallVoidMethod(obj, mid, bleDevice, uuid_service, uuid_indicate, false, callback);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_indicate2(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jstring uuid_service,
        jstring uuid_indicate,
        jboolean useCharacteristicDescriptor,
        jobject callback) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "in",
                                     "(Lcom/polaris/speedble/data/BleDevice;Ljava/lang/String;Ljava/lang/String;ZLcom/polaris/speedble/callback/BleIndicateCallback;)V");
    env->CallVoidMethod(obj, mid, bleDevice, uuid_service, uuid_indicate,
                        useCharacteristicDescriptor, callback);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_polaris_speedble_BleManagerImpl_stopNotify(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jstring uuid_service,
        jstring uuid_notify) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "sn",
                                     "(Lcom/polaris/speedble/data/BleDevice;Ljava/lang/String;Ljava/lang/String;Z)Z");
    return env->CallBooleanMethod(obj, mid, bleDevice, uuid_service, uuid_notify, false);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_polaris_speedble_BleManagerImpl_stopNotify2(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jstring uuid_service,
        jstring uuid_notify,
        jboolean useCharacteristicDescriptor) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "sn",
                                     "(Lcom/polaris/speedble/data/BleDevice;Ljava/lang/String;Ljava/lang/String;Z)Z");
    return env->CallBooleanMethod(obj, mid, bleDevice, uuid_service, uuid_notify,
                                  useCharacteristicDescriptor);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_polaris_speedble_BleManagerImpl_stopIndicate(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jstring uuid_service,
        jstring uuid_indicate) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "si",
                                     "(Lcom/polaris/speedble/data/BleDevice;Ljava/lang/String;Ljava/lang/String;Z)Z");
    return env->CallBooleanMethod(obj, mid, bleDevice, uuid_service, uuid_indicate, false);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_polaris_speedble_BleManagerImpl_stopIndicate2(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jstring uuid_service,
        jstring uuid_indicate,
        jboolean useCharacteristicDescriptor) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "si",
                                     "(Lcom/polaris/speedble/data/BleDevice;Ljava/lang/String;Ljava/lang/String;Z)Z");
    return env->CallBooleanMethod(obj, mid, bleDevice, uuid_service, uuid_indicate,
                                  useCharacteristicDescriptor);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_write(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jstring uuid_service,
        jstring uuid_write,
        jbyteArray data,
        jobject callback) {

    check(env, obj);

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "w",
                                     "(Lcom/polaris/speedble/data/BleDevice;Ljava/lang/String;Ljava/lang/String;[BZZJLcom/polaris/speedble/callback/BleWriteCallback;)V");
    jboolean z = true;
    jlong l = 0L;
    env->CallVoidMethod(obj, mid, bleDevice, uuid_service, uuid_write, data, z, z, l,
                        callback);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_write2(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jstring uuid_service,
        jstring uuid_write,
        jbyteArray data,
        jboolean split,
        jobject callback) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "w",
                                     "(Lcom/polaris/speedble/data/BleDevice;Ljava/lang/String;Ljava/lang/String;[BZZJLcom/polaris/speedble/callback/BleWriteCallback;)V");
    jboolean z = true;
    jlong l = 0L;
    env->CallVoidMethod(obj, mid, bleDevice, uuid_service, uuid_write, data, split, z, l,
                        callback);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_write3(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jstring uuid_service,
        jstring uuid_write,
        jbyteArray data,
        jboolean split,
        jboolean sendNextWhenLastSuccess,
        jlong intervalBetweenTwoPackage,
        jobject callback) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "w",
                                     "(Lcom/polaris/speedble/data/BleDevice;Ljava/lang/String;Ljava/lang/String;[BZZJLcom/polaris/speedble/callback/BleWriteCallback;)V");
    env->CallVoidMethod(obj, mid, bleDevice, uuid_service, uuid_write, data, split,
                        sendNextWhenLastSuccess, intervalBetweenTwoPackage, callback);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_read(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jstring uuid_service,
        jstring uuid_read,
        jobject callback) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "r",
                                     "(Lcom/polaris/speedble/data/BleDevice;Ljava/lang/String;Ljava/lang/String;Lcom/polaris/speedble/callback/BleReadCallback;)V");
    env->CallVoidMethod(obj, mid, bleDevice, uuid_service, uuid_read, callback);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_readRssi(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jobject callback) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "rr",
                                     "(Lcom/polaris/speedble/data/BleDevice;Lcom/polaris/speedble/callback/BleRssiCallback;)V");
    env->CallVoidMethod(obj, mid, bleDevice, callback);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_setMtu(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jint mtu,
        jobject callback) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "sm",
                                     "(Lcom/polaris/speedble/data/BleDevice;I;Lcom/polaris/speedble/callback/BleMtuChangedCallback;)V");
    env->CallVoidMethod(obj, mid, bleDevice, mtu, callback);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_polaris_speedble_BleManagerImpl_requestConnectionPriority(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jint p) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "rcp", "(Lcom/polaris/speedble/data/BleDevice;I)Z");
    return env->CallBooleanMethod(obj, mid, bleDevice, p);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_polaris_speedble_BleManagerImpl_isSupportBle(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "isb", "()Z");
    return env->CallBooleanMethod(obj, mid);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_enableBluetooth(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "eb", "()V");
    env->CallVoidMethod(obj, mid);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_disableBluetooth(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "db", "()V");
    env->CallVoidMethod(obj, mid);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_polaris_speedble_BleManagerImpl_isBlueEnable(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "ibe", "()Z");
    return env->CallBooleanMethod(obj, mid);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_convertBleDevice(
        JNIEnv *env,
        jobject obj,
        jobject device) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "cbd",
                                     "(Landroid/bluetooth/BluetoothDevice;)Lcom/polaris/speedble/data/BleDevice;");
    return env->CallObjectMethod(obj, mid, device);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_convertBleDeviceL(
        JNIEnv *env,
        jobject obj,
        jobject device) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "cbdl",
                                     "(Landroid/bluetooth/le/ScanResult;)Lcom/polaris/speedble/data/BleDevice;");
    return env->CallObjectMethod(obj, mid, device);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_getBleBluetooth(
        JNIEnv *env,
        jobject obj,
        jobject device) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "gbb",
                                     "(Lcom/polaris/speedble/data/BleDevice;)Lcom/polaris/speedble/bluetooth/BleBluetooth;");
    return env->CallObjectMethod(obj, mid, device);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_getBluetoothGatt(
        JNIEnv *env,
        jobject obj,
        jobject device) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "gbg",
                                     "(Lcom/polaris/speedble/data/BleDevice;)Landroid/bluetooth/BluetoothGatt;");
    return env->CallObjectMethod(obj, mid, device);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_getBluetoothGattServices(
        JNIEnv *env,
        jobject obj,
        jobject device) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "gbgs",
                                     "(Lcom/polaris/speedble/data/BleDevice;)Ljava/util/List;");
    return env->CallObjectMethod(obj, mid, device);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_getBluetoothGattCharacteristics(
        JNIEnv *env,
        jobject obj,
        jobject device) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "gbgc",
                                     "(Landroid/bluetooth/BluetoothGattService;)Ljava/util/List;");
    return env->CallObjectMethod(obj, mid, device);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_removeConnectGattCallback(
        JNIEnv *env,
        jobject obj,
        jobject device) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "rcgc", "(Lcom/polaris/speedble/data/BleDevice;)V");
    env->CallVoidMethod(obj, mid, device);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_removeRssiCallback(
        JNIEnv *env,
        jobject obj,
        jobject device) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "rrsc", "(Lcom/polaris/speedble/data/BleDevice;)V");
    env->CallVoidMethod(obj, mid, device);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_removeMtuChangedCallback(
        JNIEnv *env,
        jobject obj,
        jobject device) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "rmcc", "(Lcom/polaris/speedble/data/BleDevice;)V");
    env->CallVoidMethod(obj, mid, device);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_removeNotifyCallback(
        JNIEnv *env,
        jobject obj,
        jobject device,
        jstring s) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "rnc",
                                     "(Lcom/polaris/speedble/data/BleDevice;Ljava/lang/String;)V");
    env->CallVoidMethod(obj, mid, device, s);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_removeIndicateCallback(
        JNIEnv *env,
        jobject obj,
        jobject device,
        jstring s) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "ric",
                                     "(Lcom/polaris/speedble/data/BleDevice;Ljava/lang/String;)V");
    env->CallVoidMethod(obj, mid, device, s);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_removeWriteCallback(
        JNIEnv *env,
        jobject obj,
        jobject device,
        jstring s) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "rwc",
                                     "(Lcom/polaris/speedble/data/BleDevice;Ljava/lang/String;)V");
    env->CallVoidMethod(obj, mid, device, s);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_removeReadCallback(
        JNIEnv *env,
        jobject obj,
        jobject device,
        jstring s) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "rrdc",
                                     "(Lcom/polaris/speedble/data/BleDevice;Ljava/lang/String;)V");
    env->CallVoidMethod(obj, mid, device, s);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_clearCharacterCallback(
        JNIEnv *env,
        jobject obj,
        jobject device) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "ccc",
                                     "(Lcom/polaris/speedble/data/BleDevice;)V");
    env->CallVoidMethod(obj, mid, device);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_getScanSate(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "gss", "()Lcom/polaris/speedble/data/BleScanState;");
    return env->CallObjectMethod(obj, mid);
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_getAllConnectedDevice(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "gacd", "()Ljava/util/List;");
    return env->CallObjectMethod(obj, mid);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_polaris_speedble_BleManagerImpl_getConnectState(
        JNIEnv *env,
        jobject obj,
        jobject device) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "gcs", "(Lcom/polaris/speedble/data/BleDevice;)I");
    return env->CallIntMethod(obj, mid, device);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_polaris_speedble_BleManagerImpl_isConnected(
        JNIEnv *env,
        jobject obj,
        jobject device) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "ic", "(Lcom/polaris/speedble/data/BleDevice;)Z");
    return env->CallBooleanMethod(obj, mid, device);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_polaris_speedble_BleManagerImpl_isConnected2(
        JNIEnv *env,
        jobject obj,
        jstring mac) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "ic2", "(Ljava/lang/String;)Z");
    return env->CallBooleanMethod(obj, mid, mac);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_disconnect(
        JNIEnv *env,
        jobject obj,
        jobject device) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "d", "(Lcom/polaris/speedble/data/BleDevice;)V");
    env->CallVoidMethod(obj, mid, device);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_disconnectAllDevice(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "dad", "()V");
    env->CallVoidMethod(obj, mid);
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_destroy(
        JNIEnv *env,
        jobject obj) {

    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "dt", "()V");
    env->CallVoidMethod(obj, mid);
}

static jbyteArray makeWriteCommand(JNIEnv *env, jobject clazz,
                                   jint id,
                                   jbyteArray data) {
    std::string sof = "0xAA";
    jstring jstring_sof = env->NewStringUTF(sof.c_str());

    jint len = 1;
    if (data != NULL)
        len = env->GetArrayLength(data) + 1;

    jclass cls = env->FindClass("com/polaris/speedble/utils/HexUtil");

    jmethodID mid = env->GetStaticMethodID(cls, "mergeByteArrays", "([B[B)[B");
    jmethodID mid1 = env->GetStaticMethodID(cls, "mergeByteArray2", "([BB)[B");
    jmethodID mid2 = env->GetStaticMethodID(cls, "intToByteArray1", "(I)[B");
    jmethodID mid3 = env->GetStaticMethodID(cls, "hexStringToBytes", "(Ljava/lang/String;)[B");
    jmethodID mid4 = env->GetStaticMethodID(cls, "byteArrayXOR", "([B)B");

    jbyteArray jbytes_sof = static_cast<jbyteArray>(env->CallStaticObjectMethod(cls, mid3,
                                                                                jstring_sof));
    jbyteArray jbytes_bid = static_cast<jbyteArray>(env->CallStaticObjectMethod(cls, mid2, id));
    jbyteArray jbytes_len = static_cast<jbyteArray>(env->CallStaticObjectMethod(cls, mid2, len));

    jbyteArray jbytes_merged1 = static_cast<jbyteArray>(env->CallStaticObjectMethod(cls, mid,
                                                                                    jbytes_sof,
                                                                                    jbytes_len));
    jbyteArray jbytes_merged2 = static_cast<jbyteArray>(env->CallStaticObjectMethod(cls, mid,
                                                                                    jbytes_merged1,
                                                                                    jbytes_bid));
    jbyteArray jbytes_merged3 = static_cast<jbyteArray>(env->CallStaticObjectMethod(cls, mid,
                                                                                    jbytes_merged2,
                                                                                    data));

    jbyte jbytes_xsum = env->CallStaticByteMethod(cls, mid4, jbytes_merged3);
    jbyteArray jbytes_merged4 = static_cast<jbyteArray>(env->CallStaticObjectMethod(cls, mid1,
                                                                                    jbytes_merged3,
                                                                                    jbytes_xsum));

    return jbytes_merged4;
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_polaris_speedble_BleManagerImpl_writeLog(
        JNIEnv *env,
        jobject obj,
        jint id,
        jbyteArray data) {

    jbyteArray jbytes_to_write = makeWriteCommand(env, obj, id, data);

    return jbytes_to_write;
}

extern "C" JNIEXPORT void JNICALL
Java_com_polaris_speedble_BleManagerImpl_writePrivate(
        JNIEnv *env,
        jobject obj,
        jobject bleDevice,
        jstring uuid_service,
        jstring uuid_write,
        jint id,
        jbyteArray data,
        jobject callback) {

    jbyteArray jbytes_to_write = makeWriteCommand(env, obj, id, data);

    Java_com_polaris_speedble_BleManagerImpl_write(env, obj, bleDevice, uuid_service, uuid_write,
                                                   jbytes_to_write, callback);
}

//extern "C" JNIEXPORT jint JNICALL
//Java_com_polaris_speedble_BleManagerImpl_parseResponse(
//        JNIEnv *env,
//        jobject obj,
//        jbyteArray data) {
//
//    jint len = env->GetArrayLength(data);
//
//    jclass cls = env->FindClass("com/polaris/speedble/utils/HexUtil");
//
//    jmethodID mid = env->GetStaticMethodID(cls, "byteArraySub2", "([BII)[B");
//    jmethodID mid2 = env->GetStaticMethodID(cls, "byteArrayToInt", "([B)I");
//
//    if (len < 4) {
//        return -1;  // No data[]
//    }
//
//    jbyteArray jbytes = static_cast<jbyteArray>(env->CallStaticObjectMethod(cls, mid, data, 3, len - 3 - 1));
//    jint ji = env->CallStaticByteMethod(cls, mid2, jbytes);
//    jint result = static_cast<jint>(ji * 1.3456);
//
//    return result;
//}

extern "C" JNIEXPORT jobject JNICALL
Java_com_polaris_speedble_BleManagerImpl_parseResponse(
        JNIEnv *env,
        jobject obj,
        jbyteArray data) {

    jclass cls_ParseResult = env->FindClass("com/polaris/speedble/data/ParseResult");
    jclass cls_HexUtil = env->FindClass("com/polaris/speedble/utils/HexUtil");

    jmethodID mid_init = env->GetMethodID(cls_ParseResult, "<init>", "()V");
    jobject result = env->NewObject(cls_ParseResult, mid_init);
    jclass cls_ParseResult2 = env->GetObjectClass(result);

    jmethodID mid_setStMsgValid = env->GetMethodID(cls_ParseResult2, "setStMsgValid", "(Z)V");
    env->CallVoidMethod(cls_ParseResult2, mid_setStMsgValid, true);

    jmethodID mid_byteToInt = env->GetStaticMethodID(cls_HexUtil, "byteToInt", "(B)I");
    jmethodID mid_byteShiftLeft = env->GetStaticMethodID(cls_HexUtil, "byteShiftLeft", "(BI)I");

    jint data_0 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[0]);

    if (data_0 == 0xAA) {
        jmethodID mid_setStRxMsgId = env->GetMethodID(cls_ParseResult2, "setStRxMsgId", "(B)V");
        env->CallVoidMethod(cls_ParseResult2, mid_setStRxMsgId, data[2]);

        jint data_1 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[1]);
        jint data_2 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[2]);
        jint data_3 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[3]);
        jint data_4 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[4]);
        jint data_5 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[5]);
        jint data_6 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[6]);
        jint data_7 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[7]);
        jint data_8 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[8]);
        jint data_9 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[9]);
        jint data_10 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[10]);
        jint data_11 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[11]);
        jint data_12 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[12]);
        jint data_13 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[13]);
        jint data_14 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[14]);
        jint data_15 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[15]);
        jint data_16 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[16]);
        jint data_17 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[17]);
        jint data_18 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[18]);
        jint data_19 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[19]);
        jint data_20 = env->CallStaticIntMethod(cls_HexUtil, mid_byteToInt, data[20]);

        switch (data_2) {
            case 0x01:
                if (data_1 == 0x14) {
                    jmethodID mid_getStDataMsg1 = env->GetMethodID(cls_ParseResult2,
                                                                   "getStDataMsg1",
                                                                   "()Lcom/polaris/speedble/data/DataMsg1;");
                    jobject stDataMsg1 = env->CallObjectMethod(cls_ParseResult2, mid_getStDataMsg1);
                    jclass cls_StDataMsg1 = env->GetObjectClass(stDataMsg1);

                    jmethodID mid_setVar1 = env->GetMethodID(cls_StDataMsg1, "setVar1", "(I)V");
                    jmethodID mid_setVar2 = env->GetMethodID(cls_StDataMsg1, "setVar2", "(I)V");
                    jmethodID mid_setVar3 = env->GetMethodID(cls_StDataMsg1, "setVar3", "(I)V");
                    jmethodID mid_setVar4 = env->GetMethodID(cls_StDataMsg1, "setVar4", "(I)V");
                    jmethodID mid_setVar5 = env->GetMethodID(cls_StDataMsg1, "setVar5", "(I)V");
                    jmethodID mid_setVar6 = env->GetMethodID(cls_StDataMsg1, "setVar6", "(I)V");
                    jmethodID mid_setVar7 = env->GetMethodID(cls_StDataMsg1, "setVar7", "(I)V");
                    jmethodID mid_setVar8 = env->GetMethodID(cls_StDataMsg1, "setVar8", "(I)V");

                    jint var1 =
                            env->CallStaticIntMethod(cls_HexUtil, mid_byteShiftLeft, data[4], 8) |
                            data_3;
                    env->CallVoidMethod(cls_StDataMsg1, mid_setVar1, var1);
                    jint var2 =
                            env->CallStaticIntMethod(cls_HexUtil, mid_byteShiftLeft, data[6], 8) |
                            data_5;
                    env->CallVoidMethod(cls_StDataMsg1, mid_setVar2, var2);
                    env->CallVoidMethod(cls_StDataMsg1, mid_setVar3, data_7);
                    jint var4 =
                            env->CallStaticIntMethod(cls_HexUtil, mid_byteShiftLeft, data[9], 8) |
                            data_8;
                    env->CallVoidMethod(cls_StDataMsg1, mid_setVar4, var4);
                    jint var5 =
                            env->CallStaticIntMethod(cls_HexUtil, mid_byteShiftLeft, data[11], 8) |
                            data_10;
                    env->CallVoidMethod(cls_StDataMsg1, mid_setVar5, var5);
                    env->CallVoidMethod(cls_StDataMsg1, mid_setVar6, data_12);
                    jint var7 =
                            env->CallStaticIntMethod(cls_HexUtil, mid_byteShiftLeft, data[16], 8) |
                            env->CallStaticIntMethod(cls_HexUtil, mid_byteShiftLeft, data[15], 8) |
                            env->CallStaticIntMethod(cls_HexUtil, mid_byteShiftLeft, data[14], 8) |
                            data_13;
                    env->CallVoidMethod(cls_StDataMsg1, mid_setVar7, var7);
                    jint var8 =
                            env->CallStaticIntMethod(cls_HexUtil, mid_byteShiftLeft, data[20], 8) |
                            env->CallStaticIntMethod(cls_HexUtil, mid_byteShiftLeft, data[19], 8) |
                            env->CallStaticIntMethod(cls_HexUtil, mid_byteShiftLeft, data[18], 8) |
                            data_17;
                    env->CallVoidMethod(cls_StDataMsg1, mid_setVar8, var8);

                    jmethodID mid_setStDataMsg1 = env->GetMethodID(cls_ParseResult2,
                                                                   "setStDataMsg1",
                                                                   "(Lcom/polaris/speedble/data/DataMsg1;)V");
                    env->CallVoidMethod(cls_ParseResult2, mid_setStDataMsg1, stDataMsg1);
                } else {
                    env->CallVoidMethod(cls_ParseResult2, mid_setStMsgValid, false);
                }
                break;
            case 0x05:
                if (data_1 == 0x11) {
                    jmethodID mid_getStDataMsg2 = env->GetMethodID(cls_ParseResult2,
                                                                   "getStDataMsg2",
                                                                   "()Lcom/polaris/speedble/data/DataMsg2;");
                    jobject stDataMsg2 = env->CallObjectMethod(cls_ParseResult2, mid_getStDataMsg2);
                    jclass cls_StDataMsg2 = env->GetObjectClass(stDataMsg2);

                    jmethodID mid_setStatus = env->GetMethodID(cls_StDataMsg2, "mid_setStatus",
                                                               "(I)V");

                    jint status =
                            env->CallStaticIntMethod(cls_HexUtil, mid_byteShiftLeft, data[4], 8) |
                            data_3;
                    env->CallVoidMethod(cls_StDataMsg2, mid_setStatus, status);

                    // var9
                    jmethodID mid_getVar9 = env->GetMethodID(cls_StDataMsg2,
                                                             "getVar9",
                                                             "()Lcom/polaris/speedble/data/Msg2Parmeter;");
                    jobject var9 = env->CallObjectMethod(cls_StDataMsg2, mid_getVar9);
                    jclass cls_Msg2Parmeter_9 = env->GetObjectClass(var9);
                    jmethodID mid_setStatus_9 = env->GetMethodID(cls_Msg2Parmeter_9,
                                                                 "setStatus",
                                                                 "(B)V");
                    jmethodID mid_setValue_9 = env->GetMethodID(cls_Msg2Parmeter_9,
                                                                "setValue",
                                                                "(I)V");
                    env->CallVoidMethod(cls_Msg2Parmeter_9, mid_setStatus_9, data[5]);
                    env->CallVoidMethod(cls_Msg2Parmeter_9, mid_setValue_9, data_6);
                    jmethodID mid_setVar9 = env->GetMethodID(cls_StDataMsg2, "setVar9",
                                                             "(Lcom/polaris/speedble/data/Msg2Parmeter;)V");
                    env->CallVoidMethod(cls_StDataMsg2, mid_setVar9, var9);

                    // var10
                    jmethodID mid_getVar10 = env->GetMethodID(cls_StDataMsg2,
                                                              "getVar10",
                                                              "()Lcom/polaris/speedble/data/Msg2Parmeter;");
                    jobject var10 = env->CallObjectMethod(cls_StDataMsg2, mid_getVar10);
                    jclass cls_Msg2Parmeter_10 = env->GetObjectClass(var9);
                    jmethodID mid_setStatus_10 = env->GetMethodID(cls_Msg2Parmeter_10,
                                                                  "setStatus",
                                                                  "(B)V");
                    jmethodID mid_setValue_10 = env->GetMethodID(cls_Msg2Parmeter_10,
                                                                 "setValue",
                                                                 "(I)V");
                    env->CallVoidMethod(cls_Msg2Parmeter_10, mid_setStatus_10, data[7]);
                    env->CallVoidMethod(cls_Msg2Parmeter_10, mid_setValue_10, data_8);
                    jmethodID mid_setVar10 = env->GetMethodID(cls_StDataMsg2, "setVar10",
                                                              "(Lcom/polaris/speedble/data/Msg2Parmeter;)V");
                    env->CallVoidMethod(cls_StDataMsg2, mid_setVar10, var10);

                    // var11
                    jmethodID mid_getVar11 = env->GetMethodID(cls_StDataMsg2,
                                                              "getVar11",
                                                              "()Lcom/polaris/speedble/data/Msg2Parmeter;");
                    jobject var11 = env->CallObjectMethod(cls_StDataMsg2, mid_getVar11);
                    jclass cls_Msg2Parmeter_11 = env->GetObjectClass(var11);
                    jmethodID mid_setStatus_11 = env->GetMethodID(cls_Msg2Parmeter_11,
                                                                  "setStatus",
                                                                  "(B)V");
                    jmethodID mid_setValue_11 = env->GetMethodID(cls_Msg2Parmeter_11,
                                                                 "setValue",
                                                                 "(I)V");
                    env->CallVoidMethod(cls_Msg2Parmeter_9, mid_setStatus_11, data[9]);
                    env->CallVoidMethod(cls_Msg2Parmeter_9, mid_setValue_11, data_10);
                    jmethodID mid_setVar11 = env->GetMethodID(cls_StDataMsg2, "setVar11",
                                                              "(Lcom/polaris/speedble/data/Msg2Parmeter;)V");
                    env->CallVoidMethod(cls_StDataMsg2, mid_setVar11, var11);

                    // var12
                    jmethodID mid_getVar12 = env->GetMethodID(cls_StDataMsg2,
                                                              "getVar12",
                                                              "()Lcom/polaris/speedble/data/Msg2Parmeter;");
                    jobject var12 = env->CallObjectMethod(cls_StDataMsg2, mid_getVar12);
                    jclass cls_Msg2Parmeter_12 = env->GetObjectClass(var12);
                    jmethodID mid_setStatus_12 = env->GetMethodID(cls_Msg2Parmeter_12,
                                                                  "setStatus",
                                                                  "(B)V");
                    jmethodID mid_setValue_12 = env->GetMethodID(cls_Msg2Parmeter_12,
                                                                 "setValue",
                                                                 "(I)V");
                    env->CallVoidMethod(cls_Msg2Parmeter_12, mid_setStatus_12, data[11]);
                    jint val12 =
                            env->CallStaticIntMethod(cls_HexUtil, mid_byteShiftLeft, data[13], 8) |
                            data_12;
                    env->CallVoidMethod(cls_Msg2Parmeter_12, mid_setValue_12, val12);
                    jmethodID mid_setVar12 = env->GetMethodID(cls_StDataMsg2, "setVar12",
                                                              "(Lcom/polaris/speedble/data/Msg2Parmeter;)V");
                    env->CallVoidMethod(cls_StDataMsg2, mid_setVar12, var12);

                    // var13
                    jmethodID mid_getVar13 = env->GetMethodID(cls_StDataMsg2,
                                                              "getVar13",
                                                              "()Lcom/polaris/speedble/data/Msg2Parmeter;");
                    jobject var13 = env->CallObjectMethod(cls_StDataMsg2, mid_getVar13);
                    jclass cls_Msg2Parmeter_13 = env->GetObjectClass(var13);
                    jmethodID mid_setStatus_13 = env->GetMethodID(cls_Msg2Parmeter_13,
                                                                  "setStatus",
                                                                  "(B)V");
                    jmethodID mid_setValue_13 = env->GetMethodID(cls_Msg2Parmeter_13,
                                                                 "setValue",
                                                                 "(I)V");
                    env->CallVoidMethod(cls_Msg2Parmeter_13, mid_setStatus_13, data[14]);
                    env->CallVoidMethod(cls_Msg2Parmeter_13, mid_setValue_13, data_15);
                    jmethodID mid_setVar13 = env->GetMethodID(cls_StDataMsg2, "setVar13",
                                                              "(Lcom/polaris/speedble/data/Msg2Parmeter;)V");
                    env->CallVoidMethod(cls_StDataMsg2, mid_setVar13, var13);

                    jmethodID mid_setStDataMsg2 = env->GetMethodID(cls_ParseResult2,
                                                                   "setStDataMsg2",
                                                                   "(Lcom/polaris/speedble/data/DataMsg2;)V");
                    env->CallVoidMethod(cls_ParseResult2, mid_setStDataMsg2, stDataMsg2);
                } else {
                    env->CallVoidMethod(cls_ParseResult2, mid_setStMsgValid, false);
                }
                break;
            default:
                env->CallVoidMethod(cls_ParseResult2, mid_setStMsgValid, false);
                break;
        }
    } else {
        env->CallVoidMethod(cls_ParseResult2, mid_setStMsgValid, false);
    }

    return result;
}