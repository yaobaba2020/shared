package com.speedble.demo.comm;


import com.polaris.speedble.data.BleDevice;

public interface Observer {

    void disConnected(BleDevice bleDevice);
}
