package com.speedble.demo.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.View;

import com.polaris.speedble.BleManagerImpl;
import com.polaris.speedble.data.BleDevice;
import com.speedble.demo.R;

import org.byteam.superadapter.SuperAdapter;
import org.byteam.superadapter.SuperViewHolder;

import java.util.List;

public class ValueAdapter extends SuperAdapter<String> {
    public ValueAdapter(Context context, List<String> items, int layoutResId) {
        super(context, items, layoutResId);
    }

    @Override
    public void onBind(SuperViewHolder holder, int viewType, int layoutPosition, String item) {
        int newPosition = (layoutPosition % 3) * 5  + layoutPosition / 3;
        String newItem = getItem(newPosition);
        if (item != null) {
            holder.setText(R.id.txt_label, String.format("Value %d: ", newPosition + 1));
            holder.setText(R.id.txt_value, newItem);
        }
    }
}