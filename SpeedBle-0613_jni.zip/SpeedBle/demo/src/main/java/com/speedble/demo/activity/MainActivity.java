package com.speedble.demo.activity;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.polaris.speedble.BleManagerImpl;
import com.polaris.speedble.callback.BleGattCallback;
import com.polaris.speedble.callback.BleIndicateCallback;
import com.polaris.speedble.callback.BleMtuChangedCallback;
import com.polaris.speedble.callback.BleNotifyCallback;
import com.polaris.speedble.callback.BleReadCallback;
import com.polaris.speedble.callback.BleRssiCallback;
import com.polaris.speedble.callback.BleScanCallback;
import com.polaris.speedble.callback.BleWriteCallback;
import com.polaris.speedble.data.BleDevice;
import com.polaris.speedble.data.DataStructure;
import com.polaris.speedble.exception.BleException;
import com.polaris.speedble.scan.BleScanRuleConfig;
import com.polaris.speedble.utils.BluetoothRxMessageParser;
import com.polaris.speedble.utils.HexUtil;
import com.speedble.demo.Global;
import com.speedble.demo.R;
import com.speedble.demo.adapter.DeviceAdapter;
import com.speedble.demo.adapter.ValueAdapter;
import com.speedble.demo.comm.Observer;
import com.speedble.demo.comm.ObserverManager;
import com.speedble.demo.preference.TinyDB;

import org.byteam.superadapter.OnItemClickListener;

import java.util.ArrayList;
import java.util.List;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
public class MainActivity extends AppCompatActivity implements View.OnClickListener, Observer {

    private static final String TAG = MainActivity.class.getSimpleName();
    private static final int REQUEST_CODE_OPEN_GPS = 1;
    private static final int REQUEST_CODE_PERMISSION_LOCATION = 2;

    private RecyclerView recyclerDevice;
    private ImageView imgLoading;
    private Button btnScan;
    private Button btnConnect;
    private Button btnDisconnect;
    private RecyclerView recyclerValue;
    private Button btnStartRead;
    private Button btnStopRead;
    private Button btnCommand1;
    private Button btnCommand2;
    private TextView txtLog;
    private TextView txtLog2;
    private EditText editFilter;
    private TextView txtValue1;
    private TextView txtValue2;
    private TextView txtValue3;
    private TextView txtValue4;
    private TextView txtValue5;
    private CheckBox check1;
    private CheckBox check2;
    private CheckBox check3;
    private CheckBox check4;
    private CheckBox check5;
    private CheckBox check6;
    private CheckBox check7;
    private CheckBox check8;
    private CheckBox check9;
    private CheckBox check10;
    private CheckBox check11;
    private CheckBox check12;
    private CheckBox check13;
    private CheckBox check14;
    private CheckBox check15;

    private DeviceAdapter mDeviceAdapter;
    private ValueAdapter mValueAdapter;
    private List<BleDevice> deviceList = new ArrayList<>();
    private List<BleDevice> deviceListFiltered = new ArrayList<>();
    private List<String> valueList = new ArrayList<>();

    private Animation operatingAnim;
    private ProgressDialog progressDialog;
    private TinyDB tinyDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait...");
        operatingAnim = AnimationUtils.loadAnimation(this, R.anim.rotate);
        operatingAnim.setInterpolator(new LinearInterpolator());

        tinyDB = new TinyDB(this);

        initView();

        BleManagerImpl.getInstance().init(getApplication());
        BleManagerImpl.getInstance()
                .enableLog(true)
                .setReConnectCount2(1, 5000)
                .setConnectOverTime(20000)
                .setOperateTimeout(5000);

        ObserverManager.getInstance().addObserver(this);

        // scan and auto connect when app is opened
        checkPermissions();
    }

    private void initView() {
        recyclerDevice = findViewById(R.id.recycler_device);
        imgLoading = findViewById(R.id.img_loading);
        btnScan = findViewById(R.id.btn_scan);
        btnConnect = findViewById(R.id.btn_connect);
        btnDisconnect = findViewById(R.id.btn_disconnect);
        recyclerValue = findViewById(R.id.recycler_value);
        btnStartRead = findViewById(R.id.btn_start_read);
        btnStopRead = findViewById(R.id.btn_stop_read);
        btnCommand1 = findViewById(R.id.btn_command_1);
        btnCommand2 = findViewById(R.id.btn_command_2);
        txtLog = findViewById(R.id.txt_log);
        txtLog2 = findViewById(R.id.txt_log_2);

        editFilter = findViewById(R.id.edit_filter);
        txtValue1 = findViewById(R.id.txt_value1);
        txtValue2 = findViewById(R.id.txt_value2);
        txtValue3 = findViewById(R.id.txt_value3);
        txtValue4 = findViewById(R.id.txt_value4);
        txtValue5 = findViewById(R.id.txt_value5);
        check1 = findViewById(R.id.check1);
        check2 = findViewById(R.id.check2);
        check3 = findViewById(R.id.check3);
        check4 = findViewById(R.id.check4);
        check5 = findViewById(R.id.check5);
        check6 = findViewById(R.id.check6);
        check7 = findViewById(R.id.check7);
        check8 = findViewById(R.id.check8);
        check9 = findViewById(R.id.check9);
        check10 = findViewById(R.id.check10);
        check11 = findViewById(R.id.check11);
        check12 = findViewById(R.id.check12);
        check13 = findViewById(R.id.check13);
        check14 = findViewById(R.id.check14);
        check15 = findViewById(R.id.check15);

        recyclerDevice.setLayoutManager(new LinearLayoutManager(this));
        mDeviceAdapter = new DeviceAdapter(this, deviceListFiltered, R.layout.item_device);
        mDeviceAdapter.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(View itemView, int viewType, int position) {
                // mDeviceAdapter.setSelectedPosition(position);
                // mDeviceAdapter.notifyDataSetChanged();

                BleDevice bleDevice = mDeviceAdapter.getItem(position);
                if (!BleManagerImpl.getInstance().isConnected(bleDevice)) {
                    BleManagerImpl.getInstance().cancelScan();
                    connect(bleDevice);
                }
            }
        });
        recyclerDevice.setAdapter(mDeviceAdapter);

        recyclerValue.setLayoutManager(new GridLayoutManager(this, 3, LinearLayoutManager.VERTICAL, false));
        mValueAdapter = new ValueAdapter(this, valueList, R.layout.item_value);
        recyclerValue.setAdapter(mValueAdapter);
        for (int i = 0; i < 15; i++)
            mValueAdapter.add("");

        editFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                deviceListFiltered = new ArrayList<>();
                for (BleDevice device : deviceList) {
                    String query = editFilter.getText().toString();
                    if (TextUtils.isEmpty(query) || (!TextUtils.isEmpty(device.getName()) && device.getName().toLowerCase().contains(query)))
                        deviceListFiltered.add(device);
                }
                mDeviceAdapter.notifyDataSetChanged();
            }

            @Override
            public void afterTextChanged(Editable s) {
                deviceListFiltered = new ArrayList<>();
                for (BleDevice device : deviceList) {
                    String query = editFilter.getText().toString();
                    if (TextUtils.isEmpty(query) || (!TextUtils.isEmpty(device.getName()) && device.getName().toLowerCase().contains(query)))
                        deviceListFiltered.add(device);
                }
                mDeviceAdapter.notifyDataSetChanged();
            }
        });

        btnScan.setOnClickListener(this);
        btnConnect.setOnClickListener(this);
        btnDisconnect.setOnClickListener(this);
        btnStartRead.setOnClickListener(this);
        btnStopRead.setOnClickListener(this);
        btnCommand1.setOnClickListener(this);
        btnCommand2.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();

        showConnectedDevice();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        BleManagerImpl.getInstance().clearCharacterCallback(Global.bleDevice);
        ObserverManager.getInstance().deleteObserver(this);

        BleManagerImpl.getInstance().disconnectAllDevice();
        BleManagerImpl.getInstance().destroy();
    }

    @Override
    public void disConnected(BleDevice device) {
        if (device != null && Global.bleDevice != null && device.getKey().equals(Global.bleDevice.getKey())) {
            showConnectedDevice();
        }
    }

    @Override
    public void onClick(View v) {
        int selected = mDeviceAdapter.getSelectedPosition();

        switch (v.getId()) {
            case R.id.btn_scan:
                if (btnScan.getText().equals(getString(R.string.start_scan))) {
                    // btnScan.setText(R.string.stop_scan);
                    checkPermissions();
                } else {
                    // btnScan.setText(R.string.start_scan);
                    BleManagerImpl.getInstance().cancelScan();
                }
                break;
            case R.id.btn_connect:
                if (selected < mDeviceAdapter.getItemCount()) {
                    BleDevice bleDevice = mDeviceAdapter.getItem(selected);
                    if (!BleManagerImpl.getInstance().isConnected(bleDevice)) {
                        BleManagerImpl.getInstance().cancelScan();
                        connect(bleDevice);
                    }
                }
                break;
            case R.id.btn_disconnect:
                if (selected < mDeviceAdapter.getItemCount()) {
                    BleDevice bleDevice = mDeviceAdapter.getItem(selected);
                    if (BleManagerImpl.getInstance().isConnected(bleDevice)) {
                        BleManagerImpl.getInstance().disconnect(bleDevice);
                    }
                }
                break;
            case R.id.btn_start_read:
                registerNotifyCallback();
                break;
            case R.id.btn_stop_read:
                unregisterNotifyCallback();
                break;
            case R.id.btn_command_1:
                write(1, "");
                // byte[] bytes1 = HexUtil.hexStringToBytes("0xAA1401030405060708090A0B0C0D0E0F1011121314");
                // onResponse(bytes1, BluetoothRxMessageParser.parse(bytes1));
                break;
            case R.id.btn_command_2:
                write(2, "1F0000");
                // byte[] bytes2 = HexUtil.hexStringToBytes("0xAA1105A3A4A5A6A7A8A9AAABACADAEAFB0B1B2B3B4");
                // onResponse(bytes2, BluetoothRxMessageParser.parse(bytes2));
                break;
        }
    }

    private void showConnectedDevice() {
        deviceList = BleManagerImpl.getInstance().getAllConnectedDevice();
        deviceListFiltered = new ArrayList<>();
        for (BleDevice device : deviceList) {
            String query = editFilter.getText().toString();
            if (TextUtils.isEmpty(query) || (!TextUtils.isEmpty(device.getName()) && device.getName().toLowerCase().contains(query)))
                deviceListFiltered.add(device);
        }
        mDeviceAdapter.notifyDataSetChanged();
    }

    private void setScanRule() {
        BleScanRuleConfig scanRuleConfig = new BleScanRuleConfig.Builder()
                // .setServiceUuids(serviceUuids)       // 只扫描指定的服务的设备，可选
                // .setDeviceName(true, names)          // 只扫描指定广播名的设备，可选
                // .setDeviceMac(mac)                   // 只扫描指定mac的设备，可选
                .setAutoConnect(true)                  // 连接时的autoConnect参数，可选，默认false
                .setScanTimeOut(10000)                  // 扫描超时时间，可选，默认10秒
                .build();
        BleManagerImpl.getInstance().initScanRule(scanRuleConfig);
    }

    private void startScan() {
        BleManagerImpl.getInstance().scan(new BleScanCallback() {
            @Override
            public void onScanStarted(boolean success) {
                mDeviceAdapter.clear();
                imgLoading.startAnimation(operatingAnim);
                imgLoading.setVisibility(View.VISIBLE);
                btnScan.setText(R.string.stop_scan);
            }

            @Override
            public void onLeScan(BleDevice bleDevice) {
                super.onLeScan(bleDevice);
            }

            @Override
            public void onScanning(BleDevice bleDevice) {
                deviceList.add(bleDevice);
                String query = editFilter.getText().toString();
                if (TextUtils.isEmpty(query) || (!TextUtils.isEmpty(bleDevice.getName()) && bleDevice.getName().contains(query))) {
                    mDeviceAdapter.add(bleDevice);
                    mDeviceAdapter.notifyDataSetChanged();
                }
                BleDevice paired = tinyDB.getObject("BLE_PAIRED", BleDevice.class);
                if (paired != null && bleDevice.getMac().equals(paired.getMac())) {
                    if (!BleManagerImpl.getInstance().isConnected(bleDevice)) {
                        BleManagerImpl.getInstance().cancelScan();
                        connect(bleDevice);
                    }
                }
            }

            @Override
            public void onScanFinished(List<BleDevice> scanResultList) {
                imgLoading.clearAnimation();
                imgLoading.setVisibility(View.INVISIBLE);
                btnScan.setText(R.string.start_scan);
            }
        });
    }

    private void connect(final BleDevice bleDevice) {
        if (Global.bleDevice != null && BleManagerImpl.getInstance().isConnected(Global.bleDevice)) {
            BleManagerImpl.getInstance().disconnect(Global.bleDevice);
        }

        Global.bleDevice = null;
        Global.bluetoothGattService = null;
        Global.characteristicWrite = null;
        Global.characteristicRead = null;
        Global.characteristicNotify = null;
        Global.characteristicIndicate = null;

        BleManagerImpl.getInstance().connect(bleDevice, new BleGattCallback() {
            @Override
            public void onStartConnect() {
                progressDialog.show();
                mDeviceAdapter.notifyDataSetChanged();
            }

            @Override
            public void onConnectFail(BleDevice bleDevice, BleException exception) {
                imgLoading.clearAnimation();
                imgLoading.setVisibility(View.INVISIBLE);
                btnScan.setText(R.string.start_scan);
                progressDialog.dismiss();
                mDeviceAdapter.notifyDataSetChanged();
                Toast.makeText(MainActivity.this, getString(R.string.connect_fail), Toast.LENGTH_LONG).show();
            }

            @Override
            public void onConnectSuccess(BleDevice bleDevice, BluetoothGatt gatt, int status) {
                progressDialog.dismiss();
                // mDeviceAdapter.add(bleDevice);
                mDeviceAdapter.notifyDataSetChanged();

                recyclerDevice.setVisibility(View.INVISIBLE);

                tinyDB.putObject("BLE_PAIRED", bleDevice);
                Global.bleDevice = bleDevice;
                // BluetoothGatt gatt = BleManagerImpl.getInstance().getBluetoothGatt(bleDevice);
                List<BluetoothGattService> serviceList = gatt.getServices();
                Global.bluetoothGattService = serviceList.get(serviceList.size() - 1);
                for (BluetoothGattCharacteristic characteristic : Global.bluetoothGattService.getCharacteristics()) {
                    int properties = characteristic.getProperties();
                    if ((properties & BluetoothGattCharacteristic.PROPERTY_READ) > 0) {
                        Global.characteristicRead = characteristic;
                    }
                    if ((properties & BluetoothGattCharacteristic.PROPERTY_WRITE) > 0
                            || (properties & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) > 0) {
                        Global.characteristicWrite = characteristic;
                    }
                    if ((properties & BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
                        Global.characteristicNotify = characteristic;
                    }
                    if ((properties & BluetoothGattCharacteristic.PROPERTY_INDICATE) > 0) {
                        Global.characteristicIndicate = characteristic;
                    }
                }
            }

            @Override
            public void onDisConnected(boolean isActiveDisConnected, BleDevice bleDevice, BluetoothGatt gatt, int status) {
                progressDialog.dismiss();

                // mDeviceAdapter.remove(bleDevice);
                mDeviceAdapter.notifyDataSetChanged();

                if (isActiveDisConnected) {
                    Toast.makeText(MainActivity.this, getString(R.string.active_disconnected), Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, getString(R.string.disconnected), Toast.LENGTH_LONG).show();
                    ObserverManager.getInstance().notifyObserver(bleDevice);
                }

            }
        });
    }

    private void readRssi(BleDevice bleDevice) {
        BleManagerImpl.getInstance().readRssi(bleDevice, new BleRssiCallback() {
            @Override
            public void onRssiFailure(BleException exception) {
                Log.i(TAG, "onRssiFailure" + exception.toString());
            }

            @Override
            public void onRssiSuccess(int rssi) {
                Log.i(TAG, "onRssiSuccess: " + rssi);
            }
        });
    }

    private void setMtu(BleDevice bleDevice, int mtu) {
        BleManagerImpl.getInstance().setMtu(bleDevice, mtu, new BleMtuChangedCallback() {
            @Override
            public void onSetMTUFailure(BleException exception) {
                Log.i(TAG, "onsetMTUFailure" + exception.toString());
            }

            @Override
            public void onMtuChanged(int mtu) {
                Log.i(TAG, "onMtuChanged: " + mtu);
            }
        });
    }

    @Override
    public final void onRequestPermissionsResult(int requestCode,
                                                 @NonNull String[] permissions,
                                                 @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_CODE_PERMISSION_LOCATION:
                if (grantResults.length > 0) {
                    for (int i = 0; i < grantResults.length; i++) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                            onPermissionGranted(permissions[i]);
                        }
                    }
                }
                break;
        }
    }

    private void checkPermissions() {
        recyclerDevice.setVisibility(View.VISIBLE);

        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        try {
            if (!bluetoothAdapter.isEnabled()) {
                Toast.makeText(this, getString(R.string.please_open_blue), Toast.LENGTH_LONG).show();
                return;
            }

            String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION};
            List<String> permissionDeniedList = new ArrayList<>();
            for (String permission : permissions) {
                int permissionCheck = ContextCompat.checkSelfPermission(this, permission);
                if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                    onPermissionGranted(permission);
                } else {
                    permissionDeniedList.add(permission);
                }
            }
            if (!permissionDeniedList.isEmpty()) {
                String[] deniedPermissions = permissionDeniedList.toArray(new String[permissionDeniedList.size()]);
                ActivityCompat.requestPermissions(this, deniedPermissions, REQUEST_CODE_PERMISSION_LOCATION);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Your device doesn't support Bluetooth.", Toast.LENGTH_LONG).show();
        }
    }

    private void onPermissionGranted(String permission) {
        switch (permission) {
            case Manifest.permission.ACCESS_FINE_LOCATION:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !checkGPSIsOpen()) {
                    new AlertDialog.Builder(this)
                            .setTitle(R.string.notifyTitle)
                            .setMessage(R.string.gpsNotifyMsg)
                            .setNegativeButton(R.string.cancel,
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            finish();
                                        }
                                    })
                            .setPositiveButton(R.string.setting,
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                                            startActivityForResult(intent, REQUEST_CODE_OPEN_GPS);
                                        }
                                    })

                            .setCancelable(false)
                            .show();
                } else {
                    setScanRule();
                    startScan();
                }
                break;
        }
    }

    private boolean checkGPSIsOpen() {
        LocationManager locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        if (locationManager == null)
            return false;
        return locationManager.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_OPEN_GPS) {
            if (checkGPSIsOpen()) {
                setScanRule();
                startScan();
            }
        }
    }


    // ++++++++++++++++++++++++ PROPERTY_WRITE | PROPERTY_WRITE_NO_RESPONSE ++++++++++++++++++++++++


    public void write(int id, String hex) {
        // if (TextUtils.isEmpty(hex)) return;

        // Test
        byte[] bytes = BleManagerImpl.getInstance().writeLog(id, HexUtil.hexStringToBytes(hex));
        // log(HexUtil.encodeHexStr(bytes, false));
        txtLog.setText(">-- " + HexUtil.encodeHexStr(bytes, false));

        final BleDevice bleDevice = Global.bleDevice;
        final BluetoothGattCharacteristic characteristic = Global.characteristicWrite;
        if (bleDevice != null && characteristic != null) {
            int prop = characteristic.getProperties();
            if ((prop & BluetoothGattCharacteristic.PROPERTY_WRITE) > 0
                    || (prop & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) > 0) {
                BleManagerImpl.getInstance().writePrivate(
                        bleDevice,
                        characteristic.getService().getUuid().toString(),
                        characteristic.getUuid().toString(),
                        id,
                        HexUtil.hexStringToBytes(hex),
                        new BleWriteCallback() {

                            @Override
                            public void onWriteSuccess(final int current, final int total, final byte[] justWrite) {
                                log("--> current: " + current
                                        + " total: " + total
                                        + " justWrite: " + HexUtil.encodeHexStr(justWrite, false));

                                txtLog.setText("--> " + HexUtil.encodeHexStr(justWrite, false));
                            }

                            @Override
                            public void onWriteFailure(final BleException exception) {
                                log("--> " + exception.toString());
                            }
                        });
            } else {
                txtLog.setText("");
            }
        } else {
            Toast.makeText(this, "No BLE device connected.", Toast.LENGTH_SHORT).show();
            txtLog.setText("");
        }
    }

    private void registerNotifyCallback() {
        final BleDevice bleDevice = Global.bleDevice;
        final BluetoothGattCharacteristic characteristicNotify = Global.characteristicNotify;
        if (bleDevice != null && characteristicNotify != null) {
            int notifyProperties = characteristicNotify.getProperties();
            if ((notifyProperties & BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
                BleManagerImpl.getInstance().notify(
                        bleDevice,
                        characteristicNotify.getService().getUuid().toString(),
                        characteristicNotify.getUuid().toString(),
                        new BleNotifyCallback() {

                            @Override
                            public void onNotifySuccess() {
                                log("<-- notify success");
                            }

                            @Override
                            public void onNotifyFailure(final BleException exception) {
                                log("<-- notify failure " + exception.toString());
                            }

                            @Override
                            public void onCharacteristicChanged(byte[] data) {
                                DataStructure parseResult = BluetoothRxMessageParser.parse(characteristicNotify.getValue());
                                onResponse(characteristicNotify.getValue(), parseResult);

                                log("<-- " + HexUtil.encodeHexStr(characteristicNotify.getValue(), false));
                            }
                        });
            }
        }

        final BluetoothGattCharacteristic characteristicIndicate = Global.characteristicIndicate;
        if (bleDevice != null && characteristicIndicate != null) {
            int indicateProperties = characteristicIndicate.getProperties();
            if ((indicateProperties & BluetoothGattCharacteristic.PROPERTY_INDICATE) > 0) {
                BleManagerImpl.getInstance().indicate(
                        bleDevice,
                        characteristicIndicate.getService().getUuid().toString(),
                        characteristicIndicate.getUuid().toString(),
                        new BleIndicateCallback() {

                            @Override
                            public void onIndicateSuccess() {
                                log("<-- indicate success");
                            }

                            @Override
                            public void onIndicateFailure(final BleException exception) {
                                log("<-- indicate failure " + exception.toString());
                            }

                            @Override
                            public void onCharacteristicChanged(byte[] data) {
                                DataStructure parseResult = BluetoothRxMessageParser.parse(characteristicIndicate.getValue());
                                onResponse(characteristicIndicate.getValue(), parseResult);

                                log("<-- " + HexUtil.encodeHexStr(characteristicIndicate.getValue(), false));
                            }
                        });
            }
        }
    }

    private void unregisterNotifyCallback() {
        final BleDevice bleDevice = Global.bleDevice;
        final BluetoothGattCharacteristic characteristicNotify = Global.characteristicNotify;
        if (bleDevice != null && characteristicNotify != null) {
            int notifyProperties = characteristicNotify.getProperties();
            if ((notifyProperties & BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
                BleManagerImpl.getInstance().stopNotify(
                        bleDevice,
                        characteristicNotify.getService().getUuid().toString(),
                        characteristicNotify.getUuid().toString());
            }
        }

        final BluetoothGattCharacteristic characteristicIndicate = Global.characteristicIndicate;
        if (bleDevice != null && characteristicIndicate != null) {
            int indicateProperties = characteristicIndicate.getProperties();
            if ((indicateProperties & BluetoothGattCharacteristic.PROPERTY_INDICATE) > 0) {
                BleManagerImpl.getInstance().stopIndicate(
                        bleDevice,
                        characteristicIndicate.getService().getUuid().toString(),
                        characteristicIndicate.getUuid().toString());
            }
        }
    }

    private void read() {
        final BleDevice bleDevice = Global.bleDevice;
        final BluetoothGattCharacteristic characteristic = Global.characteristicRead;
        if (bleDevice != null && characteristic != null) {
            int prop = characteristic.getProperties();
            if ((prop & BluetoothGattCharacteristic.PROPERTY_READ) > 0) {
                BleManagerImpl.getInstance().read(
                        bleDevice,
                        characteristic.getService().getUuid().toString(),
                        characteristic.getUuid().toString(),
                        new BleReadCallback() {

                            @Override
                            public void onReadSuccess(final byte[] data) {
                                log("<-- " + HexUtil.encodeHexStr(data, false));
                                DataStructure parseResult = BluetoothRxMessageParser.parse(data);
                                onResponse(data, parseResult);
                            }

                            @Override
                            public void onReadFailure(final BleException exception) {
                                log("<-- " + exception.toString());
                            }
                        });
            }
        }
    }

    private void onResponse(byte[] raw, DataStructure data) {
        if (data == null) return;

        txtValue1.setText(String.valueOf(data.Value1));
        txtValue2.setText(String.valueOf(data.Value2));
        txtValue3.setText(String.valueOf(data.Value3));
        txtValue4.setText(String.valueOf(data.Value4));
        txtValue5.setText(String.valueOf(data.Value5));
        check1.setChecked(data.Check1);
        check2.setChecked(data.Check2);
        check3.setChecked(data.Check3);
        check4.setChecked(data.Check4);
        check5.setChecked(data.Check5);
        check6.setChecked(data.Check6);
        check7.setChecked(data.Check7);
        check8.setChecked(data.Check8);
        check9.setChecked(data.Check9);
        check10.setChecked(data.Check10);
        check11.setChecked(data.Check11);
        check12.setChecked(data.Check12);
        check13.setChecked(data.Check13);
        check14.setChecked(data.Check14);
        check15.setChecked(data.Check15);

        try {
            txtLog2.setText("<-- " + HexUtil.encodeHexStr(raw, false));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void log(String content) {
        Log.i(TAG, "log: " + content);
    }
}
