package com.speedble.demo;

import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;

import com.polaris.speedble.data.BleDevice;
import com.polaris.speedble.data.DataStructure;
import com.polaris.speedble.data.ParseResult;

public class Global {
    public static BleDevice bleDevice;
    public static BluetoothGattService bluetoothGattService;
    public static BluetoothGattCharacteristic characteristicWrite;
    public static BluetoothGattCharacteristic characteristicRead;
    public static BluetoothGattCharacteristic characteristicNotify;
    public static BluetoothGattCharacteristic characteristicIndicate;
}
