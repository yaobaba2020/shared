package com.speedble.demo.activity;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.polaris.speedble.BleManagerImpl;
import com.polaris.speedble.callback.BleGattCallback;
import com.polaris.speedble.callback.BleResponseCallback;
import com.polaris.speedble.callback.BleScanCallback;
import com.polaris.speedble.callback.BleWriteCallback;
import com.polaris.speedble.data.BleDevice;
import com.polaris.speedble.data.DataStructure;
import com.polaris.speedble.exception.BleException;
import com.polaris.speedble.scan.BleScanRuleConfig;
import com.polaris.speedble.utils.HexUtil;
import com.speedble.demo.R;
import com.speedble.demo.adapter.DeviceAdapter;
import com.speedble.demo.comm.Observer;
import com.speedble.demo.comm.ObserverManager;
import com.speedble.demo.preference.TinyDB;

import org.byteam.superadapter.OnItemClickListener;

import java.util.ArrayList;
import java.util.List;

import permissions.dispatcher.NeedsPermission;
import permissions.dispatcher.RuntimePermissions;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
@RuntimePermissions
public class MainActivity extends AppCompatActivity implements View.OnClickListener, Observer {

    private static final String TAG = MainActivity.class.getSimpleName();
    private static final int REQUEST_CODE_OPEN_GPS = 1;

    private RecyclerView recyclerDevice;
    private ImageView imgLoading;
    private Button btnScan;
    private Button btnCommand1;
    private Button btnCommand2;
    private TextView txtLog;
    private TextView txtLog2;
    private EditText editFilter;
    private TextView txtValue1;
    private TextView txtValue2;
    private TextView txtValue3;
    private TextView txtValue4;
    private TextView txtValue5;
    private CheckBox check1;
    private CheckBox check2;
    private CheckBox check3;
    private CheckBox check4;
    private CheckBox check5;
    private CheckBox check6;
    private CheckBox check7;
    private CheckBox check8;
    private CheckBox check9;
    private CheckBox check10;
    private CheckBox check11;
    private CheckBox check12;
    private CheckBox check13;
    private CheckBox check14;
    private CheckBox check15;

    private DeviceAdapter mDeviceAdapter;
    private List<BleDevice> deviceList = new ArrayList<>();
    private List<BleDevice> deviceListFiltered = new ArrayList<>();

    private Animation operatingAnim;
    private ProgressDialog progressDialog;
    private TinyDB tinyDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait...");
        operatingAnim = AnimationUtils.loadAnimation(this, R.anim.rotate);
        operatingAnim.setInterpolator(new LinearInterpolator());

        tinyDB = new TinyDB(this);

        initView();

        BleManagerImpl.getInstance().init(getApplication());
        BleManagerImpl.getInstance()
                .enableLog(true)
                .setReConnectCount2(1, 5000)
                .setConnectOverTime(20000)
                .setOperateTimeout(5000);

        ObserverManager.getInstance().addObserver(this);

        // scan and auto connect when app is opened
        checkPermissions();
    }

    private void initView() {
        recyclerDevice = findViewById(R.id.recycler_device);
        imgLoading = findViewById(R.id.img_loading);
        btnScan = findViewById(R.id.btn_scan);
        btnCommand1 = findViewById(R.id.btn_command_1);
        btnCommand2 = findViewById(R.id.btn_command_2);
        txtLog = findViewById(R.id.txt_log);
        txtLog2 = findViewById(R.id.txt_log_2);

        editFilter = findViewById(R.id.edit_filter);
        txtValue1 = findViewById(R.id.txt_value1);
        txtValue2 = findViewById(R.id.txt_value2);
        txtValue3 = findViewById(R.id.txt_value3);
        txtValue4 = findViewById(R.id.txt_value4);
        txtValue5 = findViewById(R.id.txt_value5);
        check1 = findViewById(R.id.check1);
        check2 = findViewById(R.id.check2);
        check3 = findViewById(R.id.check3);
        check4 = findViewById(R.id.check4);
        check5 = findViewById(R.id.check5);
        check6 = findViewById(R.id.check6);
        check7 = findViewById(R.id.check7);
        check8 = findViewById(R.id.check8);
        check9 = findViewById(R.id.check9);
        check10 = findViewById(R.id.check10);
        check11 = findViewById(R.id.check11);
        check12 = findViewById(R.id.check12);
        check13 = findViewById(R.id.check13);
        check14 = findViewById(R.id.check14);
        check15 = findViewById(R.id.check15);

        recyclerDevice.setLayoutManager(new LinearLayoutManager(this));
        mDeviceAdapter = new DeviceAdapter(this, deviceListFiltered, R.layout.item_device);
        mDeviceAdapter.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(View itemView, int viewType, int position) {
                if (BleManagerImpl.getInstance().isConnected(BleManagerImpl.bleDevice)) {
                    BleManagerImpl.getInstance().disconnect(BleManagerImpl.bleDevice);
                }
                BleDevice bleDevice = mDeviceAdapter.getItem(position);
                if (!BleManagerImpl.getInstance().isConnected(bleDevice)) {
                    BleManagerImpl.getInstance().cancelScan();
                    connect(bleDevice);
                }
            }
        });
        recyclerDevice.setAdapter(mDeviceAdapter);

        editFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                onFilterChanged();
            }

            @Override
            public void afterTextChanged(Editable s) {
                onFilterChanged();
            }
        });

        btnScan.setOnClickListener(this);
        btnCommand1.setOnClickListener(this);
        btnCommand2.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();

        showConnectedDevice();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        BleManagerImpl.getInstance().clearCharacterCallback(BleManagerImpl.bleDevice);
        ObserverManager.getInstance().deleteObserver(this);
        BleManagerImpl.getInstance().disconnectAllDevice();
        BleManagerImpl.getInstance().destroy();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_scan:
                if (btnScan.getText().equals(getString(R.string.start_scan))) {
                    checkPermissions();
                } else {
                    BleManagerImpl.getInstance().cancelScan();
                }
                break;
            case R.id.btn_command_1:
                sendCommand(1);
                break;
            case R.id.btn_command_2:
                sendCommand(2);
                break;
        }
    }

    @Override
    public final void onRequestPermissionsResult(int requestCode,
                                                 @NonNull String[] permissions,
                                                 @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        MainActivityPermissionsDispatcher.onRequestPermissionsResult(this, requestCode, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_OPEN_GPS) {
            if (checkGPSIsOpen()) {
                setScanRule();
                startScan();
            }
        }
    }

    private void checkPermissions() {
        recyclerDevice.setVisibility(View.VISIBLE);

        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        try {
            if (!bluetoothAdapter.isEnabled()) {
                Toast.makeText(this, getString(R.string.please_open_blue), Toast.LENGTH_LONG).show();
                return;
            }
            MainActivityPermissionsDispatcher.startAfterCheckPermissionWithPermissionCheck(this);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Your device doesn't support Bluetooth.", Toast.LENGTH_LONG).show();
        }
    }

    @NeedsPermission(Manifest.permission.ACCESS_FINE_LOCATION)
    protected void startAfterCheckPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !checkGPSIsOpen()) {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.notifyTitle)
                    .setMessage(R.string.gpsNotifyMsg)
                    .setNegativeButton(R.string.cancel,
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    finish();
                                }
                            })
                    .setPositiveButton(R.string.setting,
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                                    startActivityForResult(intent, REQUEST_CODE_OPEN_GPS);
                                }
                            })

                    .setCancelable(false)
                    .show();
        } else {
            setScanRule();
            startScan();
        }
    }

    private boolean checkGPSIsOpen() {
        LocationManager locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        if (locationManager == null)
            return false;
        return locationManager.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER);
    }

    @Override
    public void disConnected(BleDevice device) {
        if (device != null && BleManagerImpl.bleDevice != null && device.getKey().equals(BleManagerImpl.bleDevice.getKey())) {
            showConnectedDevice();
        }
    }

    private void showConnectedDevice() {
        deviceList = BleManagerImpl.getInstance().getAllConnectedDevice();
        deviceListFiltered = new ArrayList<>();
        for (BleDevice device : deviceList) {
            String query = editFilter.getText().toString();
            if (TextUtils.isEmpty(query) || (!TextUtils.isEmpty(device.getName()) && device.getName().toLowerCase().contains(query)))
                deviceListFiltered.add(device);
        }
        mDeviceAdapter.notifyDataSetChanged();
    }

    private void setScanRule() {
        BleScanRuleConfig scanRuleConfig = new BleScanRuleConfig.Builder()
                .setAutoConnect(true)                   // Auto connect, optional, default: false
                .setScanTimeOut(10000)                  // Scan timeout, optional, default: 10s
                .build();
        BleManagerImpl.getInstance().initScanRule(scanRuleConfig);
    }

    private void startScan() {
        if (BleManagerImpl.bleDevice != null && BleManagerImpl.getInstance().isConnected(BleManagerImpl.bleDevice)) {
            BleManagerImpl.getInstance().disconnect(BleManagerImpl.bleDevice);
        }

        BleManagerImpl.getInstance().scan(new BleScanCallback() {
            @Override
            public void onScanStarted(boolean success) {
                mDeviceAdapter.clear();
                imgLoading.startAnimation(operatingAnim);
                imgLoading.setVisibility(View.VISIBLE);
                btnScan.setText(R.string.stop_scan);
            }

            @Override
            public void onLeScan(BleDevice bleDevice) {
                super.onLeScan(bleDevice);
            }

            @Override
            public void onScanning(BleDevice bleDevice) {
                deviceList.add(bleDevice);
                String query = editFilter.getText().toString();
                if (TextUtils.isEmpty(query) || (!TextUtils.isEmpty(bleDevice.getName()) && bleDevice.getName().contains(query))) {
                    mDeviceAdapter.add(bleDevice);
                    mDeviceAdapter.notifyDataSetChanged();
                }
                BleDevice paired = tinyDB.getObject("BLE_PAIRED", BleDevice.class);
                if (paired != null && bleDevice.getMac().equals(paired.getMac())) {
                    if (!BleManagerImpl.getInstance().isConnected(bleDevice)) {
                        BleManagerImpl.getInstance().cancelScan();
                        connect(bleDevice);
                    }
                }
            }

            @Override
            public void onScanFinished(List<BleDevice> scanResultList) {
                imgLoading.clearAnimation();
                imgLoading.setVisibility(View.INVISIBLE);
                btnScan.setText(R.string.start_scan);
            }
        });
    }

    private void connect(final BleDevice bleDevice) {
        if (BleManagerImpl.bleDevice != null && BleManagerImpl.getInstance().isConnected(BleManagerImpl.bleDevice)) {
            BleManagerImpl.getInstance().disconnect(BleManagerImpl.bleDevice);
        }

        BleManagerImpl.bleDevice = null;
        BleManagerImpl.bluetoothGattService = null;
        BleManagerImpl.characteristicWrite = null;
        BleManagerImpl.characteristicRead = null;
        BleManagerImpl.characteristicNotify = null;
        BleManagerImpl.characteristicIndicate = null;

        BleManagerImpl.getInstance().connect(bleDevice, new BleGattCallback() {
            @Override
            public void onStartConnect() {
                progressDialog.show();
                mDeviceAdapter.notifyDataSetChanged();
            }

            @Override
            public void onConnectFail(BleDevice bleDevice, BleException exception) {
                imgLoading.clearAnimation();
                imgLoading.setVisibility(View.INVISIBLE);
                btnScan.setText(R.string.start_scan);
                progressDialog.dismiss();
                mDeviceAdapter.notifyDataSetChanged();
                Toast.makeText(MainActivity.this, getString(R.string.connect_fail), Toast.LENGTH_LONG).show();
            }

            @Override
            public void onConnectSuccess(BleDevice bleDevice, BluetoothGatt gatt, int status) {
                progressDialog.dismiss();
                mDeviceAdapter.notifyDataSetChanged();

                recyclerDevice.setVisibility(View.INVISIBLE);

                tinyDB.putObject("BLE_PAIRED", bleDevice);
                BleManagerImpl.bleDevice = bleDevice;
                // BluetoothGatt gatt = BleManagerImpl.getInstance().getBluetoothGatt(bleDevice);
                List<BluetoothGattService> serviceList = gatt.getServices();
                BleManagerImpl.bluetoothGattService = serviceList.get(serviceList.size() - 1);
                for (BluetoothGattCharacteristic characteristic : BleManagerImpl.bluetoothGattService.getCharacteristics()) {
                    int properties = characteristic.getProperties();
                    if ((properties & BluetoothGattCharacteristic.PROPERTY_READ) > 0) {
                        BleManagerImpl.characteristicRead = characteristic;
                    }
                    if ((properties & BluetoothGattCharacteristic.PROPERTY_WRITE) > 0
                            || (properties & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) > 0) {
                        BleManagerImpl.characteristicWrite = characteristic;
                        sendCommand(2);
                    }
                    if ((properties & BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
                        BleManagerImpl.characteristicNotify = characteristic;
                        registerNotifyCallback();
                    }
                    if ((properties & BluetoothGattCharacteristic.PROPERTY_INDICATE) > 0) {
                        BleManagerImpl.characteristicIndicate = characteristic;
                        registerNotifyCallback();
                    }
                }
            }

            @Override
            public void onDisConnected(boolean isActiveDisConnected, BleDevice bleDevice, BluetoothGatt gatt, int status) {
                progressDialog.dismiss();

                mDeviceAdapter.notifyDataSetChanged();

                if (isActiveDisConnected) {
                    Toast.makeText(MainActivity.this, getString(R.string.active_disconnected), Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, getString(R.string.disconnected), Toast.LENGTH_LONG).show();
                    ObserverManager.getInstance().notifyObserver(bleDevice);
                }
            }
        });
    }

    private void onFilterChanged() {
        deviceListFiltered = new ArrayList<>();
        for (BleDevice device : deviceList) {
            String query = editFilter.getText().toString();
            if (TextUtils.isEmpty(query) || (!TextUtils.isEmpty(device.getName()) && device.getName().toLowerCase().contains(query)))
                deviceListFiltered.add(device);
        }
        mDeviceAdapter.notifyDataSetChanged();
    }

    private void updateResponseUI(byte[] raw, DataStructure data) {
        if (data == null) return;

        txtValue1.setText(String.valueOf(data.Value1));
        txtValue2.setText(String.valueOf(data.Value2));
        txtValue3.setText(String.valueOf(data.Value3));
        txtValue4.setText(String.valueOf(data.Value4));
        txtValue5.setText(String.valueOf(data.Value5));
        check1.setChecked(data.Check1);
        check2.setChecked(data.Check2);
        check3.setChecked(data.Check3);
        check4.setChecked(data.Check4);
        check5.setChecked(data.Check5);
        check6.setChecked(data.Check6);
        check7.setChecked(data.Check7);
        check8.setChecked(data.Check8);
        check9.setChecked(data.Check9);
        check10.setChecked(data.Check10);
        check11.setChecked(data.Check11);
        check12.setChecked(data.Check12);
        check13.setChecked(data.Check13);
        check14.setChecked(data.Check14);
        check15.setChecked(data.Check15);

        try {
            txtLog2.setText("<-- " + HexUtil.encodeHexStr(raw, false));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    // ++++++++++++++++++++++++ PROPERTY_WRITE | PROPERTY_WRITE_NO_RESPONSE ++++++++++++++++++++++++


    private void sendCommand(int id) {
        switch (id) {
            case 1:
                write(1, "");
                break;
            case 2:
                write(2, "1F0000");
                break;
        }
    }

    public void write(int id, String hex) {
        // Test
        byte[] bytes = BleManagerImpl.getInstance().writeLog(id, HexUtil.hexStringToBytes(hex));
        txtLog.setText(">-- " + HexUtil.encodeHexStr(bytes, false));

        int result = BleManagerImpl.getInstance().writeCustom(id, hex, new BleWriteCallback() {
            @Override
            public void onWriteSuccess(int current, int total, byte[] justWrite) {
                txtLog.setText("--> " + HexUtil.encodeHexStr(justWrite, false));
            }

            @Override
            public void onWriteFailure(BleException exception) {

            }
        });
        if (result < 0) {
            Toast.makeText(this, "No BLE device connected.", Toast.LENGTH_SHORT).show();
        }
        if (result <= 0) {
            txtLog.setText("");
        }
    }

    private void registerNotifyCallback() {
        BleManagerImpl.getInstance().registerNotifyCallback(new BleResponseCallback() {
            @Override
            public void onWriteSuccess(byte[] raw, DataStructure dataStructure) {
                updateResponseUI(raw, dataStructure);
            }
        });
    }
}