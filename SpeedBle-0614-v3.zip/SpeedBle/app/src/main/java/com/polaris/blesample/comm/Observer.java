package com.polaris.blesample.comm;


import com.polaris.speedble.data.BleDevice;

public interface Observer {

    void disConnected(BleDevice bleDevice);
}
