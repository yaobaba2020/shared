package com.polaris.speedble.data;

public class DataMsg1 {
    public int Var1 = 0;
    public int Var2 = 0;
    public int Var3 = 0;
    public int Var4 = 0;
    public int Var5 = 0;
    public int Var6 = 0;
    public int Var7 = 0;
    public int Var8 = 0;

    public int getVar1() {
        return Var1;
    }

    public void setVar1(int var1) {
        Var1 = var1;
    }

    public int getVar2() {
        return Var2;
    }

    public void setVar2(int var2) {
        Var2 = var2;
    }

    public int getVar3() {
        return Var3;
    }

    public void setVar3(int var3) {
        Var3 = var3;
    }

    public int getVar4() {
        return Var4;
    }

    public void setVar4(int var4) {
        Var4 = var4;
    }

    public int getVar5() {
        return Var5;
    }

    public void setVar5(int var5) {
        Var5 = var5;
    }

    public int getVar6() {
        return Var6;
    }

    public void setVar6(int var6) {
        Var6 = var6;
    }

    public int getVar7() {
        return Var7;
    }

    public void setVar7(int var7) {
        Var7 = var7;
    }

    public int getVar8() {
        return Var8;
    }

    public void setVar8(int var8) {
        Var8 = var8;
    }
}
