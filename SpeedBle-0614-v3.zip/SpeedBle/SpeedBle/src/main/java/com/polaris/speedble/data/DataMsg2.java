package com.polaris.speedble.data;

public class DataMsg2 {
    public int Status;
    public Msg2Parmeter Var9 = new Msg2Parmeter();
    public Msg2Parmeter Var10 = new Msg2Parmeter();
    public Msg2Parmeter Var11 = new Msg2Parmeter();
    public Msg2Parmeter Var12 = new Msg2Parmeter();
    public Msg2Parmeter Var13 = new Msg2Parmeter();

    public int getStatus() {
        return Status;
    }

    public void setStatus(int status) {
        Status = status;
    }

    public Msg2Parmeter getVar9() {
        return Var9;
    }

    public void setVar9(Msg2Parmeter var9) {
        Var9 = var9;
    }

    public Msg2Parmeter getVar10() {
        return Var10;
    }

    public void setVar10(Msg2Parmeter var10) {
        Var10 = var10;
    }

    public Msg2Parmeter getVar11() {
        return Var11;
    }

    public void setVar11(Msg2Parmeter var11) {
        Var11 = var11;
    }

    public Msg2Parmeter getVar12() {
        return Var12;
    }

    public void setVar12(Msg2Parmeter var12) {
        Var12 = var12;
    }

    public Msg2Parmeter getVar13() {
        return Var13;
    }

    public void setVar13(Msg2Parmeter var13) {
        Var13 = var13;
    }
}
