package com.polaris.speedble.data;

public class DataStructure
{
    public int Value1;     //Value1 on User Interface
    public int Value2;     //Value2 on User Interface
    public int Value3;     //Value3 on User Interface
    public int Value4;     //Value4 on User Interface
    public int Value5;     //Value5 on User Interface
    public int Value6;
    public int Value7;
    public int Value8;

    public int Value9;
    public int Value10;
    public int Value11;
    public int Value12;
    public int Value13;
    public int Value14;
    public int Value15;

    public boolean Check1;     //Checkbox1 on User Interface
    public boolean Check2;     //Checkbox2 on User Interface
    public boolean Check3;     //Checkbox3 on User Interface
    public boolean Check4;     //Checkbox4 on User Interface
    public boolean Check5;     //Checkbox5 on User Interface
    public boolean Check6;     //Checkbox6 on User Interface
    public boolean Check7;     //Checkbox7 on User Interface
    public boolean Check8;     //Checkbox8 on User Interface
    public boolean Check9;     //Checkbox9 on User Interface
    public boolean Check10;    //Checkbox10 on User Interface
    public boolean Check11;    //Checkbox11 on User Interface
    public boolean Check12;    //Checkbox12 on User Interface
    public boolean Check13;    //Checkbox13 on User Interface
    public boolean Check14;    //Checkbox14 on User Interface
    public boolean Check15;    //Checkbox15 on User Interface
}