package com.polaris.speedble.data;

public class ParseResult {
    public boolean stMsgValid = false;                  //Valid message
    public byte stRxMsgId = 0;                          //RX Message ID
    public DataMsg1 stDataMsg1 = new DataMsg1();        //Reponse 1 Data
    public DataMsg2 stDataMsg2 = new DataMsg2();        //Reponse 2 Data

    public boolean isStMsgValid() {
        return stMsgValid;
    }

    public void setStMsgValid(boolean stMsgValid) {
        this.stMsgValid = stMsgValid;
    }

    public byte getStRxMsgId() {
        return stRxMsgId;
    }

    public void setStRxMsgId(byte stRxMsgId) {
        this.stRxMsgId = stRxMsgId;
    }

    public DataMsg1 getStDataMsg1() {
        if (stDataMsg1 == null)
            stDataMsg1 = new DataMsg1();
        return stDataMsg1;
    }

    public void setStDataMsg1(DataMsg1 stDataMsg1) {
        this.stDataMsg1 = stDataMsg1;
    }

    public DataMsg2 getStDataMsg2() {
        if (stDataMsg2 == null)
            stDataMsg2 = new DataMsg2();
        return stDataMsg2;
    }

    public void setStDataMsg2(DataMsg2 stDataMsg2) {
        this.stDataMsg2 = stDataMsg2;
    }
}
