package com.polaris.speedble.scan;


import com.polaris.speedble.BleManager;

import java.util.UUID;

public class BleScanRuleConfig {

    private UUID[] us = null;
    private String[] dns = null;
    private String dm = null;
    private boolean ac = false;
    private boolean f = false;
    private long sto = BleManager.DST;

    public UUID[] getServiceUuids() {
        return us;
    }

    public String[] getDeviceNames() {
        return dns;
    }

    public String getDeviceMac() {
        return dm;
    }

    public boolean isAutoConnect() {
        return ac;
    }

    public boolean isFuzzy() {
        return f;
    }

    public long getScanTimeOut() {
        return sto;
    }

    public static class Builder {

        private UUID[] us = null;
        private String[] dns = null;
        private String dm = null;
        private boolean ac = false;
        private boolean f = false;
        private long sto = BleManager.DST;

        public Builder setServiceUuids(UUID[] uuids) {
            this.us = uuids;
            return this;
        }

        public Builder setDeviceName(boolean fuzzy, String... name) {
            this.f = fuzzy;
            this.dns = name;
            return this;
        }

        public Builder setDeviceMac(String mac) {
            this.dm = mac;
            return this;
        }

        public Builder setAutoConnect(boolean autoConnect) {
            this.ac = autoConnect;
            return this;
        }

        public Builder setScanTimeOut(long timeOut) {
            this.sto = timeOut;
            return this;
        }

        void applyConfig(BleScanRuleConfig config) {
            config.us = this.us;
            config.dns = this.dns;
            config.dm = this.dm;
            config.ac = this.ac;
            config.f = this.f;
            config.sto = this.sto;
        }

        public BleScanRuleConfig build() {
            BleScanRuleConfig c = new BleScanRuleConfig();
            applyConfig(c);
            return c;
        }

    }


}
