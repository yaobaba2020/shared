package com.polaris.speedble.bluetooth;

import android.annotation.TargetApi;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothProfile;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import com.polaris.speedble.BleManagerImpl;
import com.polaris.speedble.callback.BleGattCallback;
import com.polaris.speedble.callback.BleIndicateCallback;
import com.polaris.speedble.callback.BleMtuChangedCallback;
import com.polaris.speedble.callback.BleNotifyCallback;
import com.polaris.speedble.callback.BleReadCallback;
import com.polaris.speedble.callback.BleRssiCallback;
import com.polaris.speedble.callback.BleWriteCallback;
import com.polaris.speedble.data.BleConnectStateParameter;
import com.polaris.speedble.data.BleDevice;
import com.polaris.speedble.data.BleMsg;
import com.polaris.speedble.exception.ConnectException;
import com.polaris.speedble.exception.OtherException;
import com.polaris.speedble.exception.TimeoutException;
import com.polaris.speedble.utils.BleLog;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import static android.bluetooth.BluetoothDevice.TRANSPORT_LE;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
public class BleBluetooth {

    private BleGattCallback bgcb;
    private BleRssiCallback brcb;
    private BleMtuChangedCallback bmccb;
    private HashMap<String, BleNotifyCallback> bncbm = new HashMap<>();
    private HashMap<String, BleIndicateCallback> bicbm = new HashMap<>();
    private HashMap<String, BleWriteCallback> bwcbm = new HashMap<>();
    private HashMap<String, BleReadCallback> brcbm = new HashMap<>();

    private LastState ls;
    private boolean d = false;
    private BleDevice bd;
    private BluetoothGatt bg;
    private MainHandler mh = new MainHandler(Looper.getMainLooper());
    private int rc = 0;

    public BleBluetooth(BleDevice bleDevice) {
        this.bd = bleDevice;
    }

    public BleConnector newBleConnector() {
        return new BleConnector(this);
    }

    public synchronized void addConnectGattCallback(BleGattCallback callback) {
        bgcb = callback;
    }

    public synchronized void removeConnectGattCallback() {
        bgcb = null;
    }

    public synchronized void addNotifyCallback(String uuid, BleNotifyCallback bleNotifyCallback) {
        bncbm.put(uuid, bleNotifyCallback);
    }

    public synchronized void addIndicateCallback(String uuid, BleIndicateCallback bleIndicateCallback) {
        bicbm.put(uuid, bleIndicateCallback);
    }

    public synchronized void addWriteCallback(String uuid, BleWriteCallback bleWriteCallback) {
        bwcbm.put(uuid, bleWriteCallback);
    }

    public synchronized void addReadCallback(String uuid, BleReadCallback bleReadCallback) {
        brcbm.put(uuid, bleReadCallback);
    }

    public synchronized void removeNotifyCallback(String uuid) {
        if (bncbm.containsKey(uuid))
            bncbm.remove(uuid);
    }

    public synchronized void removeIndicateCallback(String uuid) {
        if (bicbm.containsKey(uuid))
            bicbm.remove(uuid);
    }

    public synchronized void removeWriteCallback(String uuid) {
        if (bwcbm.containsKey(uuid))
            bwcbm.remove(uuid);
    }

    public synchronized void removeReadCallback(String uuid) {
        if (brcbm.containsKey(uuid))
            brcbm.remove(uuid);
    }

    public synchronized void clearCharacterCallback() {
        if (bncbm != null)
            bncbm.clear();
        if (bicbm != null)
            bicbm.clear();
        if (bwcbm != null)
            bwcbm.clear();
        if (brcbm != null)
            brcbm.clear();
    }

    public synchronized void addRssiCallback(BleRssiCallback callback) {
        brcb = callback;
    }

    public synchronized void removeRssiCallback() {
        brcb = null;
    }

    public synchronized void addMtuChangedCallback(BleMtuChangedCallback callback) {
        bmccb = callback;
    }

    public synchronized void removeMtuChangedCallback() {
        bmccb = null;
    }


    public String getDeviceKey() {
        return bd.getKey();
    }

    public BleDevice getDevice() {
        return bd;
    }

    public BluetoothGatt getBluetoothGatt() {
        return bg;
    }

    public synchronized BluetoothGatt connect(BleDevice bleDevice,
                                              boolean autoConnect,
                                              BleGattCallback callback) {
        return connect(bleDevice, autoConnect, callback, 0);
    }

    public synchronized BluetoothGatt connect(BleDevice bleDevice,
                                              boolean autoConnect,
                                              BleGattCallback callback,
                                              int connectRetryCount) {
        BleLog.i("connect device: " + bleDevice.getName()
                + "\nmac: " + bleDevice.getMac()
                + "\nautoConnect: " + autoConnect
                + "\ncurrentThread: " + Thread.currentThread().getId()
                + "\nconnectCount:" + (connectRetryCount + 1));
        if (connectRetryCount == 0) {
            this.rc = 0;
        }

        addConnectGattCallback(callback);

        ls = LastState.CONNECT_CONNECTING;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            bg = bleDevice.getDevice().connectGatt(BleManagerImpl.getInstance().a(),
                    autoConnect, coreGattCallback, TRANSPORT_LE);
        } else {
            bg = bleDevice.getDevice().connectGatt(BleManagerImpl.getInstance().a(),
                    autoConnect, coreGattCallback);
        }
        if (bg != null) {
            if (bgcb != null) {
                bgcb.onStartConnect();
            }
            Message m = mh.obtainMessage();
            m.what = BleMsg.MSG_CONNECT_OVER_TIME;
            mh.sendMessageDelayed(m, BleManagerImpl.getInstance().getConnectOverTime());

        } else {
            disconnectGatt();
            refreshDeviceCache();
            closeBluetoothGatt();
            ls = LastState.CONNECT_FAILURE;
            BleManagerImpl.getInstance().getMultipleBluetoothController().removeConnectingBle(BleBluetooth.this);
            if (bgcb != null)
                bgcb.onConnectFail(bleDevice, new OtherException("GATT connect exception occurred!"));

        }
        return bg;
    }

    public synchronized void disconnect() {
        d = true;
        disconnectGatt();
    }

    public synchronized void destroy() {
        ls = LastState.CONNECT_IDLE;
        disconnectGatt();
        refreshDeviceCache();
        closeBluetoothGatt();
        removeConnectGattCallback();
        removeRssiCallback();
        removeMtuChangedCallback();
        clearCharacterCallback();
        mh.removeCallbacksAndMessages(null);
    }

    private synchronized void disconnectGatt() {
        if (bg != null) {
            bg.disconnect();
        }
    }

    private synchronized void refreshDeviceCache() {
        try {
            final Method refresh = BluetoothGatt.class.getMethod("refresh");
            if (refresh != null && bg != null) {
                boolean success = (Boolean) refresh.invoke(bg);
                BleLog.i("refreshDeviceCache, is success:  " + success);
            }
        } catch (Exception e) {
            BleLog.i("exception occur while refreshing device: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private synchronized void closeBluetoothGatt() {
        if (bg != null) {
            bg.close();
        }
    }

    private final class MainHandler extends Handler {

        MainHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case BleMsg.MSG_CONNECT_FAIL: {
                    disconnectGatt();
                    refreshDeviceCache();
                    closeBluetoothGatt();

                    if (rc < BleManagerImpl.getInstance().getReConnectCount()) {
                        BleLog.e("Connect fail, try reconnect " + BleManagerImpl.getInstance().getReConnectInterval() + " millisecond later");
                        ++rc;

                        Message message = mh.obtainMessage();
                        message.what = BleMsg.MSG_RECONNECT;
                        mh.sendMessageDelayed(message, BleManagerImpl.getInstance().getReConnectInterval());
                    } else {
                        ls = LastState.CONNECT_FAILURE;
                        BleManagerImpl.getInstance().getMultipleBluetoothController().removeConnectingBle(BleBluetooth.this);

                        BleConnectStateParameter para = (BleConnectStateParameter) msg.obj;
                        int status = para.getStatus();
                        if (bgcb != null)
                            bgcb.onConnectFail(bd, new ConnectException(bg, status));
                    }
                }
                break;

                case BleMsg.MSG_DISCONNECTED: {
                    ls = LastState.CONNECT_DISCONNECT;
                    BleManagerImpl.getInstance().getMultipleBluetoothController().removeBleBluetooth(BleBluetooth.this);

                    disconnect();
                    refreshDeviceCache();
                    closeBluetoothGatt();
                    removeRssiCallback();
                    removeMtuChangedCallback();
                    clearCharacterCallback();
                    mh.removeCallbacksAndMessages(null);

                    BleConnectStateParameter p = (BleConnectStateParameter) msg.obj;
                    boolean a = p.isActive();
                    int s = p.getStatus();
                    if (bgcb != null)
                        bgcb.onDisConnected(a, bd, bg, s);
                }
                break;

                case BleMsg.MSG_RECONNECT: {
                    connect(bd, false, bgcb, rc);
                }
                break;

                case BleMsg.MSG_CONNECT_OVER_TIME: {
                    disconnectGatt();
                    refreshDeviceCache();
                    closeBluetoothGatt();

                    ls = LastState.CONNECT_FAILURE;
                    BleManagerImpl.getInstance().getMultipleBluetoothController().removeConnectingBle(BleBluetooth.this);

                    if (bgcb != null)
                        bgcb.onConnectFail(bd, new TimeoutException());
                }
                break;

                case BleMsg.MSG_DISCOVER_SERVICES: {
                    if (bg != null) {
                        boolean discoverServiceResult = bg.discoverServices();
                        if (!discoverServiceResult) {
                            Message m = mh.obtainMessage();
                            m.what = BleMsg.MSG_DISCOVER_FAIL;
                            mh.sendMessage(m);
                        }
                    } else {
                        Message m = mh.obtainMessage();
                        m.what = BleMsg.MSG_DISCOVER_FAIL;
                        mh.sendMessage(m);
                    }
                }
                break;

                case BleMsg.MSG_DISCOVER_FAIL: {
                    disconnectGatt();
                    refreshDeviceCache();
                    closeBluetoothGatt();

                    ls = LastState.CONNECT_FAILURE;
                    BleManagerImpl.getInstance().getMultipleBluetoothController().removeConnectingBle(BleBluetooth.this);

                    if (bgcb != null)
                        bgcb.onConnectFail(bd,
                                new OtherException("GATT discover services exception occurred!"));
                }
                break;

                case BleMsg.MSG_DISCOVER_SUCCESS: {
                    ls = LastState.CONNECT_CONNECTED;
                    d = false;
                    BleManagerImpl.getInstance().getMultipleBluetoothController().removeConnectingBle(BleBluetooth.this);
                    BleManagerImpl.getInstance().getMultipleBluetoothController().addBleBluetooth(BleBluetooth.this);

                    BleConnectStateParameter para = (BleConnectStateParameter) msg.obj;
                    int s = para.getStatus();
                    if (bgcb != null)
                        bgcb.onConnectSuccess(bd, bg, s);
                }
                break;

                default:
                    super.handleMessage(msg);
                    break;
            }
        }
    }

    private BluetoothGattCallback coreGattCallback = new BluetoothGattCallback() {

        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            super.onConnectionStateChange(gatt, status, newState);
            BleLog.i("BluetoothGattCallback：onConnectionStateChange "
                    + '\n' + "status: " + status
                    + '\n' + "newState: " + newState
                    + '\n' + "currentThread: " + Thread.currentThread().getId());

            bg = gatt;

            mh.removeMessages(BleMsg.MSG_CONNECT_OVER_TIME);

            if (newState == BluetoothProfile.STATE_CONNECTED) {
                Message m = mh.obtainMessage();
                m.what = BleMsg.MSG_DISCOVER_SERVICES;
                mh.sendMessageDelayed(m, 500);

            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                if (ls == LastState.CONNECT_CONNECTING) {
                    Message m = mh.obtainMessage();
                    m.what = BleMsg.MSG_CONNECT_FAIL;
                    m.obj = new BleConnectStateParameter(status);
                    mh.sendMessage(m);

                } else if (ls == LastState.CONNECT_CONNECTED) {
                    Message m = mh.obtainMessage();
                    m.what = BleMsg.MSG_DISCONNECTED;
                    BleConnectStateParameter para = new BleConnectStateParameter(status);
                    para.setActive(d);
                    m.obj = para;
                    mh.sendMessage(m);
                }
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            super.onServicesDiscovered(gatt, status);
            BleLog.i("BluetoothGattCallback：onServicesDiscovered "
                    + '\n' + "status: " + status
                    + '\n' + "currentThread: " + Thread.currentThread().getId());

            bg = gatt;

            if (status == BluetoothGatt.GATT_SUCCESS) {
                Message m = mh.obtainMessage();
                m.what = BleMsg.MSG_DISCOVER_SUCCESS;
                m.obj = new BleConnectStateParameter(status);
                mh.sendMessage(m);

            } else {
                Message m = mh.obtainMessage();
                m.what = BleMsg.MSG_DISCOVER_FAIL;
                mh.sendMessage(m);
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicChanged(gatt, characteristic);

            Iterator it = bncbm.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry e = (Map.Entry) it.next();
                Object o = e.getValue();
                if (o instanceof BleNotifyCallback) {
                    BleNotifyCallback cb = (BleNotifyCallback) o;
                    if (characteristic.getUuid().toString().equalsIgnoreCase(cb.getKey())) {
                        Handler h = cb.getHandler();
                        if (h != null) {
                            Message m = h.obtainMessage();
                            m.what = BleMsg.MSG_CHA_NOTIFY_DATA_CHANGE;
                            m.obj = cb;
                            Bundle b = new Bundle();
                            b.putByteArray(BleMsg.KEY_NOTIFY_BUNDLE_VALUE, characteristic.getValue());
                            m.setData(b);
                            h.sendMessage(m);
                        }
                    }
                }
            }

            it = bicbm.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry e = (Map.Entry) it.next();
                Object o = e.getValue();
                if (o instanceof BleIndicateCallback) {
                    BleIndicateCallback cb = (BleIndicateCallback) o;
                    if (characteristic.getUuid().toString().equalsIgnoreCase(cb.getKey())) {
                        Handler h = cb.getHandler();
                        if (h != null) {
                            Message m = h.obtainMessage();
                            m.what = BleMsg.MSG_CHA_INDICATE_DATA_CHANGE;
                            m.obj = cb;
                            Bundle b = new Bundle();
                            b.putByteArray(BleMsg.KEY_INDICATE_BUNDLE_VALUE, characteristic.getValue());
                            m.setData(b);
                            h.sendMessage(m);
                        }
                    }
                }
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorWrite(gatt, descriptor, status);

            Iterator it = bncbm.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry e = (Map.Entry) it.next();
                Object o = e.getValue();
                if (o instanceof BleNotifyCallback) {
                    BleNotifyCallback cb = (BleNotifyCallback) o;
                    if (descriptor.getCharacteristic().getUuid().toString().equalsIgnoreCase(cb.getKey())) {
                        Handler h = cb.getHandler();
                        if (h != null) {
                            Message m = h.obtainMessage();
                            m.what = BleMsg.MSG_CHA_NOTIFY_RESULT;
                            m.obj = cb;
                            Bundle b = new Bundle();
                            b.putInt(BleMsg.KEY_NOTIFY_BUNDLE_STATUS, status);
                            m.setData(b);
                            h.sendMessage(m);
                        }
                    }
                }
            }

            it = bicbm.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry e = (Map.Entry) it.next();
                Object o = e.getValue();
                if (o instanceof BleIndicateCallback) {
                    BleIndicateCallback cb = (BleIndicateCallback) o;
                    if (descriptor.getCharacteristic().getUuid().toString().equalsIgnoreCase(cb.getKey())) {
                        Handler h = cb.getHandler();
                        if (h != null) {
                            Message m = h.obtainMessage();
                            m.what = BleMsg.MSG_CHA_INDICATE_RESULT;
                            m.obj = cb;
                            Bundle b = new Bundle();
                            b.putInt(BleMsg.KEY_INDICATE_BUNDLE_STATUS, status);
                            m.setData(b);
                            h.sendMessage(m);
                        }
                    }
                }
            }
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicWrite(gatt, characteristic, status);

            Iterator it = bwcbm.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry e = (Map.Entry) it.next();
                Object o = e.getValue();
                if (o instanceof BleWriteCallback) {
                    BleWriteCallback cb = (BleWriteCallback) o;
                    if (characteristic.getUuid().toString().equalsIgnoreCase(cb.getKey())) {
                        Handler h = cb.getHandler();
                        if (h != null) {
                            Message m = h.obtainMessage();
                            m.what = BleMsg.MSG_CHA_WRITE_RESULT;
                            m.obj = cb;
                            Bundle b = new Bundle();
                            b.putInt(BleMsg.KEY_WRITE_BUNDLE_STATUS, status);
                            b.putByteArray(BleMsg.KEY_WRITE_BUNDLE_VALUE, characteristic.getValue());
                            m.setData(b);
                            h.sendMessage(m);
                        }
                    }
                }
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicRead(gatt, characteristic, status);

            Iterator it = brcbm.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry e = (Map.Entry) it.next();
                Object o = e.getValue();
                if (o instanceof BleReadCallback) {
                    BleReadCallback cb = (BleReadCallback) o;
                    if (characteristic.getUuid().toString().equalsIgnoreCase(cb.getKey())) {
                        Handler h = cb.getHandler();
                        if (h != null) {
                            Message m = h.obtainMessage();
                            m.what = BleMsg.MSG_CHA_READ_RESULT;
                            m.obj = cb;
                            Bundle b = new Bundle();
                            b.putInt(BleMsg.KEY_READ_BUNDLE_STATUS, status);
                            b.putByteArray(BleMsg.KEY_READ_BUNDLE_VALUE, characteristic.getValue());
                            m.setData(b);
                            h.sendMessage(m);
                        }
                    }
                }
            }
        }

        @Override
        public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
            super.onReadRemoteRssi(gatt, rssi, status);

            if (brcb != null) {
                Handler h = brcb.getHandler();
                if (h != null) {
                    Message m = h.obtainMessage();
                    m.what = BleMsg.MSG_READ_RSSI_RESULT;
                    m.obj = brcb;
                    Bundle b = new Bundle();
                    b.putInt(BleMsg.KEY_READ_RSSI_BUNDLE_STATUS, status);
                    b.putInt(BleMsg.KEY_READ_RSSI_BUNDLE_VALUE, rssi);
                    m.setData(b);
                    h.sendMessage(m);
                }
            }
        }

        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            super.onMtuChanged(gatt, mtu, status);

            if (bmccb != null) {
                Handler h = bmccb.getHandler();
                if (h != null) {
                    Message m = h.obtainMessage();
                    m.what = BleMsg.MSG_SET_MTU_RESULT;
                    m.obj = bmccb;
                    Bundle b = new Bundle();
                    b.putInt(BleMsg.KEY_SET_MTU_BUNDLE_STATUS, status);
                    b.putInt(BleMsg.KEY_SET_MTU_BUNDLE_VALUE, mtu);
                    m.setData(b);
                    h.sendMessage(m);
                }
            }
        }
    };

    enum LastState {
        CONNECT_IDLE,
        CONNECT_CONNECTING,
        CONNECT_CONNECTED,
        CONNECT_FAILURE,
        CONNECT_DISCONNECT
    }
}