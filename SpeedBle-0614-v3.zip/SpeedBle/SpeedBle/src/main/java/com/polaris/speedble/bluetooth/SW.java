package com.polaris.speedble.bluetooth;


import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;

import com.polaris.speedble.BleManagerImpl;
import com.polaris.speedble.callback.BleWriteCallback;
import com.polaris.speedble.data.BleMsg;
import com.polaris.speedble.exception.BleException;
import com.polaris.speedble.exception.OtherException;
import com.polaris.speedble.utils.BleLog;

import java.util.LinkedList;
import java.util.Queue;

public class SW {

    private HandlerThread ht;
    private Handler h;

    private BleBluetooth bb;
    private String s;
    private String w;
    private byte[] d;
    private int c;
    private boolean sn;
    private long it;
    private BleWriteCallback cb;
    private Queue<byte[]> q;
    private int tn;

    public SW() {
        ht = new HandlerThread("splitWriter");
        ht.start();

        h = new Handler(ht.getLooper()) {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                if (msg.what == BleMsg.MSG_SPLIT_WRITE_NEXT) {
                    w();
                }
            }
        };
    }

    public void sw(BleBluetooth bleBluetooth,
                   String uuid_service,
                   String uuid_write,
                   byte[] data,
                   boolean sendNextWhenLastSuccess,
                   long intervalBetweenTwoPackage,
                   BleWriteCallback callback) {
        bb = bleBluetooth;
        s = uuid_service;
        w = uuid_write;
        d = data;
        sn = sendNextWhenLastSuccess;
        it = intervalBetweenTwoPackage;
        c = BleManagerImpl.getInstance().getSplitWriteNum();
        cb = callback;

        sw();
    }

    private void sw() {
        if (d == null) {
            throw new IllegalArgumentException("data is Null!");
        }
        if (c < 1) {
            throw new IllegalArgumentException("split count should higher than 0!");
        }
        q = splitByte(d, c);
        tn = q.size();
        w();
    }

    private void w() {
        if (q.peek() == null) {
            release();
            return;
        }

        byte[] d = q.poll();
        bb.newBleConnector()
                .withUUIDString(s, w)
                .writeCharacteristic(
                        d,
                        new BleWriteCallback() {
                            @Override
                            public void onWriteSuccess(int current, int total, byte[] w) {
                                int p = tn - q.size();
                                if (cb != null) {
                                    cb.onWriteSuccess(p, tn, w);
                                }
                                if (sn) {
                                    Message m = h.obtainMessage(BleMsg.MSG_SPLIT_WRITE_NEXT);
                                    h.sendMessageDelayed(m, it);
                                }
                            }

                            @Override
                            public void onWriteFailure(BleException exception) {
                                if (cb != null) {
                                    cb.onWriteFailure(new OtherException("exception occur while writing: " + exception.getDescription()));
                                }
                                if (sn) {
                                    Message m = h.obtainMessage(BleMsg.MSG_SPLIT_WRITE_NEXT);
                                    h.sendMessageDelayed(m, it);
                                }
                            }
                        },
                        w);

        if (!sn) {
            Message m = h.obtainMessage(BleMsg.MSG_SPLIT_WRITE_NEXT);
            h.sendMessageDelayed(m, it);
        }
    }

    private void release() {
        ht.quit();
        h.removeCallbacksAndMessages(null);
    }

//    private static Queue<byte[]> splitByte(byte[] data, int count) {
//        if (count > 20) {
//            BleLog.w("Be careful: split count beyond 20! Ensure MTU higher than 23!");
//        }
//        Queue<byte[]> byteQueue = new LinkedList<>();
//        if (data != null) {
//            int index = 0;
//            do {
//                byte[] rawData = new byte[data.length - index];
//                byte[] newData;
//                System.arraycopy(data, index, rawData, 0, data.length - index);
//                if (rawData.length <= count) {
//                    newData = new byte[rawData.length];
//                    System.arraycopy(rawData, 0, newData, 0, rawData.length);
//                    index += rawData.length;
//                } else {
//                    newData = new byte[count];
//                    System.arraycopy(data, index, newData, 0, count);
//                    index += count;
//                }
//                byteQueue.offer(newData);
//            } while (index < data.length);
//        }
//        return byteQueue;
//    }

    private static Queue<byte[]> splitByte(byte[] data, int count) {
        if (count > 20) {
            BleLog.w("Be careful: split count beyond 20! Ensure MTU higher than 23!");
        }
        Queue<byte[]> q = new LinkedList<>();
        int c;
        if (data.length % count == 0) {
            c = data.length / count;
        } else {
            c = Math.round(data.length / count + 1);
        }

        if (c > 0) {
            for (int i = 0; i < c; i++) {
                byte[] d;
                int j;
                if (c == 1 || i == c - 1) {
                    j = data.length % count == 0 ? count : data.length % count;
                    System.arraycopy(data, i * count, d = new byte[j], 0, j);
                } else {
                    System.arraycopy(data, i * count, d = new byte[count], 0, count);
                }
                q.offer(d);
            }
        }

        return q;
    }
}
