package com.polaris.speedble.callback;


import com.polaris.speedble.data.DataStructure;

public abstract class BleResponseCallback {
    public abstract void onWriteSuccess(byte[] raw, DataStructure dataStructure);
}
