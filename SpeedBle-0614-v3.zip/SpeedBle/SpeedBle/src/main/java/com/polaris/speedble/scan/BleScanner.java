package com.polaris.speedble.scan;


import android.annotation.TargetApi;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import com.polaris.speedble.BleManagerImpl;
import com.polaris.speedble.callback.BleScanAndConnectCallback;
import com.polaris.speedble.callback.BleScanCallback;
import com.polaris.speedble.callback.BleScanPresenterImp;
import com.polaris.speedble.data.BleDevice;
import com.polaris.speedble.data.BleScanState;
import com.polaris.speedble.utils.BleLog;

import java.util.List;
import java.util.UUID;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
public class BleScanner {

    public static BleScanner getInstance() {
        return BleScannerHolder.s;
    }

    private static class BleScannerHolder {
        private static final BleScanner s = new BleScanner();
    }

    private BleScanState s = BleScanState.STATE_IDLE;

    private BSP bsp = new BSP() {

        @Override
        public void onScanStarted(boolean success) {
            BleScanPresenterImp c = bsp.getBleScanPresenterImp();
            if (c != null) {
                c.onScanStarted(success);
            }
        }

        @Override
        public void onLeScan(BleDevice bleDevice) {
            if (bsp.ismNeedConnect()) {
                BleScanAndConnectCallback c = (BleScanAndConnectCallback)
                        bsp.getBleScanPresenterImp();
                if (c != null) {
                    c.onLeScan(bleDevice);
                }
            } else {
                BleScanCallback c = (BleScanCallback) bsp.getBleScanPresenterImp();
                if (c != null) {
                    c.onLeScan(bleDevice);
                }
            }
        }

        @Override
        public void onScanning(BleDevice result) {
            BleScanPresenterImp c = bsp.getBleScanPresenterImp();
            if (c != null) {
                c.onScanning(result);
            }
        }

        @Override
        public void onScanFinished(List<BleDevice> bleDeviceList) {
            if (bsp.ismNeedConnect()) {
                final BleScanAndConnectCallback c = (BleScanAndConnectCallback)
                        bsp.getBleScanPresenterImp();
                if (bleDeviceList == null || bleDeviceList.size() < 1) {
                    if (c != null) {
                        c.onScanFinished(null);
                    }
                } else {
                    if (c != null) {
                        c.onScanFinished(bleDeviceList.get(0));
                    }
                    final List<BleDevice> l = bleDeviceList;
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            BleManagerImpl.getInstance().connect(l.get(0), c);
                        }
                    }, 100);
                }
            } else {
                BleScanCallback c = (BleScanCallback) bsp.getBleScanPresenterImp();
                if (c != null) {
                    c.onScanFinished(bleDeviceList);
                }
            }
        }
    };

    public void scan(UUID[] serviceUuids, String[] names, String mac, boolean fuzzy,
                     long timeOut, final BleScanCallback callback) {

        startLeScan(serviceUuids, names, mac, fuzzy, false, timeOut, callback);
    }

    public void scanAndConnect(UUID[] serviceUuids, String[] names, String mac, boolean fuzzy,
                               long timeOut, BleScanAndConnectCallback callback) {

        startLeScan(serviceUuids, names, mac, fuzzy, true, timeOut, callback);
    }

    private synchronized void startLeScan(UUID[] serviceUuids, String[] names, String mac, boolean fuzzy,
                                          boolean needConnect, long timeOut, BleScanPresenterImp imp) {

        if (s != BleScanState.STATE_IDLE) {
            BleLog.w("scan action already exists, complete the previous scan action first");
            if (imp != null) {
                imp.onScanStarted(false);
            }
            return;
        }

        bsp.prepare(names, mac, fuzzy, needConnect, timeOut, imp);

        boolean z = BleManagerImpl.getInstance().getBluetoothAdapter()
                .startLeScan(serviceUuids, bsp);
        s = z ? BleScanState.STATE_SCANNING : BleScanState.STATE_IDLE;
        bsp.notifyScanStarted(z);
    }

    public synchronized void stopLeScan() {
        BleManagerImpl.getInstance().getBluetoothAdapter().stopLeScan(bsp);
        s = BleScanState.STATE_IDLE;
        bsp.notifyScanStopped();
    }

    public BleScanState getScanState() {
        return s;
    }


}
